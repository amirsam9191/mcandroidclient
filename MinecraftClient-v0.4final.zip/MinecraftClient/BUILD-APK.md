# ساخت APK

روی ماشینی که این پروژه در آن نوشته شد اینترنت (DNS) کار نمی‌کرد؛ پس APK **ساخته نشده** و Kotlin هرگز کامپایل نشده است. ساده‌ترین راه:

## راه ۱ — GitHub Actions (بدون نصب چیزی)
1. یک مخزن GitHub بسازید و محتویات این پوشه را در آن push کنید (`keystore/` هم باید باشد).
2. تب **Actions** ← workflow «Build APK» (خودکار با push اجرا می‌شود، یا «Run workflow»).
3. بعد از اتمام، از پایین صفحهٔ اجرا فایل‌های **MinecraftClient-release-apk** و **MinecraftClient-debug-apk** را دانلود کنید.
4. اگر مرحلهٔ `gradle :app:assembleRelease` با خطای Kotlin شکست خورد (محتمل‌ترین مشکل اولین ساخت)، متن خطا را بفرستید تا درست شود.

## راه ۲ — محلی
JDK 17، Android SDK 34 (platform + build-tools) و Gradle 8.9:
```
gradle :app:assembleRelease     # app/build/outputs/apk/release/
gradle :app:assembleDebug       # app/build/outputs/apk/debug/
```

## اگر می‌خواهید من بسازم
محیط اجرای کد من باید به این دامنه‌ها دسترسی داشته باشد: `services.gradle.org`, `downloads.gradle.org`, `github.com`, `release-assets.githubusercontent.com`, `dl.google.com`, `maven.google.com`, `dl.google.com/dl/android/maven2`, `repo.maven.apache.org`, `repo1.maven.org`, `plugins.gradle.org`, `jcenter.bintray.com` (اختیاری). (فقط روشن‌کردن «اینترنت» کافی نیست اگر فهرست دامنه‌های مجاز Gradle و Google Maven را شامل نشود.)

## امضا و به‌روزرسانی
همهٔ APKها (debug و release، هر جا ساخته شوند) با `keystore/mcclient.jks` امضا می‌شوند و `versionCode` = ۴ است. اگر نسخهٔ قبلی با کلید دیگری امضا شده بود، یک بار آن را حذف کنید.
