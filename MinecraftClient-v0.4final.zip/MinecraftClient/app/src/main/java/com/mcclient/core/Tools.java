package com.mcclient.core;

/** Tool choice and dig-time estimation (vanilla formula: speed / hardness / 30, or / 100 without the right tool). */
public final class Tools {
    private Tools() {}

    private static boolean has(String n, String... parts) { for (String p : parts) if (n.contains(p)) return true; return false; }

    /** "pickaxe", "axe", "shovel", "hoe", "shears" or null when bare hands are fine. */
    public static String kindFor(String block) {
        if (block == null) return null;
        if (has(block, "concrete_powder")) return "shovel";
        if (has(block, "wool", "cobweb")) return "shears";
        if (has(block, "log", "wood", "planks", "stem", "hyphae", "chest", "barrel", "crafting_table", "bookshelf", "fence", "sign", "pumpkin",
            "melon", "bamboo", "note_block", "jukebox", "lectern", "loom", "beehive", "bee_nest", "trapdoor", "scaffolding", "cartography", "fletching", "smithing_table")
            && !block.startsWith("iron_") && !has(block, "nether_brick_fence", "stone", "stem_plant")) return "axe";
        if (block.endsWith("_door") && !block.startsWith("iron_")) return "axe";
        if (has(block, "dirt", "grass_block", "sand", "gravel", "clay", "soul_soil", "soul_sand", "snow", "mud", "farmland", "podzol", "mycelium",
            "dirt_path", "rooted") && !has(block, "sandstone")) return "shovel";
        if (has(block, "leaves", "hay_block", "sponge", "shroomlight", "wart_block", "sculk", "target", "moss")) return "hoe";
        if (has(block, "stone", "cobble", "brick", "ore", "deepslate", "obsidian", "terracotta", "concrete", "andesite", "diorite", "granite",
            "basalt", "blackstone", "netherrack", "end_stone", "prismarine", "purpur", "quartz", "sandstone", "furnace", "iron_", "gold_block",
            "diamond_block", "emerald_block", "lapis_block", "copper", "tuff", "calcite", "dripstone", "amethyst", "ice", "rail", "anvil", "lantern",
            "bell", "hopper", "cauldron", "glazed", "magma", "observer", "dispenser", "dropper", "piston", "coal_block", "redstone_block", "bone_block")) return "pickaxe";
        return null;
    }

    public static double tierSpeed(String item) {
        if (item == null) return 1;
        if (item.startsWith("wooden_")) return 2;
        if (item.startsWith("stone_")) return 4;
        if (item.startsWith("iron_")) return 6;
        if (item.startsWith("diamond_")) return 8;
        if (item.startsWith("netherite_")) return 9;
        if (item.startsWith("golden_")) return 12;
        if (item.equals("shears")) return 5;
        return 1;
    }

    /** True when {@code item} is the right kind of tool for {@code block}. */
    public static boolean correctTool(String item, String block) {
        String kind = kindFor(block);
        if (item == null || kind == null) return false;
        return kind.equals("shears") ? item.equals("shears") : item.endsWith("_" + kind);
    }

    /** Ticks the server needs to finish the block with this item (null = bare hand). */
    /** Highest tool tier needed to get drops from the block (-1 = none): 0 wood/gold, 1 stone, 2 iron, 3 diamond. */
    static int requiredTier(String b) {
        if (b == null) return -1;
        switch (b) {
            case "obsidian": case "crying_obsidian": case "respawn_anchor": case "ancient_debris": case "netherite_block": return 3;
            case "diamond_ore": case "deepslate_diamond_ore": case "emerald_ore": case "deepslate_emerald_ore": case "gold_ore": case "deepslate_gold_ore":
            case "redstone_ore": case "deepslate_redstone_ore": case "gold_block": case "raw_gold_block": case "diamond_block": case "emerald_block": return 2;
            case "iron_ore": case "deepslate_iron_ore": case "iron_block": case "raw_iron_block": case "lapis_ore": case "deepslate_lapis_ore": case "lapis_block":
            case "copper_ore": case "deepslate_copper_ore": case "raw_copper_block": return 1;
            default: return b.contains("copper") ? 1 : -1;
        }
    }

    static int toolTier(String item) {
        if (item == null) return -1;
        if (item.startsWith("netherite_") || item.startsWith("diamond_")) return 3;
        if (item.startsWith("iron_")) return 2;
        if (item.startsWith("stone_")) return 1;
        if (item.startsWith("wooden_") || item.startsWith("golden_")) return 0;
        return -1;
    }

    /** Mining Fatigue multipliers of 1.20.4 by level (amplifier + 1). */
    private static final float[] FATIGUE = {1f, 0.3f, 0.09f, 0.0027f, 8.1E-4f};

    public static int breakTicks(double hardness, String block, String item) { return breakTicks(hardness, block, item, true, false, 0); }

    /**
     * Ticks until the real client's destroy progress reaches 1.0, as in Player.getDestroySpeed + BlockBehaviour.getDestroyProgress:
     * progress per tick = speed / hardness / (30 if the drops are harvestable, else 100), accumulated in float. The speed is divided
     * by 5 in the air and with the head under water, and scaled down by Mining Fatigue. Efficiency and Haste are left out on purpose:
     * ignoring them only makes us slower than the real client, never faster (a faster break would be an obvious cheat signature).
     * @return 1 for an instant break (the real client then sends only START), Integer.MAX_VALUE if the block cannot be broken
     */
    public static int breakTicks(double hardness, String block, String item, boolean onGround, boolean headInWater, int fatigueLevel) {
        if (hardness < 0) return Integer.MAX_VALUE;
        boolean correct = correctTool(item, block);
        float speed = correct ? (float) tierSpeed(item) : 1.0f;
        if (fatigueLevel > 0) speed *= FATIGUE[Math.min(fatigueLevel, 4)];
        if (headInWater) speed /= 5.0f;
        if (!onGround) speed /= 5.0f;
        boolean needsTool = "pickaxe".equals(kindFor(block));
        boolean harvest = !needsTool || (correct && toolTier(item) >= requiredTier(block));
        if (hardness == 0) return 1;
        float damage = speed / (float) hardness / (harvest ? 30.0f : 100.0f);
        if (damage >= 1.0f) return 1;
        if (damage <= 0f) return Integer.MAX_VALUE;
        float acc = 0f; int n = 0;
        while (acc < 1.0f && n < 1_000_000) { acc += damage; n++; }
        return n;
    }

    /** Best hotbar slot (0-8) for the block, or -1 to keep the current item. */
    public static int bestSlot(Inventory inv, String block) {
        String kind = kindFor(block);
        if (kind == null) return -1;
        int best = -1;
        double bestSpeed = 1.0;
        for (int i = 0; i < 9; i++) {
            String n = inv.hotbarItemName(i);
            if (n != null && correctTool(n, block) && tierSpeed(n) > bestSpeed) { bestSpeed = tierSpeed(n); best = i; }
        }
        return best;
    }

    private static final String[] THROWAWAY = {"cobblestone", "dirt", "netherrack", "cobbled_deepslate", "stone", "andesite", "diorite", "granite",
        "deepslate", "tuff", "oak_planks", "spruce_planks", "birch_planks", "jungle_planks", "acacia_planks", "dark_oak_planks"};

    /** Hotbar slot with a cheap full block to bridge/pillar with, or -1. */
    public static int throwawaySlot(Inventory inv) {
        for (String want : THROWAWAY) {
            for (int i = 0; i < 9; i++) if (want.equals(inv.hotbarItemName(i))) return i;
        }
        return -1;
    }

    /** Foods in the order we prefer to eat them (best saturation first, golden apples kept for emergencies). Rotten flesh, spider eyes,
     *  poisonous potatoes, pufferfish, raw chicken, chorus fruit and suspicious stew are never eaten automatically. */
    private static final String[] FOODS = {"cooked_beef", "cooked_porkchop", "cooked_mutton", "cooked_salmon", "cooked_chicken", "cooked_rabbit", "cooked_cod",
        "bread", "baked_potato", "golden_carrot", "pumpkin_pie", "mushroom_stew", "beetroot_soup", "rabbit_stew", "carrot", "apple", "melon_slice",
        "sweet_berries", "glow_berries", "cookie", "dried_kelp", "beetroot", "potato", "honey_bottle", "beef", "porkchop", "mutton", "cod", "salmon", "rabbit"};

    public static boolean isFood(String item) { for (String f : FOODS) if (f.equals(item)) return true; return false; }

    /** Hotbar slot of the best food, or -1. */
    public static int foodSlot(Inventory inv) {
        for (String want : FOODS) {
            for (int i = 0; i < 9; i++) if (want.equals(inv.hotbarItemName(i))) return i;
        }
        return -1;
    }
}
