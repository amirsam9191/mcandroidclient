package com.mcclient.core;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** Server resource-pack cache: a pack is downloaded again only when its SHA-1 hash differs from the cached file. */
public final class Packs {
    private Packs() {}

    /** The most recently loaded server pack (used by the UI to override item textures and the font). */
    public static volatile File active;

    public static final class Result {
        public final boolean ok, cached;
        public final File file;
        public final String error;
        Result(boolean ok, boolean cached, File file, String error) { this.ok = ok; this.cached = cached; this.file = file; this.error = error; }
    }

    private static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    private static MessageDigest sha1() {
        try { return MessageDigest.getInstance("SHA-1"); } catch (NoSuchAlgorithmException e) { throw new IllegalStateException(e); }
    }

    public static String sha1(File f) throws java.io.IOException {
        MessageDigest md = sha1();
        try (InputStream in = new java.io.FileInputStream(f)) {
            byte[] buf = new byte[32768];
            int n;
            while ((n = in.read(buf)) >= 0) md.update(buf, 0, n);
        }
        return hex(md.digest());
    }

    public static Result fetch(File dir, String url, String expectedHash) {
        dir.mkdirs();
        File target = new File(dir, hex(sha1().digest(url.getBytes(StandardCharsets.UTF_8))) + ".zip");
        String want = expectedHash == null ? "" : expectedHash.trim().toLowerCase();
        try {
            if (target.exists() && !want.isEmpty() && sha1(target).equals(want)) { active = target; return new Result(true, true, target, ""); }
            String current = url;
            HttpURLConnection conn = null;
            for (int hop = 0; hop < 6; hop++) {
                HttpURLConnection c = (HttpURLConnection) new URL(current).openConnection();
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                c.setRequestProperty("User-Agent", "MinecraftClientApp/0.1");
                int code = c.getResponseCode();
                if (code >= 300 && code < 400) {
                    String loc = c.getHeaderField("Location");
                    c.disconnect();
                    if (loc == null) return new Result(false, false, null, "redirect without location");
                    current = new URL(new URL(current), loc).toString();
                    continue;
                }
                if (code != 200) { c.disconnect(); return new Result(false, false, null, "HTTP " + code); }
                conn = c;
                break;
            }
            if (conn == null) return new Result(false, false, null, "too many redirects");
            File tmp = new File(target.getPath() + ".tmp");
            try (InputStream in = conn.getInputStream(); OutputStream out = new java.io.FileOutputStream(tmp)) {
                byte[] buf = new byte[32768];
                int n;
                while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
            } finally { conn.disconnect(); }
            if (!want.isEmpty() && !sha1(tmp).equals(want)) { tmp.delete(); return new Result(false, false, null, "hash mismatch"); }
            if (target.exists()) target.delete();
            if (!tmp.renameTo(target)) return new Result(false, false, null, "cannot move file");
            active = target;
            return new Result(true, false, target, "");
        } catch (Exception e) {
            return new Result(false, false, null, e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());
        }
    }
}
