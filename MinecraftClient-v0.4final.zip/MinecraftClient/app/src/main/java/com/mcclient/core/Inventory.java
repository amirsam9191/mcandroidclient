package com.mcclient.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Player inventory + the currently open container, with click prediction (protocol 765 slot format). */
public final class Inventory {
    public static final int PLAYER_WINDOW = 0;
    public static final int OUTSIDE = -999;

    public static final class Stack {
        public final int id;
        public int count;
        public final Object nbt; // parsed NBT compound (Map) or null

        public Stack(int id, int count, Object nbt) { this.id = id; this.count = count; this.nbt = nbt; }
        public Stack copy() { return new Stack(id, count, nbt); }

        @SuppressWarnings("unchecked")
        private Map<String, Object> display() {
            if (!(nbt instanceof Map)) return null;
            Object d = ((Map<String, Object>) nbt).get("display");
            return d instanceof Map ? (Map<String, Object>) d : null;
        }
        /** Custom name (display.Name) or null. */
        public List<Chat.Span> customName() {
            Map<String, Object> d = display();
            if (d == null || !(d.get("Name") instanceof String)) return null;
            return Chat.fromJsonText((String) d.get("Name"));
        }
        /** Lore lines (display.Lore). */
        public List<List<Chat.Span>> lore() {
            List<List<Chat.Span>> out = new ArrayList<>();
            Map<String, Object> d = display();
            if (d != null && d.get("Lore") instanceof List) {
                for (Object o : (List<?>) d.get("Lore")) if (o instanceof String) out.add(Chat.fromJsonText((String) o));
            }
            return out;
        }
        boolean sameKind(Stack o) {
            return o != null && o.id == id && (nbt == null ? o.nbt == null : nbt.equals(o.nbt));
        }
    }

    public static final class Window {
        public final int id;
        public int type;                 // menu type (generic_9x3 = 2 ...); -1 for the player window
        public List<Chat.Span> title = new ArrayList<>();
        public Stack[] slots;
        public int stateId;
        /** Set Container Property values (enchantment levels, furnace progress, loom/stonecutter selection...). */
        public final java.util.Map<Integer, Integer> props = new java.util.HashMap<>();
        Window(int id, int size) { this.id = id; this.slots = new Stack[size]; }
        public int size() { return slots.length; }
        /** First slot of the 27 main inventory slots (the last 36 slots of every container window). */
        public int playerStart() { return id == PLAYER_WINDOW ? 9 : slots.length - 36; }
    }

    private Window player = new Window(PLAYER_WINDOW, 46);
    private Window open;
    private Stack cursor;
    private int held;
    public Data.Items items;

    public Inventory() { player.type = -1; }

    public synchronized Window player() { return player; }
    public synchronized Window open() { return open; }
    public synchronized Window current() { return open != null ? open : player; }
    public synchronized Stack cursor() { return cursor; }
    public synchronized int heldSlot() { return held; }
    public synchronized void setHeld(int h) { held = Math.max(0, Math.min(8, h)); }
    public synchronized Stack heldItem() { return player.slots[36 + held]; }

    /** Registry name of the item in hotbar slot i (0-8), or null when empty/unknown. */
    public synchronized String hotbarItemName(int i) {
        Stack s = i >= 0 && i < 9 ? player.slots[36 + i] : null;
        return s == null || items == null ? null : items.name(s.id);
    }

    public synchronized void reset() {
        player = new Window(PLAYER_WINDOW, 46); player.type = -1;
        open = null; cursor = null; held = 0;
    }

    /** Immutable copy of what the UI needs (safe to read from any thread). */
    public static final class Snapshot {
        public final int windowId, held, playerStart;
        public final boolean container;
        public final List<Chat.Span> title;
        public final Stack[] slots;
        public final Stack cursor;
        /** Menu type id (see {@link MenuLayouts}) or -1 for the player's own inventory window. */
        public final int type;
        /** Set Container Property values of the window. */
        public final java.util.Map<Integer, Integer> props;
        Snapshot(int windowId, int held, int playerStart, boolean container, List<Chat.Span> title, Stack[] slots, Stack cursor, int type, java.util.Map<Integer, Integer> props) {
            this.windowId = windowId; this.held = held; this.playerStart = playerStart; this.container = container;
            this.title = title; this.slots = slots; this.cursor = cursor; this.type = type; this.props = props;
        }
    }

    public synchronized Snapshot snapshot() {
        Window w = current();
        Stack[] copy = new Stack[w.slots.length];
        for (int i = 0; i < copy.length; i++) copy[i] = w.slots[i] == null ? null : w.slots[i].copy();
        return new Snapshot(w.id, held, w.playerStart(), open != null, new ArrayList<>(w.title), copy, cursor == null ? null : cursor.copy(), open != null ? w.type : -1, new java.util.HashMap<>(w.props));
    }

    // ------------------------------------------------------------------ wire format

    public static Stack readSlot(Buf.Reader r) {
        if (!r.bool()) return null;
        int id = r.varInt();
        int count = r.i8();
        Object nbt = r.nbt();
        return new Stack(id, count, nbt);
    }

    public static void writeSlot(Buf.Writer w, Stack s) {
        if (s == null || s.count <= 0) { w.bool(false); return; }
        w.bool(true).varInt(s.id).b(s.count).nbt(s.nbt);
    }

    // ------------------------------------------------------------------ server -> client

    public synchronized void onContent(Buf.Reader r) {
        int wid = r.u8();
        int state = r.varInt();
        int n = r.varInt();
        if (n < 0 || n > 200) throw new Buf.ParseEx("bad slot count");
        Stack[] slots = new Stack[n];
        for (int i = 0; i < n; i++) slots[i] = readSlot(r);
        Stack carried = readSlot(r);
        Window w = windowFor(wid);
        if (w == null) return;
        if (w.slots.length != n) w.slots = new Stack[n];
        System.arraycopy(slots, 0, w.slots, 0, n);
        w.stateId = state;
        cursor = carried;
    }

    public synchronized void onSlot(Buf.Reader r) {
        int wid = r.i8();
        int state = r.varInt();
        int slot = r.s16();
        Stack s = readSlot(r);
        if (wid == -1 && slot == -1) { cursor = s; return; }
        Window w = windowFor(wid & 0xFF);
        if (w == null) return;
        w.stateId = state;
        if (slot >= 0 && slot < w.slots.length) w.slots[slot] = s;
    }

    /** Set Container Property (0x14): window id (u8), property (s16), value (s16). */
    public synchronized void onProperty(Buf.Reader r) {
        int wid = r.u8();
        int prop = r.s16();
        int value = r.s16();
        Window w = windowFor(wid);
        if (w != null) w.props.put(prop, value);
    }

    public synchronized void onOpen(Buf.Reader r) {
        int wid = r.varInt();
        int type = r.varInt();
        Object title = r.nbt();
        int size = sizeForType(type);
        open = new Window(wid, size);
        open.type = type;
        open.title = Chat.fromAny(title);
    }

    public synchronized void onClose(int wid) { if (open != null && open.id == wid) open = null; }
    public synchronized void closeLocal() { open = null; cursor = null; }

    private Window windowFor(int wid) {
        if (wid == PLAYER_WINDOW) return player;
        if (open != null && open.id == wid) return open;
        return null;
    }

    /** Slot count (including the 36 player slots) of a menu type; the real count is also taken from Set Container Content. */
    static int sizeForType(int type) { return MenuLayouts.containerSlots(type) + 36; }

    // ------------------------------------------------------------------ client -> server

    private int maxStack(Stack s) {
        String n = items == null ? null : items.name(s.id);
        if (n == null) return 64;
        if (n.endsWith("_sword") || n.endsWith("_pickaxe") || n.endsWith("_axe") || n.endsWith("_shovel") || n.endsWith("_hoe")
            || n.endsWith("_helmet") || n.endsWith("_chestplate") || n.endsWith("_leggings") || n.endsWith("_boots")
            || n.equals("bow") || n.equals("crossbow") || n.equals("shield") || n.equals("elytra") || n.equals("trident")
            || n.endsWith("_boat") || n.endsWith("_bed") || n.endsWith("_minecart") || n.equals("saddle") || n.endsWith("_potion")
            || n.equals("shears") || n.equals("flint_and_steel") || n.equals("fishing_rod") || n.endsWith("_bucket") && !n.equals("bucket")) return 1;
        if (n.equals("ender_pearl") || n.equals("snowball") || n.equals("egg") || n.equals("bucket") || n.endsWith("_sign") || n.equals("honey_bottle")) return 16;
        return 64;
    }

    /**
     * Builds a Click Container (0x0D) body and applies the same click to the local state (prediction).
     * Servers resend the real contents when the prediction was wrong.
     */
    public synchronized byte[] click(int slot, int button, int mode) {
        Window w = current();
        Stack[] before = new Stack[w.slots.length];
        for (int i = 0; i < before.length; i++) before[i] = w.slots[i] == null ? null : w.slots[i].copy();
        if (mode == 0) predictPickup(w, slot, button);
        else if (mode == 1) predictQuickMove(w, slot);
        else if (mode == 2) predictHotbarSwap(w, slot, button);
        else if (mode == 4 && slot >= 0 && slot < w.slots.length && w.slots[slot] != null) {
            Stack s = w.slots[slot];
            if (button == 1 || s.count <= 1) w.slots[slot] = null; else s.count--;
        }
        Buf.Writer out = new Buf.Writer();
        out.b(w.id).varInt(w.stateId).s16(slot).b(button).varInt(mode);
        List<Integer> changed = new ArrayList<>();
        for (int i = 0; i < w.slots.length; i++) if (!same(before[i], w.slots[i])) changed.add(i);
        out.varInt(changed.size());
        for (int i : changed) { out.s16(i); writeSlot(out, w.slots[i]); }
        writeSlot(out, cursor);
        return out.toBytes();
    }

    private static boolean same(Stack a, Stack b) {
        if (a == null || a.count <= 0) return b == null || b.count <= 0;
        return b != null && a.sameKind(b) && a.count == b.count;
    }

    private void predictPickup(Window w, int slot, int button) {
        if (slot == OUTSIDE) {
            if (cursor != null) { if (button == 0 || cursor.count <= 1) cursor = null; else cursor.count--; }
            return;
        }
        if (slot < 0 || slot >= w.slots.length) return;
        Stack s = w.slots[slot];
        if (button == 0) {
            if (cursor == null) { cursor = s; w.slots[slot] = null; }
            else if (s == null) { w.slots[slot] = cursor; cursor = null; }
            else if (s.sameKind(cursor)) {
                int room = maxStack(s) - s.count;
                int mv = Math.min(room, cursor.count);
                s.count += mv; cursor.count -= mv;
                if (cursor.count <= 0) cursor = null;
            } else { w.slots[slot] = cursor; cursor = s; }
        } else {
            if (cursor == null) {
                if (s != null) {
                    int take = (s.count + 1) / 2;
                    cursor = new Stack(s.id, take, s.nbt);
                    s.count -= take;
                    if (s.count <= 0) w.slots[slot] = null;
                }
            } else if (s == null) {
                w.slots[slot] = new Stack(cursor.id, 1, cursor.nbt);
                if (--cursor.count <= 0) cursor = null;
            } else if (s.sameKind(cursor)) {
                if (s.count < maxStack(s)) { s.count++; if (--cursor.count <= 0) cursor = null; }
            } else { w.slots[slot] = cursor; cursor = s; }
        }
    }

    private void predictHotbarSwap(Window w, int slot, int button) {
        if (slot < 0 || slot >= w.slots.length || button < 0 || button > 8) return;
        int hb = w.id == PLAYER_WINDOW ? 36 + button : w.slots.length - 9 + button;
        if (hb < 0 || hb >= w.slots.length || hb == slot) return;
        Stack t = w.slots[slot]; w.slots[slot] = w.slots[hb]; w.slots[hb] = t;
    }

    // ------------------------------------------------------------------ shift-click (mode 1) prediction

    /** Armor slot (5-8 in the player window) for an item name, or -1. */
    public static int armorSlotFor(String n) {
        if (n == null) return -1;
        if (n.endsWith("_helmet") || n.equals("carved_pumpkin") || n.endsWith("_head") || n.endsWith("_skull")) return 5;
        if (n.endsWith("_chestplate") || n.equals("elytra")) return 6;
        if (n.endsWith("_leggings")) return 7;
        if (n.endsWith("_boots")) return 8;
        return -1;
    }

    /** InventoryMenu / AbstractContainerMenu.moveItemStackTo: merge into matching stacks, then fill empty slots. */
    private boolean moveStackTo(Window w, Stack st, int start, int end, boolean reverse) {
        boolean moved = false;
        int max = maxStack(st);
        if (max > 1) {
            for (int k = 0; k < end - start && st.count > 0; k++) {
                int i = reverse ? end - 1 - k : start + k;
                Stack t = w.slots[i];
                if (t != null && t.sameKind(st) && t.count < max) {
                    int mv = Math.min(max - t.count, st.count);
                    t.count += mv; st.count -= mv; moved = true;
                }
            }
        }
        for (int k = 0; k < end - start && st.count > 0; k++) {
            int i = reverse ? end - 1 - k : start + k;
            if (w.slots[i] == null) {
                int mv = Math.min(max, st.count);
                w.slots[i] = new Stack(st.id, mv, st.nbt);
                st.count -= mv; moved = true;
            }
        }
        return moved;
    }

    /** Shift-click prediction for the player window and the plain item containers; other menus are left to the server. */
    private void predictQuickMove(Window w, int slot) {
        if (slot < 0 || slot >= w.slots.length || w.slots[slot] == null) return;
        Stack st = w.slots[slot];
        String name = items == null ? null : items.name(st.id);
        if (w.id == PLAYER_WINDOW) {
            if (slot == 0) return; // crafting output: the server decides how much is crafted
            if (slot >= 1 && slot <= 8 || slot == 45) moveStackTo(w, st, 9, 45, false);
            else {
                int a = armorSlotFor(name);
                if (a >= 5 && w.slots[a] == null) { w.slots[a] = new Stack(st.id, 1, st.nbt); st.count--; }
                else if ("shield".equals(name) && w.slots[45] == null) { w.slots[45] = new Stack(st.id, 1, st.nbt); st.count--; }
                else if (slot >= 9 && slot < 36) moveStackTo(w, st, 36, 45, false);
                else if (slot >= 36 && slot < 45) moveStackTo(w, st, 9, 36, false);
            }
        } else if (w.type >= 0 && w.type <= 5 || w.type == MenuLayouts.GENERIC_3X3 || w.type == MenuLayouts.HOPPER || w.type == MenuLayouts.SHULKER_BOX) {
            int cs = w.slots.length - 36;
            if (slot < cs) moveStackTo(w, st, cs, w.slots.length, true);
            else moveStackTo(w, st, 0, cs, false);
        } else return;
        if (st.count <= 0) w.slots[slot] = null;
    }
}
