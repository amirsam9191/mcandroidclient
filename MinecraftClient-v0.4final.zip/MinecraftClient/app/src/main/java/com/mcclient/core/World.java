package com.mcclient.core;

import java.util.HashMap;
import java.util.Map;

/** Loaded chunks as block-state ids, plus helpers to query them. Thread-safe. */
public final class World {
    public volatile int minY = -64;
    public volatile int height = 384;
    public volatile Data.Blocks blocks;

    private final Map<Long, int[][]> chunks = new HashMap<>();

    private static long key(int cx, int cz) { return (((long) cx) << 32) ^ (cz & 0xFFFFFFFFL); }

    public synchronized void clear() { chunks.clear(); }
    public synchronized void ensureChunk(int cx, int cz) {
        if (!chunks.containsKey(key(cx, cz))) chunks.put(key(cx, cz), new int[height >> 4][]);
    }
    public synchronized void unload(int cx, int cz) { chunks.remove(key(cx, cz)); }
    public synchronized int chunkCount() { return chunks.size(); }
    public synchronized boolean isLoaded(int x, int z) { return chunks.containsKey(key(x >> 4, z >> 4)); }

    /** Block-state id, 0 above/below the world, or -1 when the chunk is not loaded. */
    public synchronized int get(int x, int y, int z) {
        int[][] c = chunks.get(key(x >> 4, z >> 4));
        if (c == null) return -1;
        int sy = (y - minY) >> 4;
        if (y < minY || sy >= c.length) return 0;
        int[] s = c[sy];
        return s == null ? 0 : s[((y & 15) << 8) | ((z & 15) << 4) | (x & 15)];
    }

    public synchronized void set(int x, int y, int z, int state) {
        int[][] c = chunks.get(key(x >> 4, z >> 4));
        if (c == null || y < minY) return;
        int sy = (y - minY) >> 4;
        if (sy >= c.length) return;
        if (c[sy] == null) {
            if (state == 0) return;
            c[sy] = new int[4096];
        }
        c[sy][((y & 15) << 8) | ((z & 15) << 4) | (x & 15)] = state;
    }

    /** Parses the "data" array of a Chunk Data packet (protocol 765). */
    public void loadChunk(int cx, int cz, byte[] data) {
        int sections = height >> 4;
        int[][] secs = new int[sections][];
        Buf.Reader r = new Buf.Reader(data);
        for (int i = 0; i < sections; i++) {
            r.s16(); // non-air block count
            int[] st = readContainer(r, 4096, 8);
            readContainer(r, 64, 3); // biomes
            boolean any = false;
            for (int v : st) if (v != 0) { any = true; break; }
            secs[i] = any ? st : null;
        }
        synchronized (this) { chunks.put(key(cx, cz), secs); }
    }

    /** Paletted container: single value, indirect palette (bits &lt;= maxIndirect) or direct global ids. */
    static int[] readContainer(Buf.Reader r, int size, int maxIndirect) {
        int bits = r.u8();
        int[] vals = new int[size];
        if (bits == 0) {
            int v = r.varInt();
            int len = r.varInt();
            r.skip(len * 8);
            if (v != 0) java.util.Arrays.fill(vals, v);
            return vals;
        }
        boolean indirect = bits <= maxIndirect;
        int[] palette = null;
        if (indirect) {
            int n = r.varInt();
            if (n < 0 || n > 4096) throw new Buf.ParseEx("bad palette");
            palette = new int[n];
            for (int i = 0; i < n; i++) palette[i] = r.varInt();
        }
        int len = r.varInt();
        int per = 64 / bits;
        if (len < (size + per - 1) / per) throw new Buf.ParseEx("short data array");
        long[] words = new long[len];
        for (int i = 0; i < len; i++) words[i] = r.i64();
        long mask = (1L << bits) - 1;
        for (int i = 0; i < size; i++) {
            int v = (int) ((words[i / per] >>> ((i % per) * bits)) & mask);
            if (indirect) {
                if (v >= palette.length) throw new Buf.ParseEx("palette index out of range");
                v = palette[v];
            }
            vals[i] = v;
        }
        return vals;
    }

    /** Block Update (0x09) position decoding: x 26 bits, z 26 bits, y 12 bits (all signed). */
    public static int posX(long p) { return (int) (p >> 38); }
    public static int posY(long p) { return (int) (p << 52 >> 52); }
    public static int posZ(long p) { return (int) (p << 26 >> 38); }

    // ------------------------------------------------------------------ block predicates (unloaded = not passable)

    public boolean passable(int x, int y, int z) {
        int s = get(x, y, z);
        if (s < 0) return false;
        Data.Blocks b = blocks;
        return b == null ? s == 0 : (b.isPassable(s) || b.isLowStep(s));
    }

    public boolean obstacle(int x, int y, int z) {
        int s = get(x, y, z);
        if (s < 0) return false; // unknown cells do not block physics
        Data.Blocks b = blocks;
        return b == null ? s != 0 : b.isObstacle(s);
    }

    public boolean standable(int x, int y, int z) {
        int s = get(x, y, z);
        if (s < 0) return false;
        Data.Blocks b = blocks;
        return b == null ? s != 0 : b.isStandable(s);
    }

    public boolean water(int x, int y, int z) {
        int s = get(x, y, z);
        Data.Blocks b = blocks;
        return s >= 0 && b != null && b.isWater(s);
    }

    public boolean lava(int x, int y, int z) {
        int s = get(x, y, z);
        Data.Blocks b = blocks;
        return s >= 0 && b != null && b.isLava(s);
    }

    public boolean climbable(int x, int y, int z) {
        int s = get(x, y, z);
        Data.Blocks b = blocks;
        return s >= 0 && b != null && b.isClimbable(s);
    }

    public boolean closedDoor(int x, int y, int z) {
        int s = get(x, y, z);
        Data.Blocks b = blocks;
        return s >= 0 && b != null && b.isClosedDoor(s);
    }

    /** Breakable by hand/tool and safe to break (no lava next to it). Needs registry data. */
    public boolean breakable(int x, int y, int z) {
        int s = get(x, y, z);
        Data.Blocks b = blocks;
        if (s <= 0 || b == null || !b.isBreakable(s)) return false;
        return !lava(x + 1, y, z) && !lava(x - 1, y, z) && !lava(x, y + 1, z) && !lava(x, y - 1, z) && !lava(x, y, z + 1) && !lava(x, y, z - 1);
    }

    public double hardness(int x, int y, int z) {
        int s = get(x, y, z);
        Data.Blocks b = blocks;
        return s < 0 || b == null ? -1 : b.hardness(s);
    }

    public String blockName(int x, int y, int z) {
        int s = get(x, y, z);
        Data.Blocks b = blocks;
        return s < 0 || b == null ? null : b.nameOf(s);
    }

    public boolean canStand(int x, int y, int z) {
        return passable(x, y, z) && passable(x, y + 1, z) && standable(x, y - 1, z);
    }

    // ------------------------------------------------------------------ physics queries (collision boxes, fluids, block properties)

    /** Collision boxes of the block at (x,y,z) relative to its corner, or null (nothing / chunk not loaded). */
    public double[][] boxes(int x, int y, int z) {
        int s = get(x, y, z);
        if (s <= 0) return null;
        Data.Blocks b = blocks;
        if (b == null) return Data.Blocks.FULL;
        return b.collisionBoxes(s);
    }

    /** Adds the world-space boxes of every block that could touch [minX,maxX]x[minY,maxY]x[minZ,maxZ] (touching counts, 1e-7 margin). */
    public void collect(double minX, double minY, double minZ, double maxX, double maxY, double maxZ, java.util.List<double[]> out) {
        int x0 = (int) Math.floor(minX - 1e-7), x1 = (int) Math.floor(maxX + 1e-7);
        int y0 = (int) Math.floor(minY - 1e-7), y1 = (int) Math.floor(maxY + 1e-7);
        int z0 = (int) Math.floor(minZ - 1e-7), z1 = (int) Math.floor(maxZ + 1e-7);
        for (int bx = x0; bx <= x1; bx++)
            for (int bz = z0; bz <= z1; bz++)
                for (int by = y0; by <= y1; by++) {
                    double[][] bs = boxes(bx, by, bz);
                    if (bs == null) continue;
                    for (double[] bb : bs) out.add(new double[]{bx + bb[0], by + bb[1], bz + bb[2], bx + bb[3], by + bb[4], bz + bb[5]});
                }
    }

    /** True when the box overlaps no collision shape (strict overlap, touching is free). */
    public boolean noCollision(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
        java.util.List<double[]> l = new java.util.ArrayList<>();
        collect(minX, minY, minZ, maxX, maxY, maxZ, l);
        for (double[] b : l) if (maxX > b[0] && minX < b[3] && maxY > b[1] && minY < b[4] && maxZ > b[2] && minZ < b[5]) return false;
        return true;
    }

    private double fluidTop(int x, int y, int z, boolean lavaFluid) {
        int s = get(x, y, z);
        Data.Blocks b = blocks;
        if (s <= 0 || b == null) return 0;
        boolean here = lavaFluid ? b.isLava(s) : b.isWater(s);
        if (!here) return 0;
        int above = get(x, y + 1, z);
        boolean full = above > 0 && (lavaFluid ? b.isLava(above) : b.isWater(above));
        return y + (full ? 1.0 : (lavaFluid ? b.lavaOwnHeight(s) : b.waterOwnHeight(s)));
    }

    /** Surface height (absolute y) of the water in this cell, or 0 when the cell has no water. */
    public double waterTop(int x, int y, int z) { return fluidTop(x, y, z, false); }
    public double lavaTop(int x, int y, int z) { return fluidTop(x, y, z, true); }

    /** True when any cell overlapped by the box holds water or lava (cells i..ceil(max)-1, like Level.containsAnyLiquid). */
    public boolean containsLiquid(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
        Data.Blocks b = blocks;
        if (b == null) return false;
        for (int x = (int) Math.floor(minX); x < (int) Math.ceil(maxX); x++)
            for (int y = (int) Math.floor(minY); y < (int) Math.ceil(maxY); y++)
                for (int z = (int) Math.floor(minZ); z < (int) Math.ceil(maxZ); z++) {
                    int s = get(x, y, z);
                    if (s > 0 && (b.isWater(s) || b.isLava(s))) return true;
                }
        return false;
    }

    public float friction(int x, int y, int z) {
        int s = get(x, y, z);
        Data.Blocks b = blocks;
        return s <= 0 || b == null ? 0.6f : b.friction(s);
    }
    public float speedFactor(int x, int y, int z) {
        int s = get(x, y, z);
        Data.Blocks b = blocks;
        return s <= 0 || b == null ? 1f : b.speedFactor(s);
    }
    public float jumpFactor(int x, int y, int z) {
        int s = get(x, y, z);
        Data.Blocks b = blocks;
        return s <= 0 || b == null ? 1f : b.jumpFactor(s);
    }
    public boolean slime(int x, int y, int z) {
        int s = get(x, y, z);
        Data.Blocks b = blocks;
        return s > 0 && b != null && b.isSlime(s);
    }
    public double[] stuck(int x, int y, int z) {
        int s = get(x, y, z);
        Data.Blocks b = blocks;
        return s <= 0 || b == null ? null : b.stuckMultiplier(s);
    }

    // ------------------------------------------------------------------ extra queries used by Physics

    /** Adds every collision box (world coordinates) of the blocks around the query box, with a one block margin. */
    public void collectBoxes(double minX, double minY, double minZ, double maxX, double maxY, double maxZ, java.util.List<double[]> out) {
        collect(minX - 1, minY - 1, minZ - 1, maxX + 1, maxY + 1, maxZ + 1, out);
    }

    public int stateAt(int x, int y, int z) { return get(x, y, z); }

    /** True when the cell holds water or lava. */
    public boolean liquid(int x, int y, int z) {
        int s = get(x, y, z);
        Data.Blocks b = blocks;
        return s > 0 && b != null && (b.isWater(s) || b.isLava(s));
    }

    /** Expected feet height when standing in the cell: on top of a low step inside it, or on the floor block below (slab, soul sand...). */
    public double feetY(int x, int y, int z) {
        Data.Blocks b = blocks;
        if (b != null && b.hasShapes()) {
            double[][] here = boxes(x, y, z);
            if (here != null && b.isLowStep(get(x, y, z))) { double t = 0; for (double[] bx : here) t = Math.max(t, bx[4]); return y + t; }
            double[][] floor = boxes(x, y - 1, z);
            if (floor != null && !climbable(x, y, z) && !water(x, y, z)) { double t = 0; for (double[] bx : floor) t = Math.max(t, bx[4]); return y - 1 + Math.min(t, 1.0); }
        }
        return y;
    }

    /** Up to {@code max} positions of blocks with one of the given names, nearest first, within {@code radius} blocks (loaded chunks only). */
    public java.util.List<int[]> findBlocks(java.util.Set<String> names, double cx, double cy, double cz, int radius, int max) {
        Data.Blocks b = blocks;
        java.util.List<int[]> out = new java.util.ArrayList<>();
        if (b == null || names.isEmpty()) return out;
        boolean[] want = b.stateMask(names);
        java.util.List<long[]> found = new java.util.ArrayList<>();
        int[][][] snap;
        int minCx = ((int) Math.floor(cx) - radius) >> 4, maxCx = ((int) Math.floor(cx) + radius) >> 4;
        int minCz = ((int) Math.floor(cz) - radius) >> 4, maxCz = ((int) Math.floor(cz) + radius) >> 4;
        synchronized (this) {
            for (int ccx = minCx; ccx <= maxCx; ccx++) for (int ccz = minCz; ccz <= maxCz; ccz++) {
                int[][] c = chunks.get(key(ccx, ccz));
                if (c == null) continue;
                for (int sy = 0; sy < c.length; sy++) {
                    int[] sec = c[sy];
                    if (sec == null) continue;
                    for (int i = 0; i < 4096; i++) {
                        int st = sec[i];
                        if (st <= 0 || st >= want.length || !want[st]) continue;
                        int x = (ccx << 4) + (i & 15), z = (ccz << 4) + ((i >> 4) & 15), y = minY + (sy << 4) + (i >> 8);
                        double d = (x + 0.5 - cx) * (x + 0.5 - cx) + (y + 0.5 - cy) * (y + 0.5 - cy) + (z + 0.5 - cz) * (z + 0.5 - cz);
                        if (d <= (double) radius * radius) found.add(new long[]{(long) (d * 1000), x, y, z});
                    }
                }
            }
        }
        found.sort((p, q) -> Long.compare(p[0], q[0]));
        for (int i = 0; i < found.size() && i < max; i++) out.add(new int[]{(int) found.get(i)[1], (int) found.get(i)[2], (int) found.get(i)[3]});
        return out;
    }

    /** True when the cell holds a block the player walks up onto (needs collision shapes). */
    public boolean isLowStepAt(int x, int y, int z) {
        int s = get(x, y, z);
        Data.Blocks b = blocks;
        return s > 0 && b != null && b.isLowStep(s);
    }
}
