package com.mcclient.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay
import com.mcclient.app.game.ChatSpan
import com.mcclient.app.game.InvSlot
import com.mcclient.app.game.InvView
import com.mcclient.app.game.Session
import com.mcclient.app.ui.mc.ItemIcons
import com.mcclient.app.ui.mc.ItemNames
import com.mcclient.app.ui.mc.McFont
import com.mcclient.app.ui.mc.McText
import com.mcclient.core.Chat
import com.mcclient.core.MenuLayouts

/** What a tap on a slot does. SWAP uses the chosen number key (0-8 = hotbar, 40 = the offhand), like pressing 1-9 or F over a slot. */
enum class ClickMode(val label: String) {
    SELECT("انتخاب"), LEFT("چپ"), RIGHT("راست"), SHIFT("شیفت"), DROP("دراپ ۱"), DROP_ALL("دراپ همه"), DOUBLE("دابل‌کلیک"), SWAP("تعویض")
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SlotBox(slot: InvSlot?, selected: Boolean, size: Dp, onClick: () -> Unit, onLongClick: () -> Unit, plain: Boolean = true) {
    val ctx = LocalContext.current
    val ver = McFont.version
    Box(
        Modifier
            .size(size)
            .then(if (plain) Modifier.background(Color(0xFF8B8B8B)).border(if (selected) 2.dp else 1.dp, if (selected) Color.White else Color(0xFF373737))
                  else if (selected) Modifier.border(2.dp, Color.White) else Modifier)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        if (slot != null) {
            val bmp = remember(slot.key, ver) { ItemIcons.get(ctx, slot.key) }
            val pad = size / 9
            if (bmp != null) {
                Image(bmp.asImageBitmap(), contentDescription = null, modifier = Modifier.size(size).padding(pad), filterQuality = FilterQuality.None)
            } else {
                Box(Modifier.size(size).padding(pad).background(Color(0xFF5B8731)), contentAlignment = Alignment.Center) {
                    Text((slot.key ?: "#${slot.id}").take(2).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
            if (slot.count > 1) {
                McText(listOf(ChatSpan(slot.count.toString())), Modifier.align(Alignment.BottomEnd), alignEnd = true)
            }
        }
    }
}

@Composable
fun ItemTooltip(slot: InvSlot, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    Card(
        Modifier.fillMaxWidth().clickable { onDismiss() },
        colors = CardDefaults.cardColors(containerColor = Color(0xF0100010))
    ) {
        Column(Modifier.padding(8.dp)) {
            val title = slot.name ?: listOf(ChatSpan(ItemNames.display(ctx, slot.key, slot.id)))
            McText(title)
            for (l in slot.lore) McText(l)
            McText(listOf(ChatSpan("minecraft:" + (slot.key ?: ("#" + slot.id)), 0xFF555555.toInt())))
        }
    }
}

/** The tap behaviour shared by the player inventory and the server menus. */
class SlotActions(private val session: Session, var view: InvView) {
    var mode by mutableStateOf(ClickMode.SELECT)
    var swapKey by mutableIntStateOf(0)
    var tip by mutableStateOf<InvSlot?>(null)

    fun tap(i: Int) {
        tip = null
        val hotStart = view.playerStart + 27
        when (mode) {
            ClickMode.SELECT -> if (!view.container && i >= hotStart && i < hotStart + 9) session.selectHotbar(i - hotStart) else session.clickSlot(i, 0, 0)
            ClickMode.LEFT -> session.clickSlot(i, 0, 0)
            ClickMode.RIGHT -> session.clickSlot(i, 1, 0)
            ClickMode.SHIFT -> session.clickSlot(i, 0, 1)
            ClickMode.SWAP -> session.clickSlot(i, swapKey, 2)
            ClickMode.DROP -> session.clickSlot(i, 0, 4)
            ClickMode.DROP_ALL -> session.clickSlot(i, 1, 4)
            ClickMode.DOUBLE -> session.clickSlot(i, 0, 6)
        }
    }

    fun longPress(i: Int) { tip = view.slots.getOrNull(i) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ModeChips(a: SlotActions) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        for (m in ClickMode.values()) FilterChip(selected = a.mode == m, onClick = { a.mode = m }, label = { Text(m.label) })
    }
    if (a.mode == ClickMode.SWAP) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            for (k in 0..8) FilterChip(selected = a.swapKey == k, onClick = { a.swapKey = k }, label = { Text("${k + 1}") })
            FilterChip(selected = a.swapKey == 40, onClick = { a.swapKey = 40 }, label = { Text("دست چپ") })
        }
    }
}

@Composable
private fun CursorRow(view: InvView, session: Session, a: SlotActions, size: Dp, dark: Boolean) {
    val cur = view.cursor ?: return
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SlotBox(cur, false, size, { a.tip = cur }, { a.tip = cur })
        Text("در دست", style = MaterialTheme.typography.bodySmall, color = if (dark) Color.Black else MaterialTheme.colorScheme.onSurface)
        TextButton(onClick = { session.clickSlot(-999, 0, 0) }) { Text("رها کردن") }
    }
}

/** Spans of a container title recoloured to the dark grey the vanilla screens use (explicit colours are kept). */
private fun darkTitle(spans: List<ChatSpan>): List<ChatSpan> = spans.map {
    if (it.color == Chat.WHITE) ChatSpan(it.text, 0xFF404040.toInt(), it.bold, it.italic, it.underline, it.strike, it.obfuscated, it.font, it.click, it.hover, it.insertion) else it
}

/**
 * One GUI drawn like in the game: the background texture (server resource pack first, vanilla otherwise) with every slot of the
 * layout placed where the original texture has it. [layout.slots] is indexed by window slot.
 */
@Composable
fun McGuiPanel(
    layout: MenuLayouts.Layout, view: InvView, actions: SlotActions, session: Session,
    maxWidth: Dp, maxHeight: Dp, title: List<ChatSpan>?
) {
    val ctx = LocalContext.current
    val ver = McFont.version
    val packStamp = com.mcclient.core.Packs.active?.lastModified() ?: 0L
    val tex = remember(layout.texture, ver, packStamp) { ItemIcons.texture(ctx, "gui/container/${layout.texture}") }
    val ppd: Dp = minOf(maxWidth / layout.width, maxHeight / layout.height)
    val hotStart = view.playerStart + 27
    Box(Modifier.size(ppd * layout.width, ppd * layout.height)) {
        if (tex != null) {
            Canvas(Modifier.fillMaxSize()) {
                val img = tex.asImageBitmap()
                val w = size.width.toInt()
                val sy = size.height / layout.height
                if (layout.type in 0..5 && layout.texture == "generic_54") {
                    // the chest texture is drawn in two parts: the rows, then the player inventory strip
                    val topH = (layout.type + 1) * 18 + 17
                    val topDst = (topH * sy).toInt()
                    drawImage(img, IntOffset(0, 0), IntSize(176, topH), IntOffset(0, 0), IntSize(w, topDst), filterQuality = FilterQuality.None)
                    drawImage(img, IntOffset(0, 126), IntSize(176, 96), IntOffset(0, topDst), IntSize(w, size.height.toInt() - topDst), filterQuality = FilterQuality.None)
                } else {
                    drawImage(img, IntOffset.Zero, IntSize(minOf(layout.width, img.width), minOf(layout.height, img.height)),
                        IntOffset.Zero, IntSize(w, size.height.toInt()), filterQuality = FilterQuality.None)
                }
            }
        } else {
            Box(Modifier.fillMaxSize().background(Color(0xFFC6C6C6)).border(2.dp, Color(0xFF555555)))
        }
        if (title != null && title.isNotEmpty()) {
            Box(Modifier.offset(ppd * layout.titleX, ppd * layout.titleY).widthIn(max = ppd * (layout.width - 2 * layout.titleX))) { McText(darkTitle(title)) }
        }
        for (i in layout.slots.indices) {
            val p = layout.slots[i]
            if (p[0] < 0) continue
            val selected = !view.container && i >= hotStart && i < hotStart + 9 && i - hotStart == view.held
            Box(Modifier.offset(ppd * (p[0] - 1), ppd * (p[1] - 1))) {
                SlotBox(view.slots.getOrNull(i), selected, ppd * 18, { actions.tap(i) }, { actions.longPress(i) }, plain = tex == null)
            }
        }
        for (b in layout.buttons) {
            val level = view.props[b.id]
            Box(
                Modifier
                    .offset(ppd * b.x, ppd * b.y)
                    .size(ppd * b.w, ppd * b.h)
                    .border(1.dp, Color(0x88FFFFFF))
                    .clickable { session.clickButton(b.id) },
                contentAlignment = Alignment.Center
            ) {
                val label = when {
                    view.type == MenuLayouts.ENCHANTMENT && level != null && level > 0 -> "$level"
                    view.type == MenuLayouts.ENCHANTMENT -> ""
                    else -> "${b.id}"
                }
                if (label.isNotEmpty()) Text(label, color = Color(0xFFFFFF55), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun screenWidth(): Dp = LocalConfiguration.current.screenWidthDp.dp
@Composable
private fun screenHeight(): Dp = LocalConfiguration.current.screenHeightDp.dp

/**
 * The player's inventory. The WHOLE inventory is shown by default (armor, 2x2 crafting + result, offhand, 27 + 9 slots, laid out like
 * inventory.png); the hotbar row alone stays when it is collapsed, so it is always visible above the chat input. Menus opened by the
 * server appear in the middle of the screen. Tapping works like the vanilla GUI; long-press shows the item's name and lore.
 * Tapping a slot opens the inventory screen like pressing E: the character stops (the real client has no movement input then) and the
 * screen closes by itself a few seconds later, or with the close button.
 */
@Composable
fun InventoryPanel(view: InvView, session: Session, modifier: Modifier = Modifier) {
    if (view.slots.size < 36) return
    var expanded by rememberSaveable { mutableStateOf(true) }
    var screenOpen by remember { mutableStateOf(false) }
    LaunchedEffect(session) { while (true) { screenOpen = session.isScreenOpen; delay(300) } }
    val actions = remember(session) { SlotActions(session, view) }
    actions.view = view // the mode and tooltip survive inventory updates; only the view is refreshed
    val hotStart = view.playerStart + 27
    val size = ((screenWidth().value - 28) / 9).coerceIn(30f, 44f).dp
    val full = expanded && !view.container && view.slots.size >= 46

    Column(modifier.padding(horizontal = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        val t = actions.tip
        if (t != null) ItemTooltip(t) { actions.tip = null }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = { session.leftClick() }) { Text("کلیک چپ") }
            OutlinedButton(onClick = { session.rightClick() }) { Text("کلیک راست") }
            OutlinedButton(onClick = { session.swapHands() }) { Text("تعویض دست") }
            TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "کوچک کردن" else "اینونتوری کامل") }
            if (screenOpen) TextButton(onClick = { session.closeWindow() }) { Text("بستن اینونتوری (حرکت ادامه یابد)") }
        }
        if (full) {
            ModeChips(actions)
            CursorRow(view, session, actions, size, false)
            val layout = remember { MenuLayouts.playerInventory() }
            // an inventory.png sized panel: the width of the screen, at most 42% of its height, so the chat stays usable
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                McGuiPanel(layout, view, actions, session, minOf(screenWidth() - 16.dp, 440.dp), screenHeight() * 0.42f, null)
            }
            if (screenOpen) Text("اینونتوری باز است؛ تا بسته نشود (یا چند ثانیه بدون لمس) کاراکتر حرکت نمی‌کند، مثل بازی اصلی.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            // collapsed (or a server menu is open): only the hotbar, which never goes away
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    for (i in hotStart until hotStart + 9) {
                        SlotBox(view.slots.getOrNull(i), i - hotStart == view.held, size, { actions.tap(i) }, { actions.longPress(i) })
                    }
                }
            }
        }
    }

    if (view.container) ServerMenuDialog(view, session, actions)
}

/** A chest / furnace / crafting table / anvil / ... opened by the server: centred on the screen, tapping outside closes it. */
@Composable
private fun ServerMenuDialog(view: InvView, session: Session, actions: SlotActions) {
    val layout = remember(view.type, view.slots.size) {
        val l = MenuLayouts.of(view.type)
        // an unknown size (a type we have no layout for): fall back to a plain grid of the real slot count
        if (l.slots.size == view.slots.size) l else MenuLayouts.of(if (view.slots.size - 36 in 1..54 && (view.slots.size - 36) % 9 == 0) (view.slots.size - 36) / 9 - 1 else 2)
    }
    val size = ((screenWidth().value - 28) / 9).coerceIn(30f, 44f).dp
    Dialog(onDismissRequest = { session.closeWindow() }, properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = true)) {
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) { detectTapGestures(onTap = { session.closeWindow() }) },
            contentAlignment = Alignment.Center
        ) {
            Column(
                Modifier.pointerInput(Unit) { detectTapGestures(onTap = { }) }, // taps inside never close it
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val t = actions.tip
                if (t != null) ItemTooltip(t) { actions.tip = null }
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    McGuiPanel(layout, view, actions, session, minOf(screenWidth() - 12.dp, 460.dp), screenHeight() - 170.dp, view.title)
                }
                Column(Modifier.background(Color(0xCC000000)).padding(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    ModeChips(actions)
                    CursorRow(view, session, actions, size, false)
                    if (!layout.exact) Text("چیدمان این منو تقریبی است", color = Color(0xFFBBBBBB), fontSize = 11.sp)
                }
            }
        }
    }
}
