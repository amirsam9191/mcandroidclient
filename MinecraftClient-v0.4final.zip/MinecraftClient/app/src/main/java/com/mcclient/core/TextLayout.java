package com.mcclient.core;

import java.text.Bidi;
import java.util.ArrayList;
import java.util.List;

/**
 * Chat text layout in "game pixels", independent of Android.
 * Text is classified by script: ASCII (Minecraft bitmap font), Persian/Arabic script (pixel Persian renderer),
 * digits, spaces and any other glyph. Lines are wrapped word by word and reordered with a bidi pass so Persian and
 * English can be mixed in one message without scrambling.
 */
public final class TextLayout {
    private TextLayout() {}

    public static final int LINE_H = 12, BASE = 9;

    public enum Type { AR, LT, NUM, EXT, SPACE }

    public static final class Seg {
        public final String text;
        public final Type type;
        public final Chat.Span span;
        public int width, level, x;
        Seg(String text, Type type, Chat.Span span) { this.text = text; this.type = type; this.span = span; }
    }

    public static final class Layout {
        public final List<List<Seg>> lines;  // each line already in visual (left-to-right) order
        public final int heightGp;
        public final boolean rtl;
        Layout(List<List<Seg>> l, int h, boolean rtl) { lines = l; heightGp = h; this.rtl = rtl; }
    }

    public interface Metrics {
        /** Width in game pixels of the whole run. */
        int width(String text, Type type, boolean bold);
        /** Width of one character inside a run (used only to break over-long words). */
        int charWidth(Seg seg, char ch);
        /**
         * Width of a run drawn with a resource-pack font ("ns:name"), or {@link Integer#MIN_VALUE} when that font is unknown
         * (the run is then measured with the default font). Advances may be negative: pack "space" fonts use them to shift text.
         */
        default int fontWidth(String font, String text, boolean bold) { return Integer.MIN_VALUE; }
    }

    static boolean isArabic(char c) {
        return (c >= '\u0600' && c <= '\u06FF') || (c >= '\u0750' && c <= '\u077F') || (c >= '\u08A0' && c <= '\u08FF')
            || (c >= '\uFB50' && c <= '\uFDFF') || (c >= '\uFE70' && c <= '\uFEFF') || c == '\u200C' || c == '\u200D';
    }

    /** ASCII, Arabic-Indic (U+0660..) and Persian (U+06F0..) digits. */
    private static boolean digit(char c) { return (c >= '0' && c <= '9') || (c >= '\u0660' && c <= '\u0669') || (c >= '\u06F0' && c <= '\u06F9'); }

    /** True when the run needs the pixel (non-bitmap) renderer: Persian/Arabic text, other glyphs, or non-ASCII digits. */
    public static boolean needsPixelFont(Seg s) {
        if (s.type == Type.AR || s.type == Type.EXT) return true;
        for (int i = 0; i < s.text.length(); i++) if (s.text.charAt(i) > 0x7E) return true;
        return false;
    }

    static Type typeOf(String t, int i) {
        char c = t.charAt(i);
        if (c == ' ' || c == '\t' || c == '\u00A0') return Type.SPACE;
        if (digit(c)) return Type.NUM;
        if (isArabic(c) && c != '\u066A' && c != '\u066B' && c != '\u066C') return Type.AR;
        boolean prevDigit = i > 0 && digit(t.charAt(i - 1));
        boolean nextDigit = i + 1 < t.length() && digit(t.charAt(i + 1));
        if ((c == '.' || c == ',' || c == ':' || c == '/' || c == '\u066B' || c == '\u066C') && prevDigit && nextDigit) return Type.NUM;
        if ((c == '%' || c == '\u066A') && prevDigit) return Type.NUM;
        if (isArabic(c)) return Type.AR;
        if (c >= 0x21 && c <= 0x7E) return Type.LT;
        return Type.EXT;
    }

    private static boolean spaceChar(char c) { return c == ' ' || c == '\t' || c == '\u00A0'; }

    private static void tokenize(Chat.Span sp, List<Seg> out) {
        String t = sp.text;
        int i = 0;
        while (i < t.length()) {
            if (t.charAt(i) == '\n') { out.add(null); i++; continue; }
            Type type = typeOf(t, i);
            int j = i + 1;
            if (type == Type.SPACE) { while (j < t.length() && spaceChar(t.charAt(j))) j++; }
            else { while (j < t.length() && t.charAt(j) != '\n' && typeOf(t, j) == type) j++; }
            out.add(new Seg(t.substring(i, j), type, sp));
            i = j;
        }
    }

    private static Seg mk(String text, Type type, Chat.Span span, Metrics m) {
        Seg s = new Seg(text, type, span);
        s.width = measure(s, m);
        return s;
    }

    private static int measure(Seg s, Metrics m) {
        if (s.span.font != null && s.type != Type.SPACE) {
            int fw = m.fontWidth(s.span.font, s.text, s.span.bold);
            if (fw != Integer.MIN_VALUE) return fw;
        }
        if (s.type == Type.SPACE) return s.text.length() * (4 + (s.span.bold ? 1 : 0));
        return m.width(s.text, s.type, s.span.bold);
    }

    private static int cutIndex(Seg seg, int avail, Metrics m) {
        int w = 0, n = 0;
        for (int k = 0; k < seg.text.length(); k++) {
            int cw = m.charWidth(seg, seg.text.charAt(k));
            if (w + cw > avail) break;
            w += cw; n++;
        }
        return n;
    }

    private static Seg prevNonSpace(List<Seg> line, int k) {
        for (int i = k - 1; i >= 0; i--) if (line.get(i).type != Type.SPACE) return line.get(i);
        return null;
    }
    private static Integer levelLeft(List<Seg> line, int k) {
        for (int i = k - 1; i >= 0; i--) if (line.get(i).type != Type.SPACE) return line.get(i).level;
        return null;
    }
    private static Integer levelRight(List<Seg> line, int k) {
        for (int i = k + 1; i < line.size(); i++) if (line.get(i).type != Type.SPACE) return line.get(i).level;
        return null;
    }

    public static Layout build(List<Chat.Span> spans, int maxGp, Metrics m) {
        final int limit = Math.max(20, maxGp);
        List<Seg> items = new ArrayList<>();
        for (Chat.Span sp : spans) tokenize(sp, items);
        for (Seg s : items) if (s != null) s.width = measure(s, m);

        // base direction of the whole message: the first strong character decides
        boolean rtl = false;
        for (Seg s : items) {
            if (s == null) continue;
            if (s.type == Type.AR) { rtl = true; break; }
            if (s.type == Type.LT) {
                boolean letter = false;
                for (int k = 0; k < s.text.length(); k++) if (Character.isLetter(s.text.charAt(k))) letter = true;
                if (letter) break;
            }
        }

        // word wrapping
        List<List<Seg>> lines = new ArrayList<>();
        List<Seg> cur = new ArrayList<>();
        int curW = 0;
        int i = 0;
        while (i < items.size()) {
            Seg s = items.get(i);
            if (s == null) { lines.add(trim(cur)); cur = new ArrayList<>(); curW = 0; i++; continue; }
            if (s.type == Type.SPACE) {
                if (!cur.isEmpty()) {
                    if (curW + s.width > limit) { lines.add(trim(cur)); cur = new ArrayList<>(); curW = 0; }
                    else { cur.add(s); curW += s.width; }
                }
                i++;
                continue;
            }
            List<Seg> word = new ArrayList<>();
            int ww = 0;
            while (i < items.size()) {
                Seg t = items.get(i);
                if (t == null || t.type == Type.SPACE) break;
                word.add(t); ww += t.width; i++;
            }
            if (curW + ww > limit && !cur.isEmpty()) { lines.add(trim(cur)); cur = new ArrayList<>(); curW = 0; }
            if (ww <= limit) { cur.addAll(word); curW += ww; continue; }
            for (Seg seg : word) {
                Seg rest = seg;
                while (true) {
                    if (curW + rest.width <= limit || rest.type == Type.AR || rest.type == Type.EXT) { cur.add(rest); curW += rest.width; break; }
                    int n = cutIndex(rest, limit - curW, m);
                    if (n == 0) {
                        if (!cur.isEmpty()) { lines.add(trim(cur)); cur = new ArrayList<>(); curW = 0; continue; }
                        n = 1;
                    }
                    Seg head = mk(rest.text.substring(0, n), rest.type, rest.span, m);
                    cur.add(head); curW += head.width;
                    lines.add(trim(cur)); cur = new ArrayList<>(); curW = 0;
                    if (n >= rest.text.length()) break;
                    rest = mk(rest.text.substring(n), rest.type, rest.span, m);
                }
            }
        }
        if (!cur.isEmpty() || lines.isEmpty()) lines.add(trim(cur));

        // bidi levels, visual order, x positions
        int base = rtl ? 1 : 0;
        List<List<Seg>> ordered = new ArrayList<>();
        for (List<Seg> line : lines) {
            int n = line.size();
            if (n == 0) { ordered.add(line); continue; }
            for (int k = 0; k < n; k++) {
                Seg s = line.get(k);
                switch (s.type) {
                    case AR: s.level = 1; break;
                    case LT: case EXT: s.level = base == 1 ? 2 : 0; break;
                    case NUM: { Seg p = prevNonSpace(line, k); s.level = (base == 1 || (p != null && p.type == Type.AR)) ? 2 : 0; break; }
                    default: s.level = -1;
                }
            }
            for (int k = 0; k < n; k++) {
                if (line.get(k).level != -1) continue;
                Integer a = levelLeft(line, k), b = levelRight(line, k);
                int lv = base;
                if (a != null && b != null) lv = a.equals(b) ? a : ((a >= 1 && b >= 1) ? 1 : base);
                line.get(k).level = lv;
            }
            byte[] lv = new byte[n];
            Object[] idx = new Object[n];
            for (int k = 0; k < n; k++) { lv[k] = (byte) line.get(k).level; idx[k] = k; }
            Bidi.reorderVisually(lv, 0, idx, 0, n);
            List<Seg> vis = new ArrayList<>(n);
            int total = 0;
            for (int k = 0; k < n; k++) { Seg s = line.get((Integer) idx[k]); vis.add(s); total += s.width; }
            int x = rtl ? Math.max(0, limit - total) : 0;
            for (Seg s : vis) { s.x = x; x += s.width; }
            ordered.add(vis);
        }
        return new Layout(ordered, ordered.size() * LINE_H + 2, rtl);
    }

    private static List<Seg> trim(List<Seg> l) {
        while (!l.isEmpty() && l.get(l.size() - 1).type == Type.SPACE) l.remove(l.size() - 1);
        return l;
    }
}
