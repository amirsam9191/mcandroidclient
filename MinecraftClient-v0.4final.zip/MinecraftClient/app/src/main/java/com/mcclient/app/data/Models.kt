package com.mcclient.app.data

import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object PackMode {
    const val ASK = 0
    const val ACCEPT = 1
    const val DECLINE = 2
}

/** A command that is sent automatically [delaySec] seconds after joining (after auto-login if enabled). */
data class StartupCommand(val command: String, val delaySec: Int)

data class ServerEntry(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    val address: String = "",
    val username: String = "",
    val autoLogin: Boolean = false,
    val password: String = "",
    val autoRejoin: Boolean = false,
    val packMode: Int = PackMode.ASK,
    val commands: List<StartupCommand> = emptyList()
)

fun ServerEntry.toJson(): JSONObject {
    val cmds = JSONArray()
    for (c in commands) cmds.put(JSONObject().put("c", c.command).put("d", c.delaySec))
    return JSONObject()
        .put("id", id).put("name", name).put("address", address).put("username", username)
        .put("autoLogin", autoLogin).put("password", password).put("autoRejoin", autoRejoin)
        .put("packMode", packMode).put("commands", cmds)
}

fun serverFromJson(o: JSONObject): ServerEntry {
    val list = ArrayList<StartupCommand>()
    val arr = o.optJSONArray("commands")
    if (arr != null) for (i in 0 until arr.length()) {
        val c = arr.getJSONObject(i)
        list.add(StartupCommand(c.optString("c", ""), c.optInt("d", 0)))
    }
    return ServerEntry(
        id = o.optString("id", UUID.randomUUID().toString()),
        name = o.optString("name", ""),
        address = o.optString("address", ""),
        username = o.optString("username", ""),
        autoLogin = o.optBoolean("autoLogin", false),
        password = o.optString("password", ""),
        autoRejoin = o.optBoolean("autoRejoin", false),
        packMode = o.optInt("packMode", PackMode.ASK),
        commands = list
    )
}

class ServerStore(private val sp: SharedPreferences) {
    val list = mutableStateListOf<ServerEntry>()

    init {
        try {
            val a = JSONArray(sp.getString("servers", "[]"))
            for (i in 0 until a.length()) list.add(serverFromJson(a.getJSONObject(i)))
        } catch (e: Exception) { /* start empty */ }
    }

    private fun save() {
        val a = JSONArray()
        for (s in list) a.put(s.toJson())
        sp.edit().putString("servers", a.toString()).apply()
    }

    fun upsert(s: ServerEntry) {
        val i = list.indexOfFirst { it.id == s.id }
        if (i >= 0) list[i] = s else list.add(s)
        save()
    }

    fun delete(id: String) {
        list.removeAll { it.id == id }
        save()
    }

    fun find(id: String): ServerEntry? = list.firstOrNull { it.id == id }
}

class Prefs(private val sp: SharedPreferences) {
    var serverListMode by mutableStateOf(sp.getBoolean("server_list_mode", false)); private set
    var username by mutableStateOf(sp.getString("username", "") ?: ""); private set
    var lastAddress by mutableStateOf(sp.getString("last_address", "") ?: ""); private set
    var autoRespawn by mutableStateOf(sp.getBoolean("auto_respawn", true)); private set
    var chatScale by mutableFloatStateOf(sp.getFloat("chat_scale", 1f)); private set
    var persianPx by mutableIntStateOf(sp.getInt("persian_px", 10)); private set
    var onboardingDone by mutableStateOf(sp.getBoolean("onboarding_done", false)); private set
    var physics by mutableStateOf(sp.getBoolean("physics", true)); private set
    var navMaxFall by mutableIntStateOf(sp.getInt("nav_max_fall", 3)); private set
    var navJump by mutableStateOf(sp.getBoolean("nav_jump", true)); private set
    var navDiagonal by mutableStateOf(sp.getBoolean("nav_diag", true)); private set
    var navSprint by mutableStateOf(sp.getBoolean("nav_sprint", false)); private set
    var navArrive by mutableFloatStateOf(sp.getFloat("nav_arrive", 1f)); private set
    var navStuck by mutableIntStateOf(sp.getInt("nav_stuck", 6)); private set
    var navBreak by mutableStateOf(sp.getBoolean("nav_break", false)); private set
    var navPlace by mutableStateOf(sp.getBoolean("nav_place", false)); private set
    var navSwim by mutableStateOf(sp.getBoolean("nav_swim", true)); private set
    var navClimb by mutableStateOf(sp.getBoolean("nav_climb", true)); private set
    var navDoors by mutableStateOf(sp.getBoolean("nav_doors", true)); private set
    var navBreakPenalty by mutableFloatStateOf(sp.getFloat("nav_break_penalty", 2f)); private set
    var autoEat by mutableStateOf(sp.getBoolean("auto_eat", false)); private set

    fun setServerListMode(v: Boolean) { serverListMode = v; sp.edit().putBoolean("server_list_mode", v).apply() }
    fun setUsername(v: String) { username = v; sp.edit().putString("username", v).apply() }
    fun setLastAddress(v: String) { lastAddress = v; sp.edit().putString("last_address", v).apply() }
    fun setAutoRespawn(v: Boolean) { autoRespawn = v; sp.edit().putBoolean("auto_respawn", v).apply() }
    fun setChatScale(v: Float) { chatScale = v; sp.edit().putFloat("chat_scale", v).apply() }
    fun setPersianPx(v: Int) { persianPx = v; sp.edit().putInt("persian_px", v).apply() }
    fun setPhysics(v: Boolean) { physics = v; sp.edit().putBoolean("physics", v).apply() }
    fun setNavMaxFall(v: Int) { navMaxFall = v; sp.edit().putInt("nav_max_fall", v).apply() }
    fun setNavJump(v: Boolean) { navJump = v; sp.edit().putBoolean("nav_jump", v).apply() }
    fun setNavDiagonal(v: Boolean) { navDiagonal = v; sp.edit().putBoolean("nav_diag", v).apply() }
    fun setNavSprint(v: Boolean) { navSprint = v; sp.edit().putBoolean("nav_sprint", v).apply() }
    fun setNavArrive(v: Float) { navArrive = v; sp.edit().putFloat("nav_arrive", v).apply() }
    fun setNavBreak(v: Boolean) { navBreak = v; sp.edit().putBoolean("nav_break", v).apply() }
    fun setNavPlace(v: Boolean) { navPlace = v; sp.edit().putBoolean("nav_place", v).apply() }
    fun setNavSwim(v: Boolean) { navSwim = v; sp.edit().putBoolean("nav_swim", v).apply() }
    fun setNavClimb(v: Boolean) { navClimb = v; sp.edit().putBoolean("nav_climb", v).apply() }
    fun setNavDoors(v: Boolean) { navDoors = v; sp.edit().putBoolean("nav_doors", v).apply() }
    fun setNavBreakPenalty(v: Float) { navBreakPenalty = v; sp.edit().putFloat("nav_break_penalty", v).apply() }
    fun setAutoEat(v: Boolean) { autoEat = v; sp.edit().putBoolean("auto_eat", v).apply() }

    /** Waypoints per server key ("host:port"): name -> x,y,z, stored as one JSON object per server. */
    fun waypoints(server: String): Map<String, IntArray> {
        val out = LinkedHashMap<String, IntArray>()
        try {
            val o = org.json.JSONObject(sp.getString("waypoints_" + server, "{}") ?: "{}")
            val it = o.keys()
            while (it.hasNext()) {
                val k = it.next()
                val a = o.getJSONArray(k)
                out[k] = intArrayOf(a.getInt(0), a.getInt(1), a.getInt(2))
            }
        } catch (e: Exception) { /* corrupt entry: start empty */ }
        return out
    }

    fun saveWaypoints(server: String, points: Map<String, IntArray>) {
        val o = org.json.JSONObject()
        for ((k, v) in points) o.put(k, org.json.JSONArray(listOf(v[0], v[1], v[2])))
        sp.edit().putString("waypoints_" + server, o.toString()).apply()
    }

    fun setNavStuck(v: Int) { navStuck = v; sp.edit().putInt("nav_stuck", v).apply() }
    fun setOnboardingDone() { onboardingDone = true; sp.edit().putBoolean("onboarding_done", true).apply() }

    // Sent-message history (used by the previous/next message buttons).
    private val hist = ArrayList<String>()

    init {
        try {
            val a = JSONArray(sp.getString("history", "[]"))
            for (i in 0 until a.length()) hist.add(a.getString(i))
        } catch (e: Exception) { /* empty */ }
    }

    fun history(): List<String> = ArrayList(hist)

    fun addHistory(s: String) {
        if (s.isBlank()) return
        if (hist.isNotEmpty() && hist.last() == s) return
        hist.add(s)
        while (hist.size > 100) hist.removeAt(0)
        val a = JSONArray()
        for (h in hist) a.put(h)
        sp.edit().putString("history", a.toString()).apply()
    }
}
