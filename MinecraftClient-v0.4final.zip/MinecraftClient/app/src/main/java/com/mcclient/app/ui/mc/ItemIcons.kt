package com.mcclient.app.ui.mc

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import com.mcclient.core.Json
import com.mcclient.core.Packs
import java.io.File
import java.util.zip.ZipFile

/** Item textures from the official client assets (flat 16x16 icons); the active server pack overrides them. */
object ItemIcons {
    private val MISSING: Bitmap = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
    private val cache = LruCache<String, Bitmap>(300)

    fun clear() { cache.evictAll(); gui.evictAll() }

    private val gui = LruCache<String, Bitmap>(24)

    /**
     * A GUI texture such as "gui/container/generic_54": from the server's resource pack when it has one, otherwise from the
     * vanilla files extracted from Mojang's jar. Null when neither has it.
     */
    fun texture(ctx: Context, path: String): Bitmap? {
        val packTag = Packs.active?.let { it.path + it.lastModified() } ?: ""
        val key = "$packTag|$path"
        val hit = gui.get(key)
        if (hit != null) return if (hit === MISSING) null else hit
        val opts = BitmapFactory.Options()
        opts.inScaled = false
        var bmp: Bitmap? = null
        val pack = Packs.active
        if (pack != null && pack.exists()) {
            try {
                ZipFile(pack).use { zip ->
                    val e = zip.getEntry("assets/minecraft/textures/$path.png")
                    if (e != null) bmp = zip.getInputStream(e).use { BitmapFactory.decodeStream(it, null, opts) }
                }
            } catch (e: Exception) { /* unreadable pack: use the vanilla file */ }
        }
        if (bmp == null) {
            val f = File(Assets.dir(ctx), "assets/minecraft/textures/$path.png")
            if (f.exists()) bmp = BitmapFactory.decodeFile(f.path, opts)
        }
        gui.put(key, bmp ?: MISSING)
        return bmp
    }

    fun get(ctx: Context, key: String?): Bitmap? {
        if (key == null) return null
        val hit = cache.get(key)
        if (hit != null) return if (hit === MISSING) null else hit
        val bmp = load(ctx, key)
        cache.put(key, bmp ?: MISSING)
        return bmp
    }

    private val SUFFIXES = listOf("", "_front", "_top", "_side", "_0")
    private val FOLDERS = listOf("item", "block")

    private fun load(ctx: Context, key: String): Bitmap? {
        val opts = BitmapFactory.Options()
        opts.inScaled = false
        // 1) resource pack of the server
        val pack = Packs.active
        if (pack != null && pack.exists()) {
            try {
                ZipFile(pack).use { zip ->
                    for (folder in FOLDERS) for (suf in SUFFIXES) {
                        val e = zip.getEntry("assets/minecraft/textures/$folder/$key$suf.png")
                        if (e != null) {
                            val b = zip.getInputStream(e).use { BitmapFactory.decodeStream(it, null, opts) }
                            if (b != null) return b
                        }
                    }
                }
            } catch (e: Exception) { /* not a readable zip: fall back to the base assets */ }
        }
        // 2) vanilla assets downloaded from Mojang
        val base = File(Assets.dir(ctx), "assets/minecraft/textures")
        for (folder in FOLDERS) for (suf in SUFFIXES) {
            val f = File(base, "$folder/$key$suf.png")
            if (f.exists()) {
                val b = BitmapFactory.decodeFile(f.path, opts)
                if (b != null) return b
            }
        }
        return null
    }
}

/** Display names from the official en_us language file; falls back to a prettified registry name. */
object ItemNames {
    @Volatile private var lang: Map<String, Any?>? = null

    @Suppress("UNCHECKED_CAST")
    private fun lang(ctx: Context): Map<String, Any?> {
        lang?.let { return it }
        val f = File(Assets.dir(ctx), "assets/minecraft/lang/en_us.json")
        val m: Map<String, Any?> = try {
            if (f.exists()) Json.parse(f.readText()) as Map<String, Any?> else emptyMap()
        } catch (e: Exception) { emptyMap() }
        lang = m
        return m
    }

    fun reset() { lang = null }

    fun display(ctx: Context, key: String?, id: Int): String {
        if (key == null) return "#$id"
        val l = lang(ctx)
        val v = l["item.minecraft.$key"] ?: l["block.minecraft.$key"]
        if (v is String) return v
        return key.split('_').joinToString(" ") { w -> w.replaceFirstChar { it.uppercase() } }
    }
}
