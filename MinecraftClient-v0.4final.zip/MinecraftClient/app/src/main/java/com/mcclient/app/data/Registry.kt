package com.mcclient.app.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.mcclient.core.Data
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Item and block-state ids of 1.20.4. They are not contained in the client jar, so they are fetched once from
 * the minecraft-data project and cached. Without them the app still works: items show as "#id" and the path finder
 * treats every non-air block as solid.
 */
object Registry {
    @Volatile var items: Data.Items? = null
    @Volatile var blocks: Data.Blocks? = null
    /** Mob effect ids {jump_boost, levitation, slow_falling, dolphins_grace} from effects.json of the running version, if downloaded. */
    @Volatile var effects: IntArray? = null
    /** True once real collision shapes (blockCollisionShapes.json) passed the sanity checks. */
    @Volatile var shapesLoaded: Boolean = false
    var status by mutableStateOf("")
    var busy by mutableStateOf(false)
    @Volatile var autoStarted = false

    private val BASES = listOf("1.20.3", "1.20.4", "1.20.2", "1.20")
    private const val ROOT = "https://raw.githubusercontent.com/PrismarineJS/minecraft-data/master/data/pc/"

    private fun dir(ctx: Context) = File(ctx.filesDir, "mcdata")
    val ready: Boolean get() = items != null && blocks != null

    fun load(ctx: Context) {
        try { val f = File(dir(ctx), "items.json"); if (f.exists()) items = Data.Items.parse(f.readText()) } catch (e: Exception) { items = null }
        try { val f = File(dir(ctx), "blocks.json"); if (f.exists()) blocks = Data.Blocks.parse(f.readText()) } catch (e: Exception) { blocks = null }
        shapesLoaded = false
        try {
            val f = File(dir(ctx), "shapes.json")
            val b = blocks
            if (f.exists() && b != null) shapesLoaded = b.loadShapes(f.readText()) == null
        } catch (e: Exception) { shapesLoaded = false }
        try { val f = File(dir(ctx), "effects.json"); if (f.exists()) effects = parseEffects(f.readText()) } catch (e: Exception) { effects = null }
    }

    /** minecraft-data effects.json: [{"id":8,"name":"JumpBoost",...}, ...] -> ids of the effects the physics needs (null if one is missing). */
    fun parseEffects(text: String): IntArray? {
        val a = org.json.JSONArray(text)
        val want = listOf("jumpboost", "levitation", "slowfalling", "dolphinsgrace")
        val ids = IntArray(4) { -1 }
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val n = o.optString("name").replace("_", "").lowercase()
            val k = want.indexOf(n)
            if (k >= 0) ids[k] = o.getInt("id")
        }
        return if (ids.any { it < 0 }) null else ids
    }

    /**
     * Candidate data folders for 1.20.4, best first: what dataPaths.json says for each file, then the usual folder names.
     * (The folder of a file differs per data set, e.g. blockCollisionShapes may live in an older version's folder.)
     */
    private fun folders(file: String): List<String> {
        val out = ArrayList<String>()
        try {
            val dp = org.json.JSONObject(get("https://raw.githubusercontent.com/PrismarineJS/minecraft-data/master/data/dataPaths.json"))
            val v = dp.getJSONObject("pc").getJSONObject("1.20.4")
            val key = file.removeSuffix(".json")
            if (v.has(key)) out.add(v.getString(key).removePrefix("pc/"))
        } catch (e: Exception) { /* offline or format changed: use the fallback list */ }
        for (b in BASES) if (b !in out) out.add(b)
        return out
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        try { return c.inputStream.use { String(it.readBytes(), Charsets.UTF_8) } } finally { c.disconnect() }
    }

    /** Blocking; run on a background thread. */
    fun download(ctx: Context) {
        if (busy) return
        busy = true
        try {
            dir(ctx).mkdirs()
            status = "در حال دریافت لیست آیتم‌ها و بلاک‌ها…"
            var okItems = false
            var okBlocks = false
            for (v in BASES) {
                if (!okItems) try {
                    val t = get("$ROOT$v/items.json")
                    if (Data.Items.parse(t).size() > 500) { File(dir(ctx), "items.json").writeText(t); okItems = true }
                } catch (e: Exception) { /* try the next folder */ }
                if (!okBlocks) try {
                    val t = get("$ROOT$v/blocks.json")
                    if ("stone" == Data.Blocks.parse(t).nameOf(1)) { File(dir(ctx), "blocks.json").writeText(t); okBlocks = true }
                } catch (e: Exception) { /* try the next folder */ }
                if (okItems && okBlocks) break
            }
            load(ctx)
            val b = blocks
            if (b != null) {
                // collision shapes: tried in several folders and accepted only when they match the block registry
                status = "در حال دریافت شکل‌های برخورد بلاک‌ها…"
                for (v in folders("blockCollisionShapes.json")) {
                    try {
                        val t = get("$ROOT$v/blockCollisionShapes.json")
                        if (b.loadShapes(t) == null) { File(dir(ctx), "shapes.json").writeText(t); shapesLoaded = true; break }
                    } catch (e: Exception) { /* next folder */ }
                }
            }
            for (v in folders("effects.json")) {
                try {
                    val t = get("$ROOT$v/effects.json")
                    if (parseEffects(t) != null) { File(dir(ctx), "effects.json").writeText(t); effects = parseEffects(t); break }
                } catch (e: Exception) { /* next folder */ }
            }
            status = if (ready) "داده‌های آیتم و بلاک آماده است" + (if (shapesLoaded) " (با شکل‌های برخورد)" else " (شکل برخورد دانلود نشد؛ بلاک‌ها مکعب کامل فرض می‌شوند)") else "دریافت داده‌ها ناموفق بود (اینترنت را بررسی کنید)"
        } catch (e: Exception) {
            status = "خطا: ${e.message ?: e.javaClass.simpleName}"
        } finally {
            busy = false
        }
    }
}
