package com.mcclient.core;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

/** Packet byte buffers (writer/reader) for the Minecraft Java protocol. */
public final class Buf {
    private Buf() {}

    /** Thrown when a packet body cannot be parsed; the session skips such packets. */
    public static class ParseEx extends RuntimeException {
        private static final long serialVersionUID = 1L;
        public ParseEx(String m) { super(m); }
    }

    public static final class Writer {
        private final ByteArrayOutputStream out = new ByteArrayOutputStream();

        public Writer b(int v) { out.write(v & 0xFF); return this; }
        public Writer bool(boolean v) { return b(v ? 1 : 0); }
        public Writer s16(int v) { out.write((v >> 8) & 0xFF); out.write(v & 0xFF); return this; }
        public Writer i32(int v) { out.write((v >> 24) & 0xFF); out.write((v >> 16) & 0xFF); out.write((v >> 8) & 0xFF); out.write(v & 0xFF); return this; }
        public Writer i64(long v) { for (int s = 56; s >= 0; s -= 8) out.write((int) ((v >> s) & 0xFF)); return this; }
        public Writer f32(float v) { return i32(Float.floatToIntBits(v)); }
        public Writer f64(double v) { return i64(Double.doubleToLongBits(v)); }
        public Writer varInt(int value) {
            int v = value;
            while (true) {
                if ((v & ~0x7F) == 0) { out.write(v); return this; }
                out.write((v & 0x7F) | 0x80);
                v >>>= 7;
            }
        }
        public Writer varLong(long value) {
            long v = value;
            while (true) {
                if ((v & ~0x7FL) == 0) { out.write((int) v); return this; }
                out.write((int) ((v & 0x7F) | 0x80));
                v >>>= 7;
            }
        }
        public Writer str(String s) {
            byte[] bytes = s.getBytes(StandardCharsets.UTF_8);
            varInt(bytes.length);
            out.write(bytes, 0, bytes.length);
            return this;
        }
        public Writer uuid(UUID u) { return i64(u.getMostSignificantBits()).i64(u.getLeastSignificantBits()); }
        public Writer bytes(byte[] b) { out.write(b, 0, b.length); return this; }
        public Writer nbt(Object tag) { Nbt.writeNetwork(this, tag); return this; }
        public byte[] toBytes() { return out.toByteArray(); }
    }

    public static final class Reader {
        private final byte[] buf;
        public int pos;
        private final int end;

        public Reader(byte[] buf) { this(buf, 0, buf.length); }
        public Reader(byte[] buf, int pos, int end) { this.buf = buf; this.pos = pos; this.end = end; }

        public int remaining() { return end - pos; }
        public int u8() {
            if (pos >= end) throw new ParseEx("eof");
            return buf[pos++] & 0xFF;
        }
        public int i8() { return (byte) u8(); }
        public boolean bool() { return u8() != 0; }
        public int u16() { return (u8() << 8) | u8(); }
        public int s16() { return (short) u16(); }
        public int i32() { return (u8() << 24) | (u8() << 16) | (u8() << 8) | u8(); }
        public long i64() { long hi = i32(); long lo = i32() & 0xFFFFFFFFL; return (hi << 32) | lo; }
        public float f32() { return Float.intBitsToFloat(i32()); }
        public double f64() { return Double.longBitsToDouble(i64()); }
        public int varInt() {
            int r = 0, shift = 0;
            while (true) {
                int b = u8();
                r |= (b & 0x7F) << shift;
                if ((b & 0x80) == 0) return r;
                shift += 7;
                if (shift > 35) throw new ParseEx("varint too long");
            }
        }
        public long varLong() {
            long r = 0;
            int shift = 0;
            while (true) {
                int b = u8();
                r |= ((long) (b & 0x7F)) << shift;
                if ((b & 0x80) == 0) return r;
                shift += 7;
                if (shift > 70) throw new ParseEx("varlong too long");
            }
        }
        public void skip(int n) {
            if (n < 0 || pos + n > end) throw new ParseEx("skip out of range");
            pos += n;
        }
        public byte[] bytes(int n) {
            if (n < 0 || pos + n > end) throw new ParseEx("bytes out of range");
            byte[] r = new byte[n];
            System.arraycopy(buf, pos, r, 0, n);
            pos += n;
            return r;
        }
        public String str() {
            int n = varInt();
            if (n < 0 || pos + n > end) throw new ParseEx("string out of range");
            String s = new String(buf, pos, n, StandardCharsets.UTF_8);
            pos += n;
            return s;
        }
        public UUID uuid() { long a = i64(); long b = i64(); return new UUID(a, b); }
        public Object nbt() { return Nbt.readNetwork(this); }
    }
}
