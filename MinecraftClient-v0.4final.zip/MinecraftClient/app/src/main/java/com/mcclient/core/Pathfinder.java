package com.mcclient.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

/**
 * A* over standing cells, ported from Baritone's approach: goals ({@link Goals}) decide when to stop and estimate the rest,
 * every move costs game ticks from {@link ActionCosts}. Moves: walk, diagonal, step up 1, fall, swim, climb ladders/vines,
 * open doors and — when enabled in {@link NavConfig} — dig through blocks, dig down, bridge gaps and pillar up.
 */
public final class Pathfinder {
    private Pathfinder() {}

    public enum Kind { WALK, JUMP, FALL, SWIM, CLIMB, DIG_DOWN, PILLAR }

    /** One move of the path with the work that has to be done before/while making it. */
    public static final class Step {
        public final int x, y, z;
        public final Kind kind;
        public final List<int[]> breaks = new ArrayList<>();  // cells to dig first
        public final List<int[]> opens = new ArrayList<>();   // closed doors/gates to open first
        public int[] place;                                    // {x,y,z of the new block, support x,y,z, face}
        Step(int x, int y, int z, Kind k) { this.x = x; this.y = y; this.z = z; this.kind = k; }
        public boolean needsWork() { return !breaks.isEmpty() || !opens.isEmpty() || place != null; }
    }

    public static final class Result {
        public final List<int[]> path;   // feet cells after the start cell
        public final List<Step> steps;   // same length, with the work needed for each
        public final boolean complete;   // reached the goal (otherwise: closest reachable cell)
        public final int expanded;
        Result(List<Step> steps, boolean c, int e) {
            this.steps = steps; complete = c; expanded = e;
            path = new ArrayList<>();
            for (Step s : steps) path.add(new int[]{s.x, s.y, s.z});
        }
    }

    private static final class Node {
        final int x, y, z;
        double g, f;
        Node parent;
        Step via;
        boolean closed;
        Node(int x, int y, int z) { this.x = x; this.y = y; this.z = z; }
    }

    private static long key(int x, int y, int z) {
        return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | ((y + 2048) & 0xFFF);
    }

    /** Cost of the body occupying a cell: -1 impossible, 0 free, > 0 needs swimming/opening/digging (recorded in {@code st}). */
    private static double occ(World w, NavConfig c, int x, int y, int z, Step st) {
        if (w.get(x, y, z) < 0) return -1;
        if (w.passable(x, y, z)) return 0;
        if (w.water(x, y, z)) return c.allowSwim ? 0.0 : -1;
        if (w.lava(x, y, z)) return -1;
        if (c.openDoors && w.closedDoor(x, y, z)) { st.opens.add(new int[]{x, y, z}); return OPEN_DOOR_COST; }
        if (c.allowBreak && w.breakable(x, y, z)) { st.breaks.add(new int[]{x, y, z}); return breakCost(w, c, x, y, z); }
        return -1;
    }

    private static double breakCost(World w, NavConfig c, int x, int y, int z) {
        double h = Math.max(0, w.hardness(x, y, z));
        return h * 30.0 + c.breakPenalty; // hand-speed ticks plus Baritone's blockBreakAdditionalPenalty
    }

    /** Ticks spent opening a door or gate (right click + the swing). */
    static final double OPEN_DOOR_COST = 10;

    private static final int[][] CARD = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    private static final int[][] DIAG = {{1, 1}, {1, -1}, {-1, 1}, {-1, -1}};

    private static int faceOf(int dx, int dy, int dz) {
        if (dy > 0) return 1;
        if (dy < 0) return 0;
        if (dx > 0) return 5;
        if (dx < 0) return 4;
        return dz > 0 ? 3 : 2;
    }

    /** Compatibility entry point used by the older actions: a cell (or column with {@code ignoreY}) with an optional radius. */
    public static Result find(World w, int sx, int sy, int sz, int gx, int gy, int gz, boolean ignoreY, double radius, NavConfig cfg) {
        Goals.Goal g;
        if (ignoreY) g = radius <= 0 ? new Goals.GoalXZ(gx, gz) : new Goals.GoalXZNear(gx, gz, radius);
        else g = radius < 1 ? new Goals.GoalBlock(gx, gy, gz) : new Goals.GoalNear(gx, gy, gz, (int) Math.floor(radius));
        return find(w, sx, sy, sz, g, cfg);
    }

    private static double walkCost(NavConfig c) { return c.sprint ? ActionCosts.SPRINT_ONE_BLOCK_COST : ActionCosts.WALK_ONE_BLOCK_COST; }

    /** Cost of stepping onto the floor block at (x, y-1, z): soul sand is much slower. */
    private static double floorWalk(World w, NavConfig c, int x, int y, int z) {
        String n = w.blockName(x, y - 1, z);
        return "soul_sand".equals(n) ? ActionCosts.WALK_ONE_OVER_SOUL_SAND_COST : walkCost(c);
    }

    /** A* from the start cell to any cell accepted by {@code goal}; if the goal is unreachable the path leads to the closest cell. */
    public static Result find(World w, int sx, int sy, int sz, Goals.Goal goal, NavConfig cfg) {
        Map<Long, Node> nodes = new HashMap<>();
        PriorityQueue<Node> open = new PriorityQueue<>((a, b) -> Double.compare(a.f, b.f));
        Node start = new Node(sx, sy, sz);
        start.f = goal.heuristic(sx, sy, sz);
        nodes.put(key(sx, sy, sz), start);
        open.add(start);
        Node best = start;
        double bestH = start.f;
        int expanded = 0;
        final double jump = Math.max(ActionCosts.JUMP_ONE_BLOCK_COST, ActionCosts.WALK_ONE_BLOCK_COST) + cfg.jumpPenalty;

        while (!open.isEmpty() && expanded < cfg.maxNodes) {
            Node cur = open.poll();
            if (cur.closed) continue;
            cur.closed = true;
            expanded++;
            if (goal.isInGoal(cur.x, cur.y, cur.z)) return new Result(build(cur), true, expanded);
            double hh = goal.heuristic(cur.x, cur.y, cur.z);
            if (hh < bestH) { bestH = hh; best = cur; }

            int x = cur.x, y = cur.y, z = cur.z;
            boolean wet = w.water(x, y, z), climbing = w.climbable(x, y, z);

            for (int[] d : CARD) {
                int nx = x + d[0], nz = z + d[1];
                boolean walked = false;
                Step st = new Step(nx, y, nz, Kind.WALK);
                double c1 = occ(w, cfg, nx, y, nz, st), c2 = occ(w, cfg, nx, y + 1, nz, st);
                if (c1 >= 0 && c2 >= 0) {
                    boolean swim = w.water(nx, y, nz), climb = w.climbable(nx, y, nz);
                    if (swim && cfg.allowSwim) {
                        Step s2 = copyWork(st, nx, y, nz, Kind.SWIM);
                        relax(nodes, open, cur, s2, ActionCosts.WALK_ONE_IN_WATER_COST + c1 + c2, goal);
                        walked = s2.breaks.isEmpty();
                    } else if (climb && cfg.allowClimb) {
                        Step s2 = copyWork(st, nx, y, nz, Kind.CLIMB);
                        relax(nodes, open, cur, s2, walkCost(cfg) + c1 + c2, goal);
                        walked = s2.breaks.isEmpty();
                    } else if (w.standable(nx, y - 1, nz)) {
                        relax(nodes, open, cur, st, floorWalk(w, cfg, nx, y, nz) + c1 + c2, goal);
                        walked = st.breaks.isEmpty();
                    } else if (c1 == 0 && c2 == 0) {
                        // no floor: fall...
                        boolean fell = false;
                        for (int dd = 1; dd <= cfg.maxFall; dd++) {
                            int ny = y - dd;
                            double fall = ActionCosts.WALK_OFF_BLOCK_COST + ActionCosts.FALL_N_BLOCKS_COST[dd] + ActionCosts.CENTER_AFTER_FALL_COST;
                            if (cfg.allowSwim && w.water(nx, ny, nz)) {
                                relax(nodes, open, cur, new Step(nx, ny, nz, Kind.FALL), fall, goal);
                                fell = true;
                                break;
                            }
                            if (!w.passable(nx, ny, nz)) break;
                            if (w.standable(nx, ny - 1, nz)) {
                                if (w.canStand(nx, ny, nz)) { relax(nodes, open, cur, new Step(nx, ny, nz, Kind.FALL), fall, goal); fell = true; }
                                break;
                            }
                        }
                        // ...or bridge over the gap
                        if (!fell && cfg.allowPlace && cfg.hasThrowaway && !wet && supported(w, cur, x, y, z) && w.passable(nx, y - 1, nz)) {
                            Step bs = new Step(nx, y, nz, Kind.WALK);
                            bs.place = new int[]{nx, y - 1, nz, x, y - 1, z, faceOf(d[0], 0, d[1])};
                            relax(nodes, open, cur, bs, walkCost(cfg) + cfg.blockPlacementPenalty, goal);
                        }
                    }
                }
                // step up one block
                if (cfg.allowJump && !walked) {
                    Step js = new Step(nx, y + 1, nz, Kind.JUMP);
                    double j0 = occ(w, cfg, x, y + 2, z, js), j1 = occ(w, cfg, nx, y + 1, nz, js), j2 = occ(w, cfg, nx, y + 2, nz, js);
                    if (j0 >= 0 && j1 >= 0 && j2 >= 0 && w.standable(nx, y, nz)) {
                        relax(nodes, open, cur, js, jump + j0 + j1 + j2, goal);
                    }
                }
            }

            if (cfg.allowDiagonal) {
                for (int[] d : DIAG) {
                    int nx = x + d[0], nz = z + d[1];
                    if (w.passable(x + d[0], y, z) && w.passable(x + d[0], y + 1, z) && w.passable(x, y, z + d[1]) && w.passable(x, y + 1, z + d[1])
                        && w.canStand(nx, y, nz)) {
                        relax(nodes, open, cur, new Step(nx, y, nz, Kind.WALK), floorWalk(w, cfg, nx, y, nz) * Math.sqrt(2.0), goal);
                    }
                }
            }

            // vertical moves in water and on ladders
            if ((wet && cfg.allowSwim) || (climbing && cfg.allowClimb)) {
                Step up = new Step(x, y + 1, z, wet ? Kind.SWIM : Kind.CLIMB);
                boolean target = (cfg.allowSwim && w.water(x, y + 1, z)) || (cfg.allowClimb && w.climbable(x, y + 1, z));
                if (target && occ(w, cfg, x, y + 2, z, up) >= 0 && up.breaks.isEmpty()) {
                    relax(nodes, open, cur, up, wet ? ActionCosts.WALK_ONE_IN_WATER_COST : ActionCosts.LADDER_UP_ONE_COST, goal);
                }
                boolean below = (cfg.allowSwim && w.water(x, y - 1, z)) || (cfg.allowClimb && w.climbable(x, y - 1, z));
                if (below) relax(nodes, open, cur, new Step(x, y - 1, z, wet ? Kind.SWIM : Kind.CLIMB), wet ? ActionCosts.WALK_ONE_IN_WATER_COST : ActionCosts.LADDER_DOWN_ONE_COST, goal);
            }

            // dig straight down (floor block removed, then we drop one block)
            if (cfg.allowBreak && !wet && w.standable(x, y - 1, z) && w.breakable(x, y - 1, z) && w.standable(x, y - 2, z)) {
                Step ds = new Step(x, y - 1, z, Kind.DIG_DOWN);
                ds.breaks.add(new int[]{x, y - 1, z});
                relax(nodes, open, cur, ds, ActionCosts.FALL_N_BLOCKS_COST[1] + breakCost(w, cfg, x, y - 1, z), goal);
            }

            // pillar up with a placed block
            if (cfg.allowPlace && cfg.hasThrowaway && !wet && supported(w, cur, x, y, z)) {
                Step ps = new Step(x, y + 1, z, Kind.PILLAR);
                double p = occ(w, cfg, x, y + 2, z, ps);
                if (p >= 0 && w.passable(x, y + 1, z)) {
                    ps.place = new int[]{x, y, z, x, y - 1, z, 1};
                    relax(nodes, open, cur, ps, ActionCosts.JUMP_ONE_BLOCK_COST + cfg.blockPlacementPenalty + p, goal);
                }
            }
        }
        if (best == start) return new Result(new ArrayList<Step>(), false, expanded);
        return new Result(build(best), false, expanded);
    }

    /** The cell under (x,y,z) holds us: a real solid block, or the block this very path placed in the previous step. */
    private static boolean supported(World w, Node cur, int x, int y, int z) {
        if (w.standable(x, y - 1, z)) return true;
        int[] p = cur.via == null ? null : cur.via.place;
        return p != null && p[0] == x && p[1] == y - 1 && p[2] == z;
    }

    private static Step copyWork(Step from, int x, int y, int z, Kind k) {
        Step s = new Step(x, y, z, k);
        s.breaks.addAll(from.breaks);
        s.opens.addAll(from.opens);
        return s;
    }

    private static void relax(Map<Long, Node> nodes, PriorityQueue<Node> open, Node from, Step st, double cost, Goals.Goal goal) {
        long k = key(st.x, st.y, st.z);
        Node n = nodes.get(k);
        double g = from.g + cost;
        if (n == null) {
            n = new Node(st.x, st.y, st.z);
            nodes.put(k, n);
        } else if (n.closed || g >= n.g) {
            return;
        }
        n.g = g;
        n.parent = from;
        n.via = st;
        n.f = g + goal.heuristic(st.x, st.y, st.z);
        open.add(n);
    }

    private static List<Step> build(Node end) {
        List<Step> p = new ArrayList<>();
        for (Node n = end; n.parent != null; n = n.parent) p.add(n.via);
        Collections.reverse(p);
        return p;
    }
}
