package com.mcclient.app.ui.mc

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalDensity
import com.mcclient.app.Core
import com.mcclient.app.game.ChatSpan
import kotlin.math.roundToInt

/** Size of one Minecraft "game pixel" in screen pixels. */
@Composable
fun mcUnit(): Int {
    val d = LocalDensity.current.density
    val u = (d * 1.6f * Core.prefs.chatScale).roundToInt()
    return if (u < 2) 2 else u
}

@Composable
fun McText(
    spans: List<ChatSpan>,
    modifier: Modifier = Modifier,
    alignEnd: Boolean = false,
    /** Called with the tapped span (clickEvent / hoverEvent live on it); null when the tap hit no text. */
    onTap: ((ChatSpan?) -> Unit)? = null,
    onLongPress: ((ChatSpan?) -> Unit)? = null
) {
    val density = LocalDensity.current
    val unit = mcUnit()
    val ver = McFont.version
    BoxWithConstraints(modifier) {
        val widthPx = if (constraints.hasBoundedWidth) constraints.maxWidth else (300 * density.density).toInt()
        val gp = widthPx / unit
        val layout = remember(spans, gp, ver, unit) { McLayout.build(spans, gp) }
        val h = with(density) { (layout.heightGp * unit).toDp() }
        val shiftGp = if (alignEnd) maxOf(0, gp - McLayout.contentWidth(layout)) else 0
        val tapMod = if (onTap == null && onLongPress == null) Modifier else Modifier.pointerInput(layout, unit, shiftGp) {
            detectTapGestures(
                onTap = { o -> onTap?.invoke(McLayout.hit(layout, o.x / unit, o.y / unit, shiftGp)) },
                onLongPress = { o -> onLongPress?.invoke(McLayout.hit(layout, o.x / unit, o.y / unit, shiftGp)) }
            )
        }
        Canvas(Modifier.fillMaxWidth().height(h).then(tapMod)) {
            val shift = shiftGp
            drawIntoCanvas { c -> McLayout.draw(c.nativeCanvas, layout, unit, shift) }
        }
    }
}
