package com.mcclient.app.game

import android.content.Context
import com.mcclient.app.Core
import com.mcclient.app.data.Registry
import com.mcclient.app.data.ServerEntry
import com.mcclient.app.ui.mc.ItemIcons
import com.mcclient.app.ui.mc.McFont
import com.mcclient.core.Actions
import com.mcclient.core.ClientSession
import com.mcclient.core.Goals
import com.mcclient.core.Inventory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.File
import java.util.concurrent.atomic.AtomicLong

enum class Status { IDLE, CONNECTING, ONLINE, WAITING_RECONNECT }

/** One inventory slot as the UI sees it (immutable). */
class InvSlot(
    val id: Int,
    val count: Int,
    val key: String?,
    val name: List<ChatSpan>?,
    val lore: List<List<ChatSpan>>
)

class InvView(
    val windowId: Int,
    val title: List<ChatSpan>,
    val slots: List<InvSlot?>,
    val cursor: InvSlot?,
    val held: Int,
    val playerStart: Int,
    val container: Boolean,
    /** Menu type id (see MenuLayouts) or -1 for the player's own inventory. */
    val type: Int = -1,
    /** Set Container Property values (enchanting costs, furnace progress...). */
    val props: Map<Int, Int> = emptyMap()
)

data class SessionState(
    val status: Status = Status.IDLE,
    val serverName: String = "",
    val info: String = "",
    val health: Float = 20f,
    val food: Int = 20,
    val reconnectIn: Int = 0,
    val actionBar: List<ChatSpan> = emptyList(),
    val actionBarNonce: Int = 0,
    val players: List<String> = emptyList(),
    val pendingPack: ClientSession.PackOffer? = null,
    val suggestions: ClientSession.Suggestions? = null,
    val actionText: String = "",
    val actionRunning: Boolean = false
)

/**
 * Android-facing wrapper around the pure-Java [ClientSession] (protocol, world, inventory, actions — all unit and
 * integration tested on a JVM). This class only converts events into Compose-friendly state.
 */
class Session(private val ctx: Context) : ClientSession.Listener {
    val core = ClientSession(this)

    private val _state = MutableStateFlow(SessionState())
    val state: StateFlow<SessionState> = _state.asStateFlow()
    private val _chat = MutableStateFlow<List<ChatLine>>(emptyList())
    val chat: StateFlow<List<ChatLine>> = _chat.asStateFlow()
    private val _inv = MutableStateFlow(InvView(0, emptyList(), emptyList(), null, 0, 9, false))
    val inv: StateFlow<InvView> = _inv.asStateFlow()
    private val ids = AtomicLong(0)

    init {
        core.config.packDir = File(ctx.filesDir, "packs")
    }

    // ------------------------------------------------------------------ connection

    fun connect(server: ServerEntry, username: String) {
        _chat.value = emptyList()
        _inv.value = InvView(0, emptyList(), emptyList(), null, 0, 9, false)
        Core.lastEnd = ""
        _state.value = SessionState(status = Status.CONNECTING, serverName = server.name.ifBlank { server.address }, info = "در حال اتصال…")
        applyConfig()
        loadWaypoints(server.address)
        val p = ClientSession.Profile()
        p.name = server.name
        p.address = server.address
        p.username = username
        p.autoLogin = server.autoLogin
        p.password = server.password
        p.autoRejoin = server.autoRejoin
        p.packMode = server.packMode
        for (c in server.commands) p.commands.add(ClientSession.Cmd(c.command, c.delaySec))
        core.connect(p)
    }

    fun disconnect() = core.disconnect()

    /** Pushes the user's settings into the core before a connection starts or when they change. */
    fun applyConfig() {
        val p = Core.prefs
        core.config.autoRespawn = p.autoRespawn
        core.config.physics = p.physics
        val n = core.config.nav
        n.maxFall = p.navMaxFall
        n.allowJump = p.navJump
        n.allowDiagonal = p.navDiagonal
        n.sprint = p.navSprint
        n.arriveDistance = p.navArrive.toDouble()
        n.stuckSeconds = p.navStuck
        n.allowBreak = p.navBreak
        n.allowPlace = p.navPlace
        n.allowSwim = p.navSwim
        n.allowClimb = p.navClimb
        n.openDoors = p.navDoors
        n.breakPenalty = p.navBreakPenalty.toDouble()
        n.autoEat = p.autoEat
        core.inventory.items = Registry.items
        core.world.blocks = Registry.blocks
        Registry.effects?.let { core.setEffectIds(it[0], it[1], it[2], it[3]) }
    }

    // ------------------------------------------------------------------ user actions

    fun sendUserText(text: String): Boolean = core.sendUserText(text)
    fun respawn() = core.respawn()
    fun requestSuggestions(text: String) = core.requestSuggestions(text)
    fun clearSuggestions() { _state.update { it.copy(suggestions = null) } }

    fun answerPack(accept: Boolean) {
        val offer = _state.value.pendingPack ?: return
        _state.update { it.copy(pendingPack = null) }
        core.answerPack(offer, accept)
    }

    fun clickSlot(slot: Int, button: Int, mode: Int) = core.clickSlot(slot, button, mode)
    fun closeWindow() = core.closeWindow()
    fun selectHotbar(i: Int) = core.selectHotbar(i)
    fun leftClick() = core.swing()
    fun rightClick() = core.useItem()
    fun dropHeld(all: Boolean) = core.dropHeld(all)

    fun startGoTo(x: Int, y: Int, z: Int, ignoreY: Boolean) { applyConfig(); core.startAction(Actions.GoTo(x, y, z, ignoreY)) }
    fun startFollow(player: String, keep: Double) { applyConfig(); core.startAction(Actions.Follow(player, keep)) }
    fun startAntiAfk(sec: Int) = core.startAction(Actions.AntiAfk(sec))
    fun startRepeat(text: String, sec: Int) = core.startAction(Actions.RepeatText(text, sec))
    fun startPatrol(points: List<IntArray>, loop: Boolean) { applyConfig(); core.startAction(Actions.Patrol(points, loop)) }
    fun startGoToPlayer(player: String) { applyConfig(); core.startAction(Actions.Follow(player, 2.0, true)) }
    fun startOpenBlock(group: String) { applyConfig(); core.startAction(Actions.OpenBlock(group)) }
    fun startMine(label: String, blocks: Array<String>, count: Int) { applyConfig(); core.startAction(Actions.Mine(label, blocks, count)) }
    fun startExplore() { applyConfig(); core.startAction(Actions.Explore()) }
    fun startFlyTo(x: Double, y: Double, z: Double) { applyConfig(); core.startAction(Actions.FlyTo(x, y, z)) }
    fun startGoToGoal(goal: Goals.Goal, label: String) { applyConfig(); core.startAction(Actions.GoTo(goal, label)) }

    // ---- manual control pad
    fun manualMove(forward: Float, strafe: Float, jump: Boolean, sneak: Boolean, sprint: Boolean) = core.manualMove(forward, strafe, jump, sneak, sprint)
    fun manualTurn(dYaw: Float, dPitch: Float) = core.manualTurn(dYaw, dPitch)
    val isScreenOpen: Boolean get() = core.isScreenOpen()
    val mayFly: Boolean get() = core.mayFly()
    val isFlying: Boolean get() = core.isFlying()
    fun setFlying(on: Boolean) = core.setFlying(on)

    // ---- inventory extras
    fun swapHands() = core.swapHands()
    fun clickButton(id: Int) = core.clickButton(id)

    // ---- waypoints (kept per server in the preferences)
    private var wpKey = ""
    fun loadWaypoints(serverKey: String) {
        wpKey = serverKey
        for ((k, v) in Core.prefs.waypoints(serverKey)) core.setWaypoint(k, v[0], v[1], v[2])
    }
    fun waypoints(): Map<String, IntArray> = core.waypoints()
    fun saveWaypoint(name: String) { core.saveWaypoint(name); persistWaypoints() }
    fun deleteWaypoint(name: String) { core.deleteWaypoint(name); persistWaypoints() }
    private fun persistWaypoints() { if (wpKey.isNotEmpty()) Core.prefs.saveWaypoints(wpKey, core.waypoints()) }
    fun goToWaypoint(name: String) {
        val p = core.waypoints()[name] ?: return
        applyConfig()
        core.startAction(Actions.goToWaypoint(name, p))
    }

    fun stopAction() = core.stopAction()

    // ------------------------------------------------------------------ ClientSession.Listener

    override fun onStatus(status: ClientSession.Status, info: String?) {
        if (status == ClientSession.Status.IDLE) {
            _state.value = SessionState()
            return
        }
        val s = when (status) {
            ClientSession.Status.ONLINE -> Status.ONLINE
            ClientSession.Status.WAITING_RECONNECT -> Status.WAITING_RECONNECT
            else -> Status.CONNECTING
        }
        _state.update { it.copy(status = s, info = info ?: "") }
    }

    override fun onReconnectIn(seconds: Int) { _state.update { it.copy(reconnectIn = seconds) } }

    override fun onChat(spans: List<ChatSpan>) {
        if (spans.isEmpty()) return
        val line = ChatLine(ids.incrementAndGet(), ArrayList(spans))
        _chat.update { (it + line).takeLast(1000) }
    }

    override fun onActionBar(spans: List<ChatSpan>) {
        _state.update { it.copy(actionBar = ArrayList(spans), actionBarNonce = it.actionBarNonce + 1) }
    }

    override fun onHealth(health: Float, food: Int) { _state.update { it.copy(health = health, food = food) } }
    override fun onPlayers(names: List<String>) { _state.update { it.copy(players = ArrayList(names)) } }
    override fun onPackOffer(offer: ClientSession.PackOffer) { _state.update { it.copy(pendingPack = offer) } }

    override fun onPackResult(ok: Boolean, cached: Boolean, error: String?) {
        if (ok) { ItemIcons.clear(); McFont.reload(ctx) }
    }

    override fun onSuggestions(s: ClientSession.Suggestions?) { _state.update { it.copy(suggestions = s) } }

    override fun onInventory() { _inv.value = buildInv(core.inventory.snapshot()) }

    override fun onActionStatus(text: String, running: Boolean) {
        _state.update { it.copy(actionText = text, actionRunning = running) }
    }

    override fun onEnded(reason: String?) { Core.lastEnd = reason ?: "" }

    // ------------------------------------------------------------------ inventory snapshot -> UI model

    private fun slot(s: Inventory.Stack?): InvSlot? {
        if (s == null || s.count <= 0) return null
        return InvSlot(s.id, s.count, Registry.items?.name(s.id), s.customName(), s.lore())
    }

    private fun buildInv(snap: Inventory.Snapshot): InvView =
        InvView(snap.windowId, snap.title, snap.slots.map { slot(it) }, slot(snap.cursor), snap.held, snap.playerStart, snap.container, snap.type, HashMap(snap.props))
}
