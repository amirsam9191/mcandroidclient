package com.mcclient.app.net

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.mcclient.app.game.ChatSpan
import com.mcclient.core.Pinger

data class PingResult(
    val ok: Boolean,
    val motd: List<ChatSpan> = emptyList(),
    val online: Int = 0,
    val max: Int = 0,
    val version: String = "",
    val pingMs: Long = -1,
    val icon: Bitmap? = null,
    val error: String = ""
)

object ServerPinger {
    fun ping(address: String): PingResult {
        val r = Pinger.ping(address)
        var icon: Bitmap? = null
        val bytes = r.icon
        if (bytes != null) {
            try { icon = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) } catch (e: Exception) { icon = null }
        }
        return PingResult(r.ok, r.motd, r.online, r.max, r.version, r.pingMs, icon, r.error)
    }
}
