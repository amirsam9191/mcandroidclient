package com.mcclient.app.ui.mc

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.Rect
import android.graphics.RectF
import com.mcclient.app.Core
import com.mcclient.core.Packs
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipFile

/**
 * Custom fonts of the server's resource pack: assets/<namespace>/font/<name>.json with "bitmap" providers (a texture cut into
 * a grid of glyphs, the glyph width is trimmed to its used columns) and "space" providers (advance widths, negative ones shift
 * text). Other provider types (ttf, unihex, legacy_unicode) are ignored; their characters fall back to the default font.
 * Used for container titles and any chat component with a "font" field.
 */
object PackFonts {
    class Glyph(val bmp: Bitmap, val sx: Int, val sy: Int, val cw: Int, val ch: Int, val advance: Int, val scale: Float, val ascent: Float)
    class Font {
        val glyphs = HashMap<Int, Glyph>()
        val spaces = HashMap<Int, Float>()
    }

    private val cache = HashMap<String, Font>()
    private val NONE = Font()

    @Synchronized fun clear() { cache.clear() }

    private fun split(id: String): Pair<String, String> {
        val i = id.indexOf(':')
        return if (i < 0) "minecraft" to id else id.substring(0, i) to id.substring(i + 1)
    }

    private fun readEntry(pack: File, name: String): ByteArray? =
        try { ZipFile(pack).use { z -> z.getEntry(name)?.let { e -> z.getInputStream(e).use { it.readBytes() } } } } catch (e: Exception) { null }

    private fun texture(pack: File, file: String): Bitmap? {
        val (ns, path) = split(file)
        val opts = BitmapFactory.Options().also { it.inScaled = false }
        readEntry(pack, "assets/$ns/textures/$path")?.let { b -> BitmapFactory.decodeByteArray(b, 0, b.size, opts)?.let { return it } }
        val f = File(com.mcclient.app.ui.mc.Assets.dir(Core.app), "assets/$ns/textures/$path")
        return if (f.exists()) BitmapFactory.decodeFile(f.path, opts) else null
    }

    /** The font for an id like "ns:name", or null (default font) when the pack does not define it. */
    @Synchronized fun get(id: String): Font? {
        if (id == "minecraft:default" || id == "default") return null
        val pack = Packs.active ?: return null
        if (!pack.exists()) return null
        val key = pack.path + "|" + pack.lastModified() + "|" + id
        val hit = cache[key]
        if (hit != null) return if (hit === NONE) null else hit
        val f = try { parse(pack, id) } catch (e: Exception) { null }
        cache[key] = f ?: NONE
        return f
    }

    private fun parse(pack: File, id: String): Font? {
        val (ns, name) = split(id)
        val json = readEntry(pack, "assets/$ns/font/$name.json") ?: return null
        val providers = JSONObject(String(json, Charsets.UTF_8)).optJSONArray("providers") ?: return null
        val font = Font()
        // later providers do not override earlier ones for the same character (the first provider wins)
        for (i in 0 until providers.length()) {
            val p = providers.getJSONObject(i)
            when (p.optString("type")) {
                "space" -> {
                    val adv = p.optJSONObject("advances") ?: continue
                    val it = adv.keys()
                    while (it.hasNext()) {
                        val k = it.next()
                        if (k.isEmpty()) continue
                        val cp = k.codePointAt(0)
                        if (!font.spaces.containsKey(cp) && !font.glyphs.containsKey(cp)) font.spaces[cp] = adv.getDouble(k).toFloat()
                    }
                }
                "bitmap" -> {
                    val bmp = texture(pack, p.optString("file")) ?: continue
                    val chars = p.optJSONArray("chars") ?: continue
                    val rows = chars.length()
                    if (rows == 0) continue
                    val cols = chars.getString(0).codePointCount(0, chars.getString(0).length)
                    if (cols == 0) continue
                    val cellW = bmp.width / cols
                    val cellH = bmp.height / rows
                    if (cellW <= 0 || cellH <= 0) continue
                    val height = p.optInt("height", 8)
                    val ascent = p.optDouble("ascent", 7.0).toFloat()
                    val scale = height.toFloat() / cellH
                    val px = IntArray(cellW)
                    for (r in 0 until rows) {
                        val row = chars.getString(r)
                        var c = 0
                        var idx = 0
                        while (idx < row.length && c < cols) {
                            val cp = row.codePointAt(idx)
                            idx += Character.charCount(cp)
                            if (cp != 0 && !font.glyphs.containsKey(cp) && !font.spaces.containsKey(cp)) {
                                // trimmed width: the right-most column that has any visible pixel
                                var used = 0
                                for (y in 0 until cellH) {
                                    bmp.getPixels(px, 0, cellW, c * cellW, r * cellH + y, cellW, 1)
                                    for (x in cellW - 1 downTo used) if ((px[x] ushr 24) != 0) { used = x + 1; break }
                                }
                                if (used > 0) {
                                    val advance = (0.5 + used * scale).toInt() + 1
                                    font.glyphs[cp] = Glyph(bmp, c * cellW, r * cellH, cellW, cellH, advance, scale, ascent)
                                }
                            }
                            c++
                        }
                    }
                }
            }
        }
        return if (font.glyphs.isEmpty() && font.spaces.isEmpty()) null else font
    }

    /** Advance of one code point in game pixels, or MIN_VALUE when the font does not define it. */
    private fun advance(f: Font, cp: Int): Float {
        f.spaces[cp]?.let { return it }
        f.glyphs[cp]?.let { return it.advance.toFloat() }
        return Float.NaN
    }

    /** Width of a run; characters the font lacks use the default font's advance. */
    fun width(f: Font, text: String, bold: Boolean): Int {
        var w = 0f
        var i = 0
        while (i < text.length) {
            val cp = text.codePointAt(i)
            i += Character.charCount(cp)
            val a = advance(f, cp)
            w += if (a.isNaN()) McFont.charAdv(cp).toFloat() else a
            if (bold && !a.isNaN() && f.glyphs.containsKey(cp)) w += 1
        }
        return w.toInt()
    }

    /** Draws the run; the paint already carries the colour filter. Returns nothing: the layout knows the width. */
    fun draw(canvas: Canvas, f: Font, text: String, xGp: Int, topGp: Int, unit: Float, paint: Paint, bold: Boolean) {
        var x = xGp.toFloat()
        val src = Rect()
        val dst = RectF()
        var i = 0
        while (i < text.length) {
            val cp = text.codePointAt(i)
            i += Character.charCount(cp)
            val g = f.glyphs[cp]
            if (g != null) {
                src.set(g.sx, g.sy, g.sx + g.cw, g.sy + g.ch)
                val l = x * unit
                val t = (topGp + TEXT_BASE - g.ascent) * unit
                dst.set(l, t, l + g.cw * g.scale * unit, t + g.ch * g.scale * unit)
                canvas.drawBitmap(g.bmp, src, dst, paint)
                if (bold) { dst.offset(unit, 0f); canvas.drawBitmap(g.bmp, src, dst, paint) }
                x += g.advance + (if (bold) 1 else 0)
            } else {
                x += advance(f, cp).let { if (it.isNaN()) McFont.charAdv(cp).toFloat() else it }
            }
        }
    }

    /** Baseline row inside a text line (ascent 7 glyphs are drawn at BASE - 7). */
    private const val TEXT_BASE = 9f

    fun filter(color: Int): PorterDuffColorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.MULTIPLY)
}
