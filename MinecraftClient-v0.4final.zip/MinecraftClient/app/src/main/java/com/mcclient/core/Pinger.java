package com.mcclient.core;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/** Server-list ping (status protocol): MOTD, players, version, favicon bytes and latency. */
public final class Pinger {
    private Pinger() {}

    public static final class Result {
        public boolean ok;
        public List<Chat.Span> motd = Collections.emptyList();
        public int online, max;
        public String version = "", error = "";
        public long pingMs = -1;
        public byte[] icon;  // PNG bytes or null
    }

    @SuppressWarnings("unchecked")
    public static Result ping(String address) {
        Result res = new Result();
        try (Socket s = new Socket()) {
            Object[] hp = Framing.parseAddress(address);
            String host = (String) hp[0];
            int port = (Integer) hp[1];
            s.connect(new InetSocketAddress(host, port), 5000);
            s.setSoTimeout(5000);
            Framing.Conn c = new Framing.Conn(s.getInputStream(), s.getOutputStream());
            c.send(0x00, new Buf.Writer().varInt(ClientSession.PROTOCOL).str(host).s16(port).varInt(1).toBytes());
            c.send(0x00);
            Framing.Incoming in = c.read();
            if (in.id != 0x00) { res.error = "پاسخ نامعتبر"; return res; }
            Map<String, Object> json = (Map<String, Object>) Json.parse(in.r.str());
            res.motd = Chat.fromAny(json.get("description"));
            Object pl = json.get("players");
            if (pl instanceof Map) {
                Object o = ((Map<String, Object>) pl).get("online"), m = ((Map<String, Object>) pl).get("max");
                res.online = o instanceof Number ? ((Number) o).intValue() : 0;
                res.max = m instanceof Number ? ((Number) m).intValue() : 0;
            }
            Object ver = json.get("version");
            if (ver instanceof Map && ((Map<String, Object>) ver).get("name") != null) res.version = String.valueOf(((Map<String, Object>) ver).get("name"));
            Object fav = json.get("favicon");
            if (fav instanceof String && ((String) fav).startsWith("data:image")) {
                try { res.icon = Base64.getMimeDecoder().decode(((String) fav).substring(((String) fav).indexOf(',') + 1)); } catch (IllegalArgumentException e) { res.icon = null; }
            }
            long t0 = System.nanoTime();
            c.send(0x01, new Buf.Writer().i64(t0).toBytes());
            c.read();
            res.pingMs = (System.nanoTime() - t0) / 1_000_000;
            res.ok = true;
        } catch (Exception e) {
            res.ok = false;
            res.error = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
        }
        return res;
    }
}
