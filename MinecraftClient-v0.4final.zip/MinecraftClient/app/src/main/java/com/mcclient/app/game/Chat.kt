package com.mcclient.app.game

import com.mcclient.core.Chat

/** Styled text span; the parser itself lives in the tested Java core. */
typealias ChatSpan = Chat.Span

class ChatLine(val id: Long, val spans: List<ChatSpan>) {
    val plain: String = spans.joinToString("") { it.text }
}

object ChatParser {
    fun legacy(s: String): List<ChatSpan> = Chat.legacy(s)
    fun fromAny(n: Any?): List<ChatSpan> = Chat.fromAny(n)
}
