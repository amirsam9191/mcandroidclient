package com.mcclient.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Path goals. {@code isInGoal} / {@code heuristic} follow baritone.api.pathing.goals (baritone-api 1.8.6, read with javap):
 * GoalXZ.calculate = (diagonal * sqrt2 + straight) * costHeuristic, GoalYLevel.calculate = fall/jump cost per block,
 * GoalBlock = GoalYLevel + GoalXZ, GoalNear = GoalBlock heuristic with a squared range, GoalGetToBlock = adjacent to a block,
 * GoalComposite = any of its goals (heuristic: the minimum).
 */
public final class Goals {
    private Goals() {}

    /** Baritone's Settings.costHeuristic default (equal to the sprint cost per block). */
    public static double costHeuristic = ActionCosts.SPRINT_ONE_BLOCK_COST;
    private static final double SQRT_2 = Math.sqrt(2.0);

    public interface Goal {
        boolean isInGoal(int x, int y, int z);
        /** Estimated remaining cost (ticks) from this cell. */
        double heuristic(int x, int y, int z);
        String describe();
    }

    static double calculateXZ(double xDiff, double zDiff) {
        double x = Math.abs(xDiff), z = Math.abs(zDiff);
        double straight, diagonal;
        if (x < z) { straight = z - x; diagonal = x; } else { straight = x - z; diagonal = z; }
        return (diagonal * SQRT_2 + straight) * costHeuristic;
    }

    static double calculateY(int goalY, int currentY) {
        if (currentY > goalY) return ActionCosts.FALL_N_BLOCKS_COST[2] / 2 * (currentY - goalY);
        if (currentY < goalY) return (goalY - currentY) * ActionCosts.JUMP_ONE_BLOCK_COST;
        return 0;
    }

    static double calculateBlock(int xDiff, int yDiff, int zDiff) {
        return calculateY(0, yDiff) + calculateXZ(xDiff, zDiff);
    }

    /** Exactly one cell. */
    public static final class GoalBlock implements Goal {
        public final int x, y, z;
        public GoalBlock(int x, int y, int z) { this.x = x; this.y = y; this.z = z; }
        @Override public boolean isInGoal(int px, int py, int pz) { return px == x && py == y && pz == z; }
        @Override public double heuristic(int px, int py, int pz) { return calculateBlock(px - x, py - y, pz - z); }
        @Override public String describe() { return "GoalBlock{" + x + "," + y + "," + z + "}"; }
    }

    /** Any cell of one column, whatever the height. */
    public static final class GoalXZ implements Goal {
        public final int x, z;
        public GoalXZ(int x, int z) { this.x = x; this.z = z; }
        @Override public boolean isInGoal(int px, int py, int pz) { return px == x && pz == z; }
        @Override public double heuristic(int px, int py, int pz) { return calculateXZ(px - x, pz - z); }
        @Override public String describe() { return "GoalXZ{" + x + "," + z + "}"; }
    }

    /** Our own addition: any height, within {@code radius} blocks of a column (used for "go to x z" with an arrival distance). */
    public static final class GoalXZNear implements Goal {
        public final int x, z; public final double radius;
        public GoalXZNear(int x, int z, double radius) { this.x = x; this.z = z; this.radius = radius; }
        @Override public boolean isInGoal(int px, int py, int pz) { double dx = px - x, dz = pz - z; return dx * dx + dz * dz <= radius * radius; }
        @Override public double heuristic(int px, int py, int pz) { return calculateXZ(px - x, pz - z); }
        @Override public String describe() { return "GoalXZNear{" + x + "," + z + " r=" + radius + "}"; }
    }

    /** Within {@code range} blocks (euclidean) of a cell. */
    public static final class GoalNear implements Goal {
        public final int x, y, z, rangeSq;
        public GoalNear(int x, int y, int z, int range) { this.x = x; this.y = y; this.z = z; this.rangeSq = range * range; }
        @Override public boolean isInGoal(int px, int py, int pz) {
            int dx = px - x, dy = py - y, dz = pz - z;
            return dx * dx + dy * dy + dz * dz <= rangeSq;
        }
        @Override public double heuristic(int px, int py, int pz) { return calculateBlock(px - x, py - y, pz - z); }
        @Override public String describe() { return "GoalNear{" + x + "," + y + "," + z + " r^2=" + rangeSq + "}"; }
    }

    /** Next to a block (so it can be opened / mined / used): |dx| + |dy'| + |dz| <= 1 where dy' counts the head height. */
    public static final class GoalGetToBlock implements Goal {
        public final int x, y, z;
        public GoalGetToBlock(int x, int y, int z) { this.x = x; this.y = y; this.z = z; }
        @Override public boolean isInGoal(int px, int py, int pz) {
            int xDiff = px - x, yDiff = py - y, zDiff = pz - z;
            return Math.abs(xDiff) + Math.abs(yDiff < 0 ? yDiff + 1 : yDiff) + Math.abs(zDiff) <= 1;
        }
        @Override public double heuristic(int px, int py, int pz) {
            int xDiff = px - x, yDiff = py - y, zDiff = pz - z;
            return calculateBlock(xDiff, yDiff < 0 ? yDiff + 1 : yDiff, zDiff);
        }
        @Override public String describe() { return "GoalGetToBlock{" + x + "," + y + "," + z + "}"; }
    }

    /** Reach any one of several goals. */
    public static final class GoalComposite implements Goal {
        public final List<Goal> goals;
        public GoalComposite(Goal... g) { goals = new ArrayList<>(Arrays.asList(g)); }
        public GoalComposite(List<? extends Goal> g) { goals = new ArrayList<Goal>(g); }
        @Override public boolean isInGoal(int x, int y, int z) {
            for (Goal g : goals) if (g.isInGoal(x, y, z)) return true;
            return false;
        }
        @Override public double heuristic(int x, int y, int z) {
            double min = Double.MAX_VALUE;
            for (Goal g : goals) min = Math.min(min, g.heuristic(x, y, z));
            return min;
        }
        @Override public String describe() { return "GoalComposite" + goals.size(); }
    }

    /** A given height (any x/z). */
    public static final class GoalYLevel implements Goal {
        public final int level;
        public GoalYLevel(int level) { this.level = level; }
        @Override public boolean isInGoal(int x, int y, int z) { return y == level; }
        @Override public double heuristic(int x, int y, int z) { return calculateY(level, y); }
        @Override public String describe() { return "GoalYLevel{" + level + "}"; }
    }
}
