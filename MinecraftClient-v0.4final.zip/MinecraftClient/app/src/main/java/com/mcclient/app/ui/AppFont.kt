@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)

package com.mcclient.app.ui

import android.content.Context
import androidx.compose.material3.Typography
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * The app's own font (menus, buttons, settings): Vazirmatn.
 * Order of preference: a font file bundled in the APK (app/src/main/assets/fonts/Vazirmatn-Regular.ttf, optional),
 * the file downloaded on the first run and cached in the app's private storage, then the system font.
 * The in-game chat is not affected: it uses Minecraft's own bitmap fonts.
 */
object AppFont {
    var family by mutableStateOf<FontFamily>(FontFamily.Default)
        private set
    var status by mutableStateOf("")
        private set
    @Volatile private var started = false

    private const val REGULAR = "Vazirmatn-Regular.ttf"
    private const val BOLD = "Vazirmatn-Bold.ttf"

    /** The repository path was checked against github.com/rastikerdar/vazirmatn (fonts/ttf, tag v33.003, default branch master). */
    private val SOURCES = listOf(
        "https://raw.githubusercontent.com/rastikerdar/vazirmatn/v33.003/fonts/ttf/",
        "https://raw.githubusercontent.com/rastikerdar/vazirmatn/master/fonts/ttf/",
        "https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/fonts/ttf/"
    )

    private fun dir(ctx: Context) = File(ctx.filesDir, "fonts")

    /** A TrueType/OpenType file starts with 00 01 00 00, "true", "OTTO" or "ttcf". */
    private fun looksLikeFont(b: ByteArray): Boolean {
        if (b.size < 50_000) return false
        val h = String(b, 0, 4, Charsets.ISO_8859_1)
        return (b[0] == 0.toByte() && b[1] == 1.toByte() && b[2] == 0.toByte() && b[3] == 0.toByte()) || h == "true" || h == "OTTO" || h == "ttcf"
    }

    private fun fetch(url: String): ByteArray? {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.setRequestProperty("User-Agent", "MinecraftClientApp")
            try { if (c.responseCode == 200) c.inputStream.use { it.readBytes() } else null } finally { c.disconnect() }
        } catch (e: Exception) { null }
    }

    /** Builds the family from whatever is available right now. */
    fun load(ctx: Context) {
        val fonts = ArrayList<Font>()
        // 1) bundled in the APK
        try {
            val names = ctx.assets.list("fonts")?.toSet() ?: emptySet()
            if (REGULAR in names) fonts.add(Font("fonts/$REGULAR", ctx.assets, FontWeight.Normal))
            if (BOLD in names) fonts.add(Font("fonts/$BOLD", ctx.assets, FontWeight.Bold))
        } catch (e: Exception) { fonts.clear() }
        // 2) downloaded on the first run
        if (fonts.isEmpty()) {
            val r = File(dir(ctx), REGULAR)
            val b = File(dir(ctx), BOLD)
            if (r.exists()) fonts.add(Font(r, FontWeight.Normal))
            if (b.exists()) fonts.add(Font(b, FontWeight.Bold))
            else if (r.exists()) fonts.add(Font(r, FontWeight.Bold))
        }
        if (fonts.isNotEmpty()) family = FontFamily(fonts)
    }

    fun has(ctx: Context): Boolean =
        File(dir(ctx), REGULAR).exists() || (try { ctx.assets.list("fonts")?.contains(REGULAR) == true } catch (e: Exception) { false })

    /** Blocking; run on a background thread. */
    fun download(ctx: Context) {
        try {
            status = "در حال دریافت فونت وزیرمتن…"
            dir(ctx).mkdirs()
            for (name in listOf(REGULAR, BOLD)) {
                var saved = false
                for (base in SOURCES) {
                    val bytes = fetch(base + name) ?: continue
                    if (!looksLikeFont(bytes)) continue
                    val tmp = File(dir(ctx), "$name.tmp")
                    tmp.writeBytes(bytes)
                    tmp.renameTo(File(dir(ctx), name))
                    saved = true
                    break
                }
                if (!saved && name == REGULAR) { status = "دانلود فونت وزیرمتن ناموفق بود (اینترنت را بررسی کنید)"; return }
            }
            load(ctx)
            status = "فونت وزیرمتن آماده است"
        } catch (e: Exception) {
            status = "خطا در دریافت فونت: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    /** Loads what exists and downloads the rest in the background (once per process). */
    fun ensure(ctx: Context) {
        val app = ctx.applicationContext
        load(app)
        if (started || has(app)) return
        started = true
        Thread { download(app) }.start()
    }

    fun typography(f: FontFamily): Typography {
        val d = Typography()
        fun TextStyle.v() = copy(fontFamily = f)
        return d.copy(
            displayLarge = d.displayLarge.v(), displayMedium = d.displayMedium.v(), displaySmall = d.displaySmall.v(),
            headlineLarge = d.headlineLarge.v(), headlineMedium = d.headlineMedium.v(), headlineSmall = d.headlineSmall.v(),
            titleLarge = d.titleLarge.v(), titleMedium = d.titleMedium.v(), titleSmall = d.titleSmall.v(),
            bodyLarge = d.bodyLarge.v(), bodyMedium = d.bodyMedium.v(), bodySmall = d.bodySmall.v(),
            labelLarge = d.labelLarge.v(), labelMedium = d.labelMedium.v(), labelSmall = d.labelSmall.v()
        )
    }
}
