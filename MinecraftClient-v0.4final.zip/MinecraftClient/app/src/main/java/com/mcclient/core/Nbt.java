package com.mcclient.core;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Network NBT (1.20.2+: the root tag has no name).
 * Compound -> Map&lt;String,Object&gt;, List -> List&lt;Object&gt;, String -> String,
 * Byte/Short/Integer/Long/Float/Double for numbers, byte[]/int[]/long[] for arrays.
 */
public final class Nbt {
    private Nbt() {}

    public static Object readNetwork(Buf.Reader r) {
        int t = r.u8();
        if (t == 0) return null;
        return payload(r, t);
    }

    private static Object payload(Buf.Reader r, int t) {
        switch (t) {
            case 1: return (byte) r.i8();
            case 2: return (short) r.s16();
            case 3: return r.i32();
            case 4: return r.i64();
            case 5: return r.f32();
            case 6: return r.f64();
            case 7: { int n = r.i32(); return r.bytes(n); }
            case 8: return str(r);
            case 9: {
                int et = r.u8();
                int n = r.i32();
                if (n < 0 || n > 1_000_000) throw new Buf.ParseEx("bad nbt list");
                List<Object> l = new ArrayList<>();
                for (int i = 0; i < n; i++) l.add(payload(r, et));
                return l;
            }
            case 10: {
                Map<String, Object> m = new LinkedHashMap<>();
                while (true) {
                    int et = r.u8();
                    if (et == 0) break;
                    String name = str(r);
                    m.put(name, payload(r, et));
                }
                return m;
            }
            case 11: { int n = r.i32(); if (n < 0) throw new Buf.ParseEx("bad array"); int[] a = new int[n]; for (int i = 0; i < n; i++) a[i] = r.i32(); return a; }
            case 12: { int n = r.i32(); if (n < 0) throw new Buf.ParseEx("bad array"); long[] a = new long[n]; for (int i = 0; i < n; i++) a[i] = r.i64(); return a; }
            default: throw new Buf.ParseEx("bad nbt tag " + t);
        }
    }

    private static String str(Buf.Reader r) {
        int n = r.u16();
        return new String(r.bytes(n), StandardCharsets.UTF_8);
    }

    // ------------------------------------------------------------------ writing

    public static void writeNetwork(Buf.Writer w, Object tag) {
        if (tag == null) { w.b(0); return; }
        w.b(typeOf(tag));
        writePayload(w, tag);
    }

    private static int typeOf(Object o) {
        if (o instanceof Byte) return 1;
        if (o instanceof Short) return 2;
        if (o instanceof Integer) return 3;
        if (o instanceof Long) return 4;
        if (o instanceof Float) return 5;
        if (o instanceof Double) return 6;
        if (o instanceof byte[]) return 7;
        if (o instanceof String) return 8;
        if (o instanceof List) return 9;
        if (o instanceof Map) return 10;
        if (o instanceof int[]) return 11;
        if (o instanceof long[]) return 12;
        if (o instanceof Boolean) return 1;
        throw new IllegalArgumentException("unsupported nbt value " + o.getClass());
    }

    @SuppressWarnings("unchecked")
    private static void writePayload(Buf.Writer w, Object o) {
        if (o instanceof Boolean) { w.b(((Boolean) o) ? 1 : 0); return; }
        if (o instanceof Byte) { w.b((Byte) o); return; }
        if (o instanceof Short) { w.s16((Short) o); return; }
        if (o instanceof Integer) { w.i32((Integer) o); return; }
        if (o instanceof Long) { w.i64((Long) o); return; }
        if (o instanceof Float) { w.f32((Float) o); return; }
        if (o instanceof Double) { w.f64((Double) o); return; }
        if (o instanceof byte[]) { byte[] a = (byte[]) o; w.i32(a.length); w.bytes(a); return; }
        if (o instanceof String) { byte[] b = ((String) o).getBytes(StandardCharsets.UTF_8); w.s16(b.length); w.bytes(b); return; }
        if (o instanceof List) {
            List<Object> l = (List<Object>) o;
            w.b(l.isEmpty() ? 0 : typeOf(l.get(0)));
            w.i32(l.size());
            for (Object e : l) writePayload(w, e);
            return;
        }
        if (o instanceof Map) {
            for (Map.Entry<String, Object> e : ((Map<String, Object>) o).entrySet()) {
                w.b(typeOf(e.getValue()));
                byte[] k = e.getKey().getBytes(StandardCharsets.UTF_8);
                w.s16(k.length); w.bytes(k);
                writePayload(w, e.getValue());
            }
            w.b(0);
            return;
        }
        if (o instanceof int[]) { int[] a = (int[]) o; w.i32(a.length); for (int v : a) w.i32(v); return; }
        if (o instanceof long[]) { long[] a = (long[]) o; w.i32(a.length); for (long v : a) w.i64(v); return; }
        throw new IllegalArgumentException("unsupported nbt value " + o.getClass());
    }
}
