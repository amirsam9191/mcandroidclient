package com.mcclient.core;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

/** Packet framing with optional zlib compression. Sending is thread-safe. */
public final class Framing {
    private Framing() {}

    public static final class Incoming {
        public final int id;
        public final Buf.Reader r;
        Incoming(int id, Buf.Reader r) { this.id = id; this.r = r; }
    }

    public static final class Conn {
        private final InputStream in;
        private final OutputStream out;
        public volatile int threshold = -1;
        private final Object wlock = new Object();
        private final Inflater inflater = new Inflater();
        private final Deflater deflater = new Deflater();

        public Conn(InputStream in, OutputStream out) { this.in = in; this.out = out; }

        private int readVarIntStream() throws IOException {
            int r = 0, shift = 0;
            while (true) {
                int b = in.read();
                if (b < 0) throw new EOFException("connection closed");
                r |= (b & 0x7F) << shift;
                if ((b & 0x80) == 0) return r;
                shift += 7;
                if (shift > 35) throw new IOException("bad varint");
            }
        }

        private byte[] readFully(int n) throws IOException {
            byte[] buf = new byte[n];
            int off = 0;
            while (off < n) {
                int k = in.read(buf, off, n - off);
                if (k < 0) throw new EOFException("connection closed");
                off += k;
            }
            return buf;
        }

        public Incoming read() throws IOException {
            int len = readVarIntStream();
            if (len <= 0 || len > 16 * 1024 * 1024) throw new IOException("bad packet length " + len);
            byte[] data = readFully(len);
            byte[] payload = data;
            if (threshold >= 0) {
                Buf.Reader r = new Buf.Reader(data);
                int dataLen = r.varInt();
                if (dataLen == 0) {
                    payload = new byte[data.length - r.pos];
                    System.arraycopy(data, r.pos, payload, 0, payload.length);
                } else {
                    payload = inflate(data, r.pos, dataLen);
                }
            }
            Buf.Reader pr = new Buf.Reader(payload);
            int id = pr.varInt();
            return new Incoming(id, pr);
        }

        private byte[] inflate(byte[] src, int off, int expected) throws IOException {
            if (expected < 0 || expected > 16 * 1024 * 1024) throw new IOException("bad uncompressed size");
            inflater.reset();
            inflater.setInput(src, off, src.length - off);
            byte[] res = new byte[expected];
            int n = 0;
            try {
                while (n < expected) {
                    int k = inflater.inflate(res, n, expected - n);
                    if (k == 0 && (inflater.finished() || inflater.needsInput() || inflater.needsDictionary())) break;
                    n += k;
                }
            } catch (DataFormatException e) {
                throw new IOException("corrupt compressed packet", e);
            }
            if (n != expected) throw new IOException("corrupt compressed packet");
            return res;
        }

        private byte[] deflate(byte[] src) {
            deflater.reset();
            deflater.setInput(src);
            deflater.finish();
            ByteArrayOutputStream bos = new ByteArrayOutputStream(src.length / 2 + 16);
            byte[] buf = new byte[4096];
            while (!deflater.finished()) {
                int k = deflater.deflate(buf);
                bos.write(buf, 0, k);
            }
            return bos.toByteArray();
        }

        private static byte[] vi(int v) { return new Buf.Writer().varInt(v).toBytes(); }

        public void send(int id) throws IOException { send(id, new byte[0]); }

        public void send(int id, byte[] body) throws IOException {
            byte[] payload = new Buf.Writer().varInt(id).bytes(body).toBytes();
            synchronized (wlock) {
                int th = threshold;
                if (th >= 0) {
                    if (payload.length >= th) {
                        byte[] comp = deflate(payload);
                        byte[] dl = vi(payload.length);
                        out.write(vi(dl.length + comp.length));
                        out.write(dl);
                        out.write(comp);
                    } else {
                        out.write(vi(1 + payload.length));
                        out.write(0);
                        out.write(payload);
                    }
                } else {
                    out.write(vi(payload.length));
                    out.write(payload);
                }
                out.flush();
            }
        }
    }

    /** "host", "host:port", "[ipv6]" or "[ipv6]:port" -> {host, port}. Missing port => 25565. */
    public static Object[] parseAddress(String input) {
        String t = input.trim();
        if (t.startsWith("[")) {
            int e = t.indexOf(']');
            if (e > 0) {
                String rest = t.substring(e + 1);
                if (rest.startsWith(":")) rest = rest.substring(1);
                int port = 25565;
                try { port = Integer.parseInt(rest); } catch (NumberFormatException ex) { /* default */ }
                return new Object[]{t.substring(1, e), port};
            }
        }
        int first = t.indexOf(':'), last = t.lastIndexOf(':');
        if (first >= 0 && first == last) {
            int p = 25565;
            try { p = Integer.parseInt(t.substring(first + 1)); } catch (NumberFormatException ex) { /* default */ }
            if (p < 1 || p > 65535) p = 25565;
            return new Object[]{t.substring(0, first), p};
        }
        return new Object[]{t, 25565};
    }
}
