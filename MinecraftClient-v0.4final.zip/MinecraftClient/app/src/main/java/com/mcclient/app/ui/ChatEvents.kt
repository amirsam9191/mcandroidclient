package com.mcclient.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.mcclient.app.game.ChatSpan
import com.mcclient.app.game.Session
import com.mcclient.app.ui.mc.McText
import com.mcclient.core.Chat

/** What a tap on a clickable part of a chat message does (1.20.4 clickEvent actions). */
class ChatEventHandler(
    private val ctx: Context,
    private val session: Session,
    private val clipboard: ClipboardManager,
    private val fillInput: (String) -> Unit,
    private val askUrl: (String) -> Unit
) {
    /** @return true when the span had a click event and it was handled. */
    fun click(span: ChatSpan?): Boolean {
        val c = span?.click ?: return false
        when (c.action) {
            // run_command: a leading "/" makes it a command, otherwise it is sent as a chat message (like the real client)
            "run_command" -> session.sendUserText(c.value)
            "suggest_command" -> fillInput(c.value)
            "copy_to_clipboard" -> clipboard.setText(AnnotatedString(c.value))
            "open_url" -> if (c.value.startsWith("http://") || c.value.startsWith("https://")) askUrl(c.value)
            else -> return false // change_page (books) and open_file do nothing in a chat client
        }
        return true
    }

    fun openUrl(url: String) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { /* no browser installed */ }
    }
}

/** Tooltip for a hoverEvent: shown on long press (there is no pointer hover on a phone). */
@Composable
fun HoverDialog(h: Chat.Hover, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xF0100010)), shape = RoundedCornerShape(6.dp)) {
            Column(Modifier.padding(10.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                for (line in h.lines()) McText(line)
                if (h.action == "show_item" && h.tag != null) {
                    McText(listOf(ChatSpan(h.tag.toString().take(300), 0xFF555555.toInt())))
                }
            }
        }
    }
}

@Composable
fun UrlConfirmDialog(url: String, onOpen: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("باز کردن لینک؟") },
        text = { Text(url) },
        confirmButton = { TextButton(onClick = { onOpen(); onDismiss() }) { Text("باز کن") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}
