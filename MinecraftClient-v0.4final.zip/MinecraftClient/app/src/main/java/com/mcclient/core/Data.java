package com.mcclient.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Registry data (item ids, block-state ids) loaded from minecraft-data JSON for the running version. */
public final class Data {
    private Data() {}

    public static final class Items {
        private final Map<Integer, String> names = new HashMap<>();

        @SuppressWarnings("unchecked")
        public static Items parse(String json) {
            Items it = new Items();
            for (Object o : (List<Object>) Json.parse(json)) {
                Map<String, Object> e = (Map<String, Object>) o;
                it.names.put(((Number) e.get("id")).intValue(), String.valueOf(e.get("name")));
            }
            return it;
        }
        public String name(int id) { return names.get(id); }
        public int size() { return names.size(); }
    }

    /**
     * Block-state classification used by the world model and the path finder, built from minecraft-data's blocks.json.
     * Without registry data (null) only state 0 (air) is treated as passable; everything else is a solid cube.
     * State ids are decoded like prismarine-block does: the last property varies fastest.
     */
    public static final class Blocks {
        static final class Prop {
            final String name, type;
            final int n;
            final String[] values;
            Prop(String name, String type, int n, String[] values) { this.name = name; this.type = type; this.n = Math.max(1, n); this.values = values; }
        }

        private int[] min = new int[0], max = new int[0];
        private String[] name = new String[0];
        private boolean[] box = new boolean[0];
        private double[] hard = new double[0];
        private Prop[][] props = new Prop[0][];

        @SuppressWarnings("unchecked")
        public static Blocks parse(String json) {
            List<Object> arr = (List<Object>) Json.parse(json);
            List<Object[]> rows = new ArrayList<>();
            for (Object o : arr) {
                Map<String, Object> e = (Map<String, Object>) o;
                Number mn = (Number) e.get("minStateId"), mx = (Number) e.get("maxStateId");
                if (mn == null || mx == null) {
                    Number id = (Number) e.get("id");
                    mn = id; mx = id;
                }
                Object h = e.get("hardness");
                double hardness = h instanceof Number ? ((Number) h).doubleValue() : -1;
                List<Prop> ps = new ArrayList<>();
                if (e.get("states") instanceof List) {
                    for (Object so : (List<Object>) e.get("states")) {
                        Map<String, Object> sm = (Map<String, Object>) so;
                        String[] vals = null;
                        if (sm.get("values") instanceof List) {
                            List<Object> vl = (List<Object>) sm.get("values");
                            vals = new String[vl.size()];
                            for (int i = 0; i < vals.length; i++) vals[i] = String.valueOf(vl.get(i));
                        }
                        int n = sm.get("num_values") instanceof Number ? ((Number) sm.get("num_values")).intValue() : (vals == null ? 2 : vals.length);
                        ps.add(new Prop(String.valueOf(sm.get("name")), String.valueOf(sm.get("type")), n, vals));
                    }
                }
                rows.add(new Object[]{mn.intValue(), mx.intValue(), String.valueOf(e.get("name")), "block".equals(e.get("boundingBox")), hardness, ps.toArray(new Prop[0])});
            }
            rows.sort(Comparator.comparingInt(r -> (Integer) r[0]));
            Blocks b = new Blocks();
            int n = rows.size();
            b.min = new int[n]; b.max = new int[n]; b.name = new String[n]; b.box = new boolean[n]; b.hard = new double[n]; b.props = new Prop[n][];
            for (int i = 0; i < n; i++) {
                Object[] r = rows.get(i);
                b.min[i] = (Integer) r[0]; b.max[i] = (Integer) r[1]; b.name[i] = (String) r[2]; b.box[i] = (Boolean) r[3];
                b.hard[i] = (Double) r[4]; b.props[i] = (Prop[]) r[5];
            }
            return b;
        }

        private int index(int state) {
            int i = Arrays.binarySearch(min, state);
            if (i < 0) i = -i - 2;
            return (i >= 0 && state <= max[i]) ? i : -1;
        }

        public String nameOf(int state) {
            int i = index(state);
            return i < 0 ? null : name[i];
        }

        /** Value of a block-state property ("open", "half", "type" ...) or null. Booleans are "true"/"false". */
        public String prop(int state, String key) {
            int i = index(state);
            if (i < 0) return null;
            Prop[] ps = props[i];
            int off = state - min[i];
            for (int k = ps.length - 1; k >= 0; k--) {
                int v = off % ps[k].n;
                off /= ps[k].n;
                if (ps[k].name.equals(key)) {
                    if (ps[k].values != null) return v < ps[k].values.length ? ps[k].values[v] : null;
                    return "bool".equals(ps[k].type) ? (v == 0 ? "true" : "false") : String.valueOf(v);
                }
            }
            return null;
        }

        /** Seconds-independent hardness (as in the game); -1 = unbreakable. */
        public double hardness(int state) {
            int i = index(state);
            return i < 0 ? -1 : hard[i];
        }

        private static boolean has(String n, String... parts) {
            for (String p : parts) if (n.contains(p)) return true;
            return false;
        }

        /** Blocks that hurt, trap or teleport: never walk through or stand on them. */
        static boolean danger(String n) {
            return has(n, "lava", "fire", "cactus", "magma_block", "sweet_berry_bush", "wither_rose", "campfire",
                "powder_snow", "cobweb", "portal", "dripstone", "bubble_column");
        }

        static boolean waterName(String n) {
            return n.equals("water") || n.equals("bubble_column") || n.equals("kelp") || n.equals("kelp_plant")
                || n.equals("seagrass") || n.equals("tall_seagrass");
        }

        static boolean liquid(String n) { return waterName(n) || n.equals("lava"); }

        static boolean climbableName(String n) {
            return n.equals("ladder") || n.equals("vine") || n.equals("cave_vines") || n.equals("cave_vines_plant")
                || n.equals("twisting_vines") || n.equals("twisting_vines_plant") || n.equals("weeping_vines") || n.equals("weeping_vines_plant");
        }

        static boolean doorName(String n) {
            if (n.startsWith("iron_")) return false; // only powered, not by hand
            return n.endsWith("_door") || n.endsWith("fence_gate") || n.endsWith("_trapdoor");
        }

        /** Blocks the path finder never breaks, even when breaking is enabled. */
        static boolean protectedName(String n) {
            return has(n, "chest", "barrel", "shulker_box", "spawner", "bedrock", "barrier", "command_block", "structure_block", "jigsaw",
                "end_portal", "beacon", "_bed", "respawn_anchor", "lodestone", "furnace", "crafting_table", "enchanting_table", "anvil",
                "hopper", "dispenser", "dropper", "lectern", "bell", "sign", "item_frame", "banner", "head", "skull", "conduit");
        }

        /** Shapes that are not a full 1x1x1 cube: standing on them gives a non-integer height. */
        static boolean partial(String n) {
            return has(n, "slab", "stairs", "carpet", "snow", "trapdoor", "_bed", "chest", "anvil", "enchanting_table", "brewing_stand",
                "cauldron", "hopper", "lantern", "candle", "flower_pot", "head", "skull", "pane", "bars", "chain", "_rod", "farmland",
                "dirt_path", "soul_sand", "honey_block", "cake", "repeater", "comparator", "daylight_detector", "lectern", "grindstone",
                "bell", "scaffolding", "end_portal_frame", "composter", "stonecutter", "sculk_sensor", "pointed", "amethyst_cluster",
                "bud", "turtle_egg", "pickle", "conduit", "lightning_rod", "dragon_egg", "fence", "wall", "door", "gate", "ladder", "vine");
        }

        private boolean openDoor(int i, int state) { return doorName(name[i]) && "true".equals(prop(state, "open")); }

        /** Collision box of any kind (cannot walk through). Open doors/gates and climbables do not collide. */
        public boolean isObstacle(int state) {
            if (state < 0) return true;
            int i = index(state);
            if (i < 0) return state != 0;
            if (climbableName(name[i]) || openDoor(i, state)) return false;
            return box[i];
        }

        /** Free to walk through at feet/head height (air-likes, plants, ladders, vines, open doors). */
        public boolean isPassable(int state) {
            if (state < 0) return false;
            int i = index(state);
            if (i < 0) return state == 0;
            if (climbableName(name[i]) || openDoor(i, state)) return true;
            return !box[i] && !liquid(name[i]) && !danger(name[i]);
        }

        /** A full solid cube that is safe to stand on. */
        public boolean isStandable(int state) {
            if (state < 0) return false;
            int i = index(state);
            if (i < 0) return state != 0;
            return box[i] && !partial(name[i]) && !danger(name[i]) && !liquid(name[i]);
        }

        public boolean isLiquid(int state) {
            int i = index(state);
            return i >= 0 && liquid(name[i]);
        }

        public boolean isWater(int state) {
            int i = index(state);
            if (i < 0) return false;
            return waterName(name[i]) || "true".equals(prop(state, "waterlogged"));
        }

        public boolean isLava(int state) {
            int i = index(state);
            return i >= 0 && name[i].equals("lava");
        }

        public boolean isClimbable(int state) {
            int i = index(state);
            return i >= 0 && climbableName(name[i]);
        }

        /** A closed door / gate / trapdoor that can be opened by hand. */
        public boolean isClosedDoor(int state) {
            int i = index(state);
            return i >= 0 && doorName(name[i]) && "false".equals(prop(state, "open"));
        }


        // ------------------------------------------------------------------ collision shapes (minecraft-data blockCollisionShapes.json)

        /** A full 1x1x1 cube: {minX, minY, minZ, maxX, maxY, maxZ}. */
        public static final double[][] FULL = {{0, 0, 0, 1, 1, 1}};
        private int[] shapeOfState;          // state id -> shape id (-1 = none)
        private double[][][] shapeBoxes;     // shape id -> boxes

        public boolean hasShapes() { return shapeBoxes != null; }

        /**
         * Reads blockCollisionShapes.json: {"blocks": {name: shapeId | [shapeId per state]}, "shapes": {id: [[x1,y1,z1,x2,y2,z2], ...]}}.
         * The data is checked against the block registry before it is accepted.
         * @return null when accepted, otherwise the reason it was rejected (the previous shapes stay in use)
         */
        @SuppressWarnings("unchecked")
        public String loadShapes(String json) {
            Object rootO;
            try { rootO = Json.parse(json); } catch (RuntimeException e) { return "invalid JSON: " + e.getMessage(); }
            if (!(rootO instanceof Map)) return "root is not an object";
            Map<String, Object> root = (Map<String, Object>) rootO;
            if (!(root.get("blocks") instanceof Map) || !(root.get("shapes") instanceof Map)) return "missing blocks/shapes";
            Map<String, Object> blocksM = (Map<String, Object>) root.get("blocks");
            Map<String, Object> shapesM = (Map<String, Object>) root.get("shapes");
            int maxId = -1;
            for (String k : shapesM.keySet()) { try { maxId = Math.max(maxId, Integer.parseInt(k)); } catch (NumberFormatException e) { return "bad shape id " + k; } }
            double[][][] boxes = new double[maxId + 1][][];
            for (Map.Entry<String, Object> e : shapesM.entrySet()) {
                if (!(e.getValue() instanceof List)) return "bad shape " + e.getKey();
                List<Object> bl = (List<Object>) e.getValue();
                double[][] arr = new double[bl.size()][];
                for (int i = 0; i < arr.length; i++) {
                    if (!(bl.get(i) instanceof List) || ((List<Object>) bl.get(i)).size() != 6) return "bad box in shape " + e.getKey();
                    List<Object> v = (List<Object>) bl.get(i);
                    arr[i] = new double[6];
                    for (int k = 0; k < 6; k++) {
                        if (!(v.get(k) instanceof Number)) return "bad number in shape " + e.getKey();
                        arr[i][k] = ((Number) v.get(k)).doubleValue();
                        double lim = (k == 1 || k == 4) ? 1.5 : 1.0; // fences, walls and gates are 1.5 tall
                        if (arr[i][k] < -0.001 || arr[i][k] > lim + 0.001) return "box outside the block in shape " + e.getKey();
                    }
                }
                boxes[Integer.parseInt(e.getKey())] = arr;
            }
            int maxState = -1;
            for (int i = 0; i < min.length; i++) maxState = Math.max(maxState, max[i]);
            if (maxState < 0) return "block registry is empty";
            int[] of = new int[maxState + 1];
            Arrays.fill(of, -1);
            int rows = 0, matched = 0, arrays = 0, arraysFull = 0;
            for (int i = 0; i < name.length; i++) {
                rows++;
                Object v = blocksM.get(name[i]);
                if (v == null) continue;
                matched++;
                int count = max[i] - min[i] + 1;
                if (v instanceof Number) {
                    int id = ((Number) v).intValue();
                    if (id < 0 || id >= boxes.length || boxes[id] == null) return "unknown shape id " + id + " for " + name[i];
                    for (int st = min[i]; st <= max[i]; st++) of[st] = id;
                } else if (v instanceof List) {
                    List<Object> l = (List<Object>) v;
                    arrays++;
                    if (l.size() == count) arraysFull++;
                    for (int k = 0; k < count; k++) {
                        Object o = l.get(Math.min(k, l.size() - 1));
                        if (!(o instanceof Number)) return "bad shape list for " + name[i];
                        int id = ((Number) o).intValue();
                        if (id < 0 || id >= boxes.length || boxes[id] == null) return "unknown shape id " + id + " for " + name[i];
                        of[min[i] + k] = id;
                    }
                } else return "bad entry for " + name[i];
            }
            if (rows > 20 && matched < rows * 0.95) return "only " + matched + " of " + rows + " blocks have shapes (wrong game version?)";
            if (arrays > 5 && arraysFull < arrays * 0.98) return "per-state shape lists do not match the state counts (wrong game version?)";
            // spot checks on well-known blocks (only when the registry contains them)
            for (int i = 0; i < name.length; i++) {
                double[][] b0 = of[min[i]] < 0 ? null : boxes[of[min[i]]];
                String n = name[i];
                if (n.equals("air") && b0 != null && b0.length != 0) return "air has a collision shape";
                if (n.equals("stone") && !isFullCube(b0)) return "stone is not a full cube";
                if (n.equals("bedrock") && !isFullCube(b0)) return "bedrock is not a full cube";
                if (n.equals("oak_slab")) {
                    boolean half = false;
                    for (int st = min[i]; st <= max[i]; st++) { double[][] b = of[st] < 0 ? null : boxes[of[st]]; if (b != null && b.length == 1 && Math.abs((b[0][4] - b[0][1]) - 0.5) < 1e-6) half = true; }
                    if (!half) return "oak_slab has no half-height shape";
                }
                if (n.equals("oak_stairs")) {
                    boolean two = false;
                    for (int st = min[i]; st <= max[i]; st++) { double[][] b = of[st] < 0 ? null : boxes[of[st]]; if (b != null && b.length >= 2) two = true; }
                    if (!two) return "oak_stairs has no multi-box shape";
                }
            }
            shapeBoxes = boxes;
            shapeOfState = of;
            return null;
        }

        private static boolean isFullCube(double[][] b) {
            return b != null && b.length == 1 && b[0][0] == 0 && b[0][1] == 0 && b[0][2] == 0 && b[0][3] == 1 && b[0][4] == 1 && b[0][5] == 1;
        }

        /**
         * Collision boxes of a block state, relative to the block corner; null = nothing to collide with.
         * With shapes loaded these are the real shapes; without them every "block" bounding box is a full cube
         * (open doors and climbables excepted), exactly like the planner's obstacle test.
         */
        public double[][] collisionBoxes(int state) {
            if (state <= 0) return null;
            if (shapeBoxes != null) {
                if (state >= shapeOfState.length) return FULL;
                int id = shapeOfState[state];
                if (id < 0) { int i = index(state); return i >= 0 && box[i] ? FULL : null; }
                double[][] b = shapeBoxes[id];
                return b.length == 0 ? null : b;
            }
            return isObstacle(state) ? FULL : null;
        }


        /** A block the player simply walks up onto (every box at most half a block tall: bottom slab, carpet, closed trapdoor...). Needs shapes. */
        public boolean isLowStep(int state) {
            if (shapeBoxes == null || state <= 0) return false;
            double[][] b = collisionBoxes(state);
            if (b == null) return false;
            for (double[] bx : b) if (bx[4] > 0.5 + 1e-6) return false;
            return true;
        }

        /** Boolean mask over state ids: true for every state of the named blocks. */
        public boolean[] stateMask(java.util.Set<String> names) {
            int maxState = 0;
            for (int i = 0; i < max.length; i++) maxState = Math.max(maxState, max[i]);
            boolean[] m = new boolean[maxState + 1];
            for (int i = 0; i < name.length; i++) if (names.contains(name[i])) for (int st = min[i]; st <= max[i]; st++) m[st] = true;
            return m;
        }

        // ------------------------------------------------------------------ block properties that change movement

        /** Slipperiness: ice 0.98, blue ice 0.989, slime 0.8, everything else 0.6 (air included). */
        public float friction(int state) {
            int i = index(state);
            if (i < 0) return 0.6f;
            String n = name[i];
            if (n.equals("blue_ice")) return 0.989f;
            if (n.equals("ice") || n.equals("packed_ice") || n.equals("frosted_ice")) return 0.98f;
            if (n.equals("slime_block")) return 0.8f;
            return 0.6f;
        }

        /** Horizontal speed multiplier of the block (soul sand and honey: 0.4). */
        public float speedFactor(int state) {
            int i = index(state);
            return i >= 0 && (name[i].equals("soul_sand") || name[i].equals("honey_block")) ? 0.4f : 1f;
        }

        public float jumpFactor(int state) {
            int i = index(state);
            return i >= 0 && name[i].equals("honey_block") ? 0.5f : 1f;
        }

        public boolean isSlime(int state) { int i = index(state); return i >= 0 && name[i].equals("slime_block"); }

        /** Movement multiplier applied while the body is inside the block (x, y, z), or null. */
        public double[] stuckMultiplier(int state) {
            int i = index(state);
            if (i < 0) return null;
            String n = name[i];
            if (n.equals("cobweb")) return new double[]{0.25, 0.05, 0.25};
            if (n.equals("sweet_berry_bush")) return new double[]{0.8, 0.75, 0.8};
            if (n.equals("powder_snow")) return new double[]{0.9, 1.5, 0.9};
            return null;
        }

        /** Fluid surface height inside the cell (0 = no water): source 8/9, flowing (8-level)/9, falling 8/9. */
        public double waterOwnHeight(int state) {
            if (!isWater(state)) return 0;
            int i = index(state);
            if (i >= 0 && name[i].equals("water")) {
                String lv = prop(state, "level");
                int level = 0;
                try { if (lv != null) level = Integer.parseInt(lv); } catch (NumberFormatException e) { level = 0; }
                if (level >= 1 && level <= 7) return (8 - level) / 9.0;
            }
            return 8 / 9.0;
        }

        public double lavaOwnHeight(int state) {
            if (!isLava(state)) return 0;
            String lv = prop(state, "level");
            int level = 0;
            try { if (lv != null) level = Integer.parseInt(lv); } catch (NumberFormatException e) { level = 0; }
            if (level >= 1 && level <= 7) return (8 - level) / 9.0;
            return 8 / 9.0;
        }

        public boolean isBreakable(int state) {
            int i = index(state);
            if (i < 0) return state > 0;
            return hard[i] >= 0 && box[i] && !liquid(name[i]) && !protectedName(name[i]) && !climbableName(name[i]);
        }
    }
}
