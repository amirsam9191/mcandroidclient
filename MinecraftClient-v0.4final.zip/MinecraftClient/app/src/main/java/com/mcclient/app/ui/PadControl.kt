package com.mcclient.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mcclient.app.game.Session
import kotlinx.coroutines.delay

/** A round-ish pad button that reports "held" while the finger is down. */
@Composable
private fun HoldKey(label: String, active: Boolean = false, onHold: (Boolean) -> Unit) {
    val cb = rememberUpdatedState(onHold)
    Box(
        Modifier
            .size(46.dp)
            .background(if (active) Color(0xCC3E8E41) else Color(0xAA000000), RoundedCornerShape(10.dp))
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    cb.value(true)
                    try { tryAwaitRelease() } finally { cb.value(false) }
                })
            },
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 15.sp) }
}

/** Like [HoldKey] but calls [onRepeat] every 80 ms while held (turning the camera). */
@Composable
private fun RepeatKey(label: String, onRepeat: () -> Unit) {
    var down by remember { mutableStateOf(false) }
    val cb = rememberUpdatedState(onRepeat)
    LaunchedEffect(down) {
        while (down) { cb.value(); delay(80) }
    }
    HoldKey(label) { down = it }
}

@Composable
private fun TapKey(label: String, active: Boolean = false, onTap: () -> Unit) {
    Box(
        Modifier
            .size(46.dp)
            .background(if (active) Color(0xCC3E8E41) else Color(0xAA000000), RoundedCornerShape(10.dp))
            .pointerInput(Unit) { detectTapGestures(onTap = { onTap() }) },
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 13.sp) }
}

/**
 * On-screen movement pad: move (forward/back/strafe), jump, sneak, sprint toggle, camera turn, fly toggle (where the server allows it),
 * and the two game clicks. While something is held, the input is refreshed every 100 ms; the core releases it 250 ms after the last call.
 */
@Composable
fun PadControl(session: Session) {
    var fwd by remember { mutableFloatStateOf(0f) }
    var strafe by remember { mutableFloatStateOf(0f) }
    var jump by remember { mutableStateOf(false) }
    var sneak by remember { mutableStateOf(false) }
    var sprint by remember { mutableStateOf(false) }
    var flying by remember { mutableStateOf(session.isFlying) }

    LaunchedEffect(fwd, strafe, jump, sneak, sprint) {
        if (fwd != 0f || strafe != 0f || jump || sneak) {
            while (true) { session.manualMove(fwd, strafe, jump, sneak, sprint); delay(100) }
        } else {
            session.manualMove(0f, 0f, false, false, false)
        }
    }
    DisposableEffect(Unit) { onDispose { session.manualMove(0f, 0f, false, false, false) } }

    // The pad keeps the same layout in RTL and LTR: left is always left.
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(Modifier.padding(4.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.Bottom) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                HoldKey("▲") { fwd = if (it) 1f else 0f }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    HoldKey("◀") { strafe = if (it) 1f else 0f }
                    HoldKey("▼") { fwd = if (it) -1f else 0f }
                    HoldKey("▶") { strafe = if (it) -1f else 0f }
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    HoldKey("پرش", jump) { jump = it }
                    HoldKey("خزش", sneak) { sneak = it }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TapKey("دویدن", sprint) { sprint = !sprint }
                    if (session.mayFly) TapKey(if (flying) "فرود" else "پرواز", flying) {
                        flying = !flying
                        session.setFlying(flying)
                    }
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                RepeatKey("⬆") { session.manualTurn(0f, -6f) }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    RepeatKey("⟲") { session.manualTurn(-9f, 0f) }
                    RepeatKey("⬇") { session.manualTurn(0f, 6f) }
                    RepeatKey("⟳") { session.manualTurn(9f, 0f) }
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                TapKey("چپ") { session.leftClick() }
                TapKey("راست") { session.rightClick() }
            }
        }
    }
}
