package com.mcclient.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Turns NBT/JSON text components (and legacy section-sign strings) into flat styled spans. */
public final class Chat {
    private Chat() {}

    public static final int WHITE = 0xFFFFFFFF, GRAY = 0xFFAAAAAA, RED = 0xFFFF5555, GREEN = 0xFF55FF55, YELLOW = 0xFFFFFF55;

    public static final int[] LEGACY = {
        0xFF000000, 0xFF0000AA, 0xFF00AA00, 0xFF00AAAA, 0xFFAA0000, 0xFFAA00AA, 0xFFFFAA00, 0xFFAAAAAA,
        0xFF555555, 0xFF5555FF, 0xFF55FF55, 0xFF55FFFF, 0xFFFF5555, 0xFFFF55FF, 0xFFFFFF55, 0xFFFFFFFF
    };
    private static final String[] NAMES = {
        "black", "dark_blue", "dark_green", "dark_aqua", "dark_red", "dark_purple", "gold", "gray",
        "dark_gray", "blue", "green", "aqua", "red", "light_purple", "yellow", "white"
    };

    /** A click action attached to a text component: run_command, suggest_command, open_url, copy_to_clipboard, change_page, open_file. */
    public static final class Click {
        public final String action, value;
        public Click(String action, String value) { this.action = action; this.value = value; }
        @Override public boolean equals(Object o) { return o instanceof Click && ((Click) o).action.equals(action) && ((Click) o).value.equals(value); }
        @Override public int hashCode() { return action.hashCode() * 31 + value.hashCode(); }
        @Override public String toString() { return "Click(" + action + ", " + value + ")"; }
    }

    /** A hover action: show_text (spans), show_item (id/count/tag) or show_entity (type/id/name). */
    public static final class Hover {
        public final String action;
        public final List<Span> text;      // show_text content, or the entity name
        public final String id;            // item id (show_item) or entity uuid (show_entity)
        public final int count;            // show_item
        public final Object tag;           // show_item: parsed NBT/JSON of "tag" (Map) or null
        public final String entityType;    // show_entity
        public Hover(String action, List<Span> text, String id, int count, Object tag, String entityType) {
            this.action = action; this.text = text == null ? Collections.<Span>emptyList() : text;
            this.id = id; this.count = count; this.tag = tag; this.entityType = entityType;
        }
        /** Plain text lines to show in a tooltip. */
        public List<List<Span>> lines() {
            List<List<Span>> out = new ArrayList<>();
            if ("show_item".equals(action)) {
                List<Span> head = new ArrayList<>();
                head.add(new Span(String.valueOf(id) + (count > 1 ? " x" + count : ""), WHITE));
                out.add(head);
            } else if ("show_entity".equals(action)) {
                if (!text.isEmpty()) out.add(text);
                out.add(java.util.Collections.singletonList(new Span(String.valueOf(entityType), GRAY)));
            } else {
                out.addAll(splitLines(text));
            }
            return out;
        }
        @Override public String toString() { return "Hover(" + action + ")"; }
    }

    /** Splits spans at '\n' into lines. */
    public static List<List<Span>> splitLines(List<Span> spans) {
        List<List<Span>> lines = new ArrayList<>();
        List<Span> cur = new ArrayList<>();
        for (Span sp : spans) {
            String t = sp.text;
            int from = 0;
            while (true) {
                int nl = t.indexOf('\n', from);
                String part = nl < 0 ? t.substring(from) : t.substring(from, nl);
                if (!part.isEmpty()) cur.add(sp.withText(part));
                if (nl < 0) break;
                lines.add(cur); cur = new ArrayList<>();
                from = nl + 1;
            }
        }
        lines.add(cur);
        return lines;
    }

    public static final class Span {
        public final String text;
        public final int color;
        public final boolean bold, italic, underline, strike, obfuscated;
        /** Resource-pack font id ("minecraft:default", "minecraft:uniform", "ns:name") or null for the default font. */
        public final String font;
        public final Click click;
        public final Hover hover;
        /** Text inserted into the chat box on shift-click (the "insertion" field) or null. */
        public final String insertion;

        public Span(String text) { this(text, WHITE, false, false, false, false, false); }
        public Span(String text, int color) { this(text, color, false, false, false, false, false); }
        public Span(String text, int color, boolean bold, boolean italic, boolean underline, boolean strike, boolean obfuscated) {
            this(text, color, bold, italic, underline, strike, obfuscated, null, null, null, null);
        }
        public Span(String text, int color, boolean bold, boolean italic, boolean underline, boolean strike, boolean obfuscated,
                    String font, Click click, Hover hover, String insertion) {
            this.text = text; this.color = color; this.bold = bold; this.italic = italic;
            this.underline = underline; this.strike = strike; this.obfuscated = obfuscated;
            this.font = font; this.click = click; this.hover = hover; this.insertion = insertion;
        }
        /** Same style with other text (used when a layout splits a span). */
        public Span withText(String t) {
            return new Span(t, color, bold, italic, underline, strike, obfuscated, font, click, hover, insertion);
        }
        public boolean hasEvents() { return click != null || hover != null; }
        @Override public String toString() { return "Span(" + text + ", #" + Integer.toHexString(color) + (bold ? ", bold" : "") + (font != null ? ", font=" + font : "") + (click != null ? ", " + click : "") + (hover != null ? ", " + hover : "") + ")"; }
    }

    private static final class St {
        final int color; final boolean bold, italic, underline, strike, obf;
        final String font, insertion; final Click click; final Hover hover;
        St() { this(WHITE, false, false, false, false, false, null, null, null, null); }
        St(int c, boolean b, boolean i, boolean u, boolean s, boolean o, String f, Click ck, Hover hv, String ins) {
            color = c; bold = b; italic = i; underline = u; strike = s; obf = o; font = f; click = ck; hover = hv; insertion = ins;
        }
        St color(int c) { return new St(c, bold, italic, underline, strike, obf, font, click, hover, insertion); }
        St bold(boolean v) { return new St(color, v, italic, underline, strike, obf, font, click, hover, insertion); }
        St italic(boolean v) { return new St(color, bold, v, underline, strike, obf, font, click, hover, insertion); }
        St underline(boolean v) { return new St(color, bold, italic, v, strike, obf, font, click, hover, insertion); }
        St strike(boolean v) { return new St(color, bold, italic, underline, v, obf, font, click, hover, insertion); }
        St obf(boolean v) { return new St(color, bold, italic, underline, strike, v, font, click, hover, insertion); }
        /** A legacy colour code: resets the text formatting but keeps font and events (they belong to the component, not the string). */
        St legacyColor(int c) { return new St(c, false, false, false, false, false, font, click, hover, insertion); }
        /** The "r" code: back to the plain component style but with its events. */
        St legacyReset() { return new St(WHITE, false, false, false, false, false, font, click, hover, insertion); }
    }

    public static List<Span> fromAny(Object n) {
        List<Span> out = new ArrayList<>();
        try {
            flatten(n, new St(), out);
        } catch (RuntimeException e) {
            out.add(new Span(String.valueOf(n)));
        }
        List<Span> res = new ArrayList<>();
        for (Span s : out) if (!s.text.isEmpty()) res.add(s);
        return res;
    }

    public static String plain(Object n) {
        StringBuilder sb = new StringBuilder();
        for (Span s : fromAny(n)) sb.append(s.text);
        return sb.toString();
    }

    public static List<Span> legacy(String s) {
        List<Span> o = new ArrayList<>();
        addLegacy(s, new St(), o);
        return o;
    }

    /** For JSON text as sent in the login phase and in status responses. */
    public static List<Span> fromJsonText(String s) {
        String t = s.trim();
        if (t.isEmpty()) return Collections.emptyList();
        try {
            char c = t.charAt(0);
            if (c == '{' || c == '[' || c == '"') return fromAny(Json.parse(t));
            return legacy(t);
        } catch (RuntimeException e) {
            return legacy(t);
        }
    }

    public static String plainFromJsonText(String s) {
        StringBuilder sb = new StringBuilder();
        for (Span sp : fromJsonText(s)) sb.append(sp.text);
        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    private static void flatten(Object node, St st, List<Span> out) {
        if (node == null) return;
        if (node instanceof String) { addLegacy((String) node, st, out); return; }
        if (node instanceof Number || node instanceof Boolean) { addLegacy(node.toString(), st, out); return; }
        if (node instanceof List) { for (Object e : (List<Object>) node) flatten(e, st, out); return; }
        if (node instanceof Map) {
            Map<String, Object> m = (Map<String, Object>) node;
            St s = style(m, st);
            if (m.containsKey("text")) addLegacy(String.valueOf(m.get("text")), s, out);
            else if (m.containsKey("translate")) translate(m, s, out);
            else if (m.containsKey("keybind")) addLegacy(String.valueOf(m.get("keybind")), s, out);
            else if (m.containsKey("selector")) addLegacy(String.valueOf(m.get("selector")), s, out);
            else if (m.containsKey("score") && m.get("score") instanceof Map) {
                Object v = ((Map<String, Object>) m.get("score")).get("value");
                addLegacy(v == null ? "" : v.toString(), s, out);
            }
            Object extra = m.get("extra");
            if (extra instanceof List) for (Object e : (List<Object>) extra) flatten(e, s, out);
            return;
        }
        addLegacy(node.toString(), st, out);
    }

    private static boolean flag(Object v, boolean cur) {
        if (v == null) return cur;
        if (v instanceof Boolean) return (Boolean) v;
        if (v instanceof Number) return ((Number) v).intValue() != 0;
        if (v instanceof String) return "true".equals(v);
        return cur;
    }

    private static int parseColor(String s, int dflt) {
        if (s.startsWith("#") && s.length() == 7) {
            try { return 0xFF000000 | Integer.parseInt(s.substring(1), 16); } catch (NumberFormatException e) { return dflt; }
        }
        for (int i = 0; i < NAMES.length; i++) if (NAMES[i].equals(s)) return LEGACY[i];
        return dflt;
    }

    @SuppressWarnings("unchecked")
    private static St style(Map<String, Object> m, St st) {
        int c = st.color;
        Object cs = m.get("color");
        if (cs instanceof String) c = parseColor((String) cs, c);
        String font = m.get("font") instanceof String ? (String) m.get("font") : st.font;
        String ins = m.get("insertion") instanceof String ? (String) m.get("insertion") : st.insertion;
        Click click = st.click;
        Object ce = m.containsKey("clickEvent") ? m.get("clickEvent") : m.get("click_event");
        if (ce instanceof Map) {
            Map<String, Object> cm = (Map<String, Object>) ce;
            if (cm.get("action") instanceof String && cm.get("value") != null) click = new Click((String) cm.get("action"), String.valueOf(cm.get("value")));
        }
        Hover hover = st.hover;
        Object he = m.containsKey("hoverEvent") ? m.get("hoverEvent") : m.get("hover_event");
        if (he instanceof Map) {
            Hover h = parseHover((Map<String, Object>) he);
            if (h != null) hover = h;
        }
        return new St(c, flag(m.get("bold"), st.bold), flag(m.get("italic"), st.italic),
            flag(m.get("underlined"), st.underline), flag(m.get("strikethrough"), st.strike), flag(m.get("obfuscated"), st.obf),
            font, click, hover, ins);
    }

    /** 1.20.4 format: {"action":"show_text","contents":...}; the old "value" key is accepted for show_text too. */
    @SuppressWarnings("unchecked")
    private static Hover parseHover(Map<String, Object> he) {
        Object a = he.get("action");
        if (!(a instanceof String)) return null;
        String action = (String) a;
        Object contents = he.containsKey("contents") ? he.get("contents") : he.get("value");
        if (action.equals("show_text")) {
            return new Hover(action, fromAny(contents), null, 0, null, null);
        } else if (action.equals("show_item")) {
            if (contents instanceof Map) {
                Map<String, Object> im = (Map<String, Object>) contents;
                Object tag = im.get("tag");
                if (tag instanceof String) { try { tag = Json.parse((String) tag); } catch (RuntimeException e) { /* SNBT: keep as a string */ } }
                return new Hover(action, null, String.valueOf(im.get("id")), im.get("count") instanceof Number ? ((Number) im.get("count")).intValue() : 1, tag, null);
            }
            return new Hover(action, null, String.valueOf(contents), 1, null, null);
        } else if (action.equals("show_entity") && contents instanceof Map) {
            Map<String, Object> em = (Map<String, Object>) contents;
            return new Hover(action, em.containsKey("name") ? fromAny(em.get("name")) : null, String.valueOf(em.get("id")), 0, null, String.valueOf(em.get("type")));
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private static void translate(Map<String, Object> m, St s, List<Span> out) {
        String key = String.valueOf(m.get("translate"));
        List<Object> args = m.get("with") instanceof List ? (List<Object>) m.get("with") : Collections.<Object>emptyList();
        String fmt = TR.get(key);
        if (fmt == null && m.get("fallback") instanceof String) fmt = (String) m.get("fallback");
        if (fmt == null) {
            addLegacy(key, s, out);
            for (Object a : args) { addLegacy(" ", s, out); flatten(a, s, out); }
            return;
        }
        StringBuilder sb = new StringBuilder();
        int auto = 0, i = 0;
        while (i < fmt.length()) {
            char c = fmt.charAt(i);
            if (c == '%' && i + 1 < fmt.length()) {
                if (fmt.charAt(i + 1) == '%') { sb.append('%'); i += 2; continue; }
                int j = i + 1, n = 0;
                boolean has = false;
                while (j < fmt.length() && Character.isDigit(fmt.charAt(j))) { n = n * 10 + (fmt.charAt(j) - '0'); j++; has = true; }
                if (has && j < fmt.length() && fmt.charAt(j) == '$') j++;
                if (j < fmt.length() && fmt.charAt(j) == 's') {
                    if (sb.length() > 0) { addLegacy(sb.toString(), s, out); sb.setLength(0); }
                    int idx = has ? n - 1 : auto++;
                    if (idx >= 0 && idx < args.size()) flatten(args.get(idx), s, out);
                    i = j + 1;
                    continue;
                }
            }
            sb.append(c);
            i++;
        }
        if (sb.length() > 0) addLegacy(sb.toString(), s, out);
    }

    private static void addLegacy(String text, St st, List<Span> out) {
        if (text.isEmpty()) return;
        St cur = st;
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (i < text.length()) {
            char c = text.charAt(i);
            if (c == '\u00A7' && i + 1 < text.length()) {
                char code = Character.toLowerCase(text.charAt(i + 1));
                int ci = "0123456789abcdef".indexOf(code);
                if (sb.length() > 0) { out.add(span(sb.toString(), cur)); sb.setLength(0); }
                if (ci >= 0) cur = cur.legacyColor(LEGACY[ci]);
                else if (code == 'l') cur = cur.bold(true);
                else if (code == 'o') cur = cur.italic(true);
                else if (code == 'n') cur = cur.underline(true);
                else if (code == 'm') cur = cur.strike(true);
                else if (code == 'k') cur = cur.obf(true);
                else if (code == 'r') cur = cur.legacyReset();
                i += 2;
                continue;
            }
            sb.append(c);
            i++;
        }
        if (sb.length() > 0) out.add(span(sb.toString(), cur));
    }

    private static Span span(String t, St s) { return new Span(t, s.color, s.bold, s.italic, s.underline, s.strike, s.obf, s.font, s.click, s.hover, s.insertion); }

    /** English vanilla translations for the keys that appear in everyday chat. Unknown keys render as the key itself. */
    public static final Map<String, String> TR = new HashMap<>();
    static {
        String[][] t = {
            {"chat.type.text", "<%s> %s"}, {"chat.type.text.narrate", "%s says %s"}, {"chat.type.emote", "* %s %s"},
            {"chat.type.announcement", "[%s] %s"}, {"chat.type.admin", "[%s: %s]"}, {"chat.type.team.text", "%s <%s> %s"},
            {"chat.type.team.sent", "-> %s <%s> %s"},
            {"commands.message.display.incoming", "%s whispers to you: %s"}, {"commands.message.display.outgoing", "You whisper to %s: %s"},
            {"chat.type.advancement.task", "%s has made the advancement %s"}, {"chat.type.advancement.goal", "%s has reached the goal %s"},
            {"chat.type.advancement.challenge", "%s has completed the challenge %s"},
            {"multiplayer.player.joined", "%s joined the game"}, {"multiplayer.player.joined.renamed", "%s (formerly known as %s) joined the game"},
            {"multiplayer.player.left", "%s left the game"},
            {"multiplayer.disconnect.kicked", "Kicked by an operator"}, {"multiplayer.disconnect.banned", "You are banned from this server"},
            {"multiplayer.disconnect.banned.reason", "You are banned from this server.\nReason: %s"},
            {"multiplayer.disconnect.server_shutdown", "Server closed"}, {"multiplayer.disconnect.not_whitelisted", "You are not white-listed on this server!"},
            {"multiplayer.disconnect.duplicate_login", "You logged in from another location"}, {"multiplayer.disconnect.idling", "You have been idle for too long!"},
            {"multiplayer.disconnect.flying", "Flying is not enabled on this server"}, {"multiplayer.disconnect.name_taken", "That name is already taken"},
            {"multiplayer.disconnect.server_full", "The server is full!"}, {"multiplayer.disconnect.invalid_player_movement", "Invalid move player packet received"},
            {"multiplayer.disconnect.chat_validation_failed", "Chat message validation failure"},
            {"multiplayer.disconnect.too_many_pending_chats", "Too many unacknowledged chat messages"},
            {"multiplayer.disconnect.unsigned_chat", "Received chat packet with missing or invalid signature."},
            {"multiplayer.disconnect.incompatible", "Incompatible client! Please use %s"},
            {"disconnect.timeout", "Timed out"}, {"disconnect.spam", "Kicked for spamming"}, {"disconnect.kicked", "Was kicked from the game"},
            {"disconnect.disconnected", "Disconnected"}, {"disconnect.lost", "Connection Lost"},
            {"death.attack.generic", "%1$s died"}, {"death.attack.player", "%1$s was slain by %2$s"}, {"death.attack.mob", "%1$s was slain by %2$s"},
            {"death.attack.fall", "%1$s hit the ground too hard"}, {"death.attack.lava", "%1$s tried to swim in lava"}, {"death.attack.drown", "%1$s drowned"},
            {"death.attack.explosion", "%1$s blew up"}, {"death.attack.arrow", "%1$s was shot by %2$s"}, {"death.attack.onFire", "%1$s burned to death"},
            {"death.attack.inFire", "%1$s went up in flames"}, {"death.attack.outOfWorld", "%1$s fell out of the world"},
            {"death.attack.starve", "%1$s starved to death"}, {"death.attack.magic", "%1$s was killed by magic"}, {"death.attack.cactus", "%1$s was pricked to death"},
            {"death.fell.accident.generic", "%1$s fell from a high place"},
            {"commands.gamemode.success.self", "Set own game mode to %s"}, {"gameMode.survival", "Survival Mode"}, {"gameMode.creative", "Creative Mode"},
            {"gameMode.adventure", "Adventure Mode"}, {"gameMode.spectator", "Spectator Mode"}
        };
        for (String[] e : t) TR.put(e[0], e[1]);
    }
}
