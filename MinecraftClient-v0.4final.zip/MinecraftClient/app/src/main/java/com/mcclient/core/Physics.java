package com.mcclient.core;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Client-side player physics for Minecraft 1.20.4, ported from LivingEntity.travel / Entity.move / Entity.collide:
 * <ul>
 *   <li>input x0.98 (sneak x0.3), ground acceleration speed*0.216/friction^3, air 0.02 (sprint 0.026), friction block*0.91, gravity (vy-0.08)*0.98;</li>
 *   <li>jump 0.42 (+0.1 per jump-boost level, honey x0.5) with a 10 tick delay and the +0.2 sprint kick;</li>
 *   <li>water (0.02, x0.8 / sprint x0.9, vy x0.8 and -g/16, +0.04 swim up, exit pop 0.3), lava (x0.5, -g/4);</li>
 *   <li>ladders (clamp 0.15, climb 0.2, sneak holds), flying (vy x0.6, +-3*flySpeed), cobweb / berries / soul sand / honey / ice / slime;</li>
 *   <li>collision with the real block shapes: Y first, then the axis with the larger movement, step-up 0.6, no walking off edges while sneaking.</li>
 * </ul>
 * Differences from the real client: sin/cos use double Math instead of the lookup table; fluid flow pushes are not applied.
 */
public final class Physics {
    public static final double HALF_W = 0.3, HEIGHT = 1.8, SNEAK_HEIGHT = 1.5, STEP = 0.6, GRAVITY = 0.08, JUMP = 0.42;
    /** Steady-state distances per tick on 0.6 friction ground (documentation / planning values). */
    public static final double WALK = 0.2158, SPRINT = 0.2806;
    public static final UUID SPRINT_MODIFIER = UUID.fromString("662A6B8D-DA3E-4C1C-8813-96EA6097278D");

    /** One tick of keyboard-like input. */
    public static final class Input {
        public float forward, strafe;          // -1..1, left is positive strafe
        public boolean jump, sneak, sprint;
        public void clear() { forward = 0; strafe = 0; jump = false; sneak = false; sprint = false; }
        public Input copy() { Input i = new Input(); i.forward = forward; i.strafe = strafe; i.jump = jump; i.sneak = sneak; i.sprint = sprint; return i; }
    }

    public final World world;
    public double x, y, z, vx, vy, vz;
    public boolean onGround, horizontalCollision, verticalCollision, sprinting, sneaking, flying, mayFly;
    public boolean minorCollision;
    public float flySpeed = 0.05f;
    /** movement_speed attribute without the sprint modifier (0.1 by default). */
    public double speedBase = 0.1;
    public int jumpBoost;               // amplifier + 1, 0 = none
    public int levitation;              // amplifier + 1, 0 = none
    public boolean slowFalling, dolphinsGrace;
    public boolean enoughFood = true;   // food level > 6 (sprinting allowed)
    public int noJumpDelay;
    public double fallDistance;
    /** Set when landing cancelled creative flight: the session must tell the server (Player Abilities 0x20). */
    public boolean flightCancelled;
    // fluid state of the current tick
    public boolean inWater, inLava, eyeInWater;
    public double waterHeight, lavaHeight;
    /** Friction of the block walked on in the last tick (for tests / debugging). */
    public float lastFriction = 0.6f;
    private double[] stuck;

    public Physics(World w) { world = w; }

    // net.minecraft.util.Mth.sin / cos: a 65536 entry table (not Math.sin), so the velocities match the real client bit for bit
    private static final float[] SIN = new float[65536];
    static { for (int i = 0; i < 65536; i++) SIN[i] = (float) Math.sin((double) i * Math.PI * 2.0 / 65536.0); }
    public static float mthSin(float v) { return SIN[(int) (v * 10430.378F) & 65535]; }
    public static float mthCos(float v) { return SIN[(int) (v * 10430.378F + 16384.0F) & 65535]; }

    // ------------------------------------------------------------------ public queries

    public double height() { return sneaking ? SNEAK_HEIGHT : HEIGHT; }
    public double eyeHeight() { return sneaking ? 1.27 : 1.62; }
    public boolean inWater() { return inWater; }
    public boolean inLava() { return inLava; }

    /** True when the feet block is a ladder / vine (the CLIMBABLE tag). */
    public boolean onClimbable() {
        return world.climbable((int) Math.floor(x), (int) Math.floor(y), (int) Math.floor(z));
    }

    private static boolean eq(double a, double b) { return Math.abs(b - a) < 1.0E-5f; }

    // ------------------------------------------------------------------ collision

    private double[] box(double px, double py, double pz) {
        return new double[]{px - HALF_W, py, pz - HALF_W, px + HALF_W, py + height(), pz + HALF_W};
    }

    private List<double[]> shapesAround(double[] b, double reach) {
        List<double[]> out = new ArrayList<>();
        world.collectBoxes(b[0] - reach, b[1] - reach, b[2] - reach, b[3] + reach, b[4] + reach, b[5] + reach, out);
        return out;
    }

    private static boolean overlaps(double[] b, double[] s) {
        return b[3] > s[0] && b[0] < s[3] && b[4] > s[1] && b[1] < s[4] && b[5] > s[2] && b[2] < s[5];
    }

    /** True when no block shape intersects the box (touching does not count). */
    public boolean noCollision(double[] b) {
        for (double[] s : shapesAround(b, 0)) if (overlaps(b, s)) return false;
        return true;
    }

    /** True when the player's box at the given position is free of blocks. */
    public boolean freeAt(double px, double py, double pz) { return noCollision(box(px, py, pz)); }

    private boolean containsLiquid(double[] b) {
        int x0 = (int) Math.floor(b[0]), x1 = (int) Math.ceil(b[3]), y0 = (int) Math.floor(b[1]), y1 = (int) Math.ceil(b[4]);
        int z0 = (int) Math.floor(b[2]), z1 = (int) Math.ceil(b[5]);
        for (int bx = x0; bx < x1; bx++) for (int by = y0; by < y1; by++) for (int bz = z0; bz < z1; bz++) if (world.liquid(bx, by, bz)) return true;
        return false;
    }

    /** Entity.isFree: the box moved by (dx,dy,dz) has neither blocks nor liquid in it. */
    private boolean isFree(double dx, double dy, double dz) {
        double[] b = box(x + dx, y + dy, z + dz);
        return noCollision(b) && !containsLiquid(b);
    }

    private static double collideY(double[] b, List<double[]> shapes, double d) {
        for (double[] s : shapes) {
            if (Math.abs(d) < 1.0E-7) return 0;
            if (b[3] - 1e-7 > s[0] && b[0] + 1e-7 < s[3] && b[5] - 1e-7 > s[2] && b[2] + 1e-7 < s[5]) {
                if (d > 0) { double t = s[1] - b[4]; if (t >= -1e-7 && t < d) d = t; }
                else { double t = s[4] - b[1]; if (t <= 1e-7 && t > d) d = t; }
            }
        }
        return d;
    }

    private static double collideX(double[] b, List<double[]> shapes, double d) {
        for (double[] s : shapes) {
            if (Math.abs(d) < 1.0E-7) return 0;
            if (b[4] - 1e-7 > s[1] && b[1] + 1e-7 < s[4] && b[5] - 1e-7 > s[2] && b[2] + 1e-7 < s[5]) {
                if (d > 0) { double t = s[0] - b[3]; if (t >= -1e-7 && t < d) d = t; }
                else { double t = s[3] - b[0]; if (t <= 1e-7 && t > d) d = t; }
            }
        }
        return d;
    }

    private static double collideZ(double[] b, List<double[]> shapes, double d) {
        for (double[] s : shapes) {
            if (Math.abs(d) < 1.0E-7) return 0;
            if (b[3] - 1e-7 > s[0] && b[0] + 1e-7 < s[3] && b[4] - 1e-7 > s[1] && b[1] + 1e-7 < s[4]) {
                if (d > 0) { double t = s[2] - b[5]; if (t >= -1e-7 && t < d) d = t; }
                else { double t = s[5] - b[2]; if (t <= 1e-7 && t > d) d = t; }
            }
        }
        return d;
    }

    private static double[] moved(double[] b, double dx, double dy, double dz) {
        return new double[]{b[0] + dx, b[1] + dy, b[2] + dz, b[3] + dx, b[4] + dy, b[5] + dz};
    }

    /** Entity.collideWithShapes: Y first, then the axis with the larger movement, then the other. */
    private static double[] collideWithShapes(double mx, double my, double mz, double[] b, List<double[]> shapes) {
        if (shapes.isEmpty()) return new double[]{mx, my, mz};
        double d0 = mx, d1 = my, d2 = mz;
        double[] bb = b;
        if (d1 != 0) { d1 = collideY(bb, shapes, d1); if (d1 != 0) bb = moved(bb, 0, d1, 0); }
        boolean zFirst = Math.abs(d0) < Math.abs(d2);
        if (zFirst && d2 != 0) { d2 = collideZ(bb, shapes, d2); if (d2 != 0) bb = moved(bb, 0, 0, d2); }
        if (d0 != 0) { d0 = collideX(bb, shapes, d0); if (!zFirst && d0 != 0) bb = moved(bb, d0, 0, 0); }
        if (!zFirst && d2 != 0) d2 = collideZ(bb, shapes, d2);
        return new double[]{d0, d1, d2};
    }

    private static double hsq(double[] v) { return v[0] * v[0] + v[2] * v[2]; }

    /** Entity.collide including the 0.6 step-up. */
    private double[] collide(double mx, double my, double mz) {
        double[] b = box(x, y, z);
        List<double[]> shapes = shapesAround(b, Math.max(Math.max(Math.abs(mx), Math.abs(mz)), Math.abs(my)) + STEP + 1);
        double[] v = collideWithShapes(mx, my, mz, b, shapes);
        boolean fx = mx != v[0], fy = my != v[1], fz = mz != v[2];
        boolean ground = onGround || (fy && my < 0);
        if (ground && (fx || fz)) {
            double[] v1 = collideWithShapes(mx, STEP, mz, b, shapes);
            double[] expanded = {Math.min(b[0], b[0] + mx), b[1], Math.min(b[2], b[2] + mz), Math.max(b[3], b[3] + mx), b[4], Math.max(b[5], b[5] + mz)};
            double[] v2 = collideWithShapes(0, STEP, 0, expanded, shapes);
            if (v2[1] < STEP) {
                double[] v3 = collideWithShapes(mx, 0, mz, moved(b, 0, v2[1], 0), shapes);
                v3 = new double[]{v3[0] + v2[0], v3[1] + v2[1], v3[2] + v2[2]};
                if (hsq(v3) > hsq(v1)) v1 = v3;
            }
            if (hsq(v1) > hsq(v)) {
                double[] down = collideWithShapes(0, -v1[1] + my, 0, moved(b, v1[0], v1[1], v1[2]), shapes);
                return new double[]{v1[0] + down[0], v1[1] + down[1], v1[2] + down[2]};
            }
        }
        return v;
    }

    private boolean isAboveGround() {
        return onGround || (fallDistance < STEP && !noCollision(moved(box(x, y, z), 0, fallDistance - STEP, 0)));
    }

    /** Player.maybeBackOffFromEdge: sneaking never walks off a ledge. */
    private double[] backOffFromEdge(double mx, double mz) {
        if (!sneaking || flying || !isAboveGround()) return new double[]{mx, mz};
        double d0 = mx, d1 = mz;
        final double st = 0.05;
        double[] b = box(x, y, z);
        while (d0 != 0 && noCollision(moved(b, d0, -STEP, 0))) { if (d0 < st && d0 >= -st) d0 = 0; else if (d0 > 0) d0 -= st; else d0 += st; }
        while (d1 != 0 && noCollision(moved(b, 0, -STEP, d1))) { if (d1 < st && d1 >= -st) d1 = 0; else if (d1 > 0) d1 -= st; else d1 += st; }
        while (d0 != 0 && d1 != 0 && noCollision(moved(b, d0, -STEP, d1))) {
            if (d0 < st && d0 >= -st) d0 = 0; else if (d0 > 0) d0 -= st; else d0 += st;
            if (d1 < st && d1 >= -st) d1 = 0; else if (d1 > 0) d1 -= st; else d1 += st;
        }
        return new double[]{d0, d1};
    }

    /** The block that decides friction: the supporting block below the feet (centre column first, else the nearest corner). */
    private int[] supportCell(double offset) {
        int by = (int) Math.floor(y - offset);
        int cx = (int) Math.floor(x), cz = (int) Math.floor(z);
        if (world.boxes(cx, by, cz) != null || !onGround) return new int[]{cx, by, cz};
        int[] best = null;
        double bestD = Double.MAX_VALUE;
        for (int bx = (int) Math.floor(x - HALF_W); bx <= (int) Math.floor(x + HALF_W); bx++)
            for (int bz = (int) Math.floor(z - HALF_W); bz <= (int) Math.floor(z + HALF_W); bz++) {
                if (world.boxes(bx, by, bz) == null) continue;
                double d = (bx + 0.5 - x) * (bx + 0.5 - x) + (bz + 0.5 - z) * (bz + 0.5 - z);
                if (d < bestD) { bestD = d; best = new int[]{bx, by, bz}; }
            }
        return best != null ? best : new int[]{cx, by, cz};
    }

    /** Entity.move. */
    private void move(double mx, double my, double mz) {
        if (stuck != null && stuck[0] * stuck[0] + stuck[1] * stuck[1] + stuck[2] * stuck[2] > 1.0E-7) {
            mx *= stuck[0]; my *= stuck[1]; mz *= stuck[2];
            stuck = null;
            vx = 0; vy = 0; vz = 0;
        }
        double[] back = backOffFromEdge(mx, mz);
        mx = back[0]; mz = back[1];
        double[] c = collide(mx, my, mz);
        if (c[0] * c[0] + c[1] * c[1] + c[2] * c[2] > 1.0E-7) { x += c[0]; y += c[1]; z += c[2]; }
        horizontalCollision = !eq(mx, c[0]) || !eq(mz, c[2]);
        verticalCollision = my != c[1];
        // a collision that only brushes a wall at a shallow angle keeps sprinting alive (Entity.minorHorizontalCollision)
        minorCollision = horizontalCollision && Math.hypot(mx - c[0], mz - c[2]) < 0.05;
        onGround = verticalCollision && my < 0;
        if (c[1] < 0) fallDistance -= c[1];
        if (onGround || inWater) fallDistance = 0;
        if (horizontalCollision) {
            if (mx != c[0]) vx = 0;
            if (mz != c[2]) vz = 0;
        }
        if (my != c[1]) {
            int bx = (int) Math.floor(x), by = (int) Math.floor(y - 0.2), bz = (int) Math.floor(z);
            if (world.slime(bx, by, bz) && !sneaking) { if (vy < 0) vy = -vy; }
            else vy = 0;
        }
        float f = blockSpeedFactor();
        vx *= f; vz *= f;
        // blocks the body is inside of (cobweb, sweet berries, powder snow)
        int x0 = (int) Math.floor(x - HALF_W + 1e-7), x1 = (int) Math.floor(x + HALF_W - 1e-7);
        int z0 = (int) Math.floor(z - HALF_W + 1e-7), z1 = (int) Math.floor(z + HALF_W - 1e-7);
        int y0 = (int) Math.floor(y + 1e-7), y1 = (int) Math.floor(y + height() - 1e-7);
        for (int bx = x0; bx <= x1; bx++) for (int by = y0; by <= y1; by++) for (int bz = z0; bz <= z1; bz++) {
            double[] m = world.stuck(bx, by, bz);
            if (m != null) stuck = m;
        }
    }

    private float blockSpeedFactor() {
        int bx = (int) Math.floor(x), by = (int) Math.floor(y), bz = (int) Math.floor(z);
        float f = world.speedFactor(bx, by, bz);
        if (world.water(bx, by, bz)) return f;
        if (f == 1.0f) { int[] c = supportCell(0.500001); return world.speedFactor(c[0], c[1], c[2]); }
        return f;
    }

    private float blockJumpFactor() {
        int bx = (int) Math.floor(x), by = (int) Math.floor(y), bz = (int) Math.floor(z);
        float f = world.jumpFactor(bx, by, bz);
        if (f == 1.0f) { int[] c = supportCell(0.500001); return world.jumpFactor(c[0], c[1], c[2]); }
        return f;
    }

    // ------------------------------------------------------------------ fluids

    private void updateFluids() {
        inWater = false; inLava = false; waterHeight = 0; lavaHeight = 0;
        double minX = x - HALF_W + 0.001, maxX = x + HALF_W - 0.001, minY = y + 0.001, maxY = y + height() - 0.001;
        double minZ = z - HALF_W + 0.001, maxZ = z + HALF_W - 0.001;
        int i = (int) Math.floor(minX), j = (int) Math.ceil(maxX), k = (int) Math.floor(minY), l = (int) Math.ceil(maxY);
        int i1 = (int) Math.floor(minZ), j1 = (int) Math.ceil(maxZ);
        for (int bx = i; bx < j; bx++) for (int bz = i1; bz < j1; bz++) {
            if (!world.isLoaded(bx, bz)) { inWater = false; inLava = false; waterHeight = 0; lavaHeight = 0; return; }
            for (int by = k; by < l; by++) {
                double wt = world.waterTop(bx, by, bz);
                if (wt != 0 && wt >= minY) { inWater = true; waterHeight = Math.max(wt - minY, waterHeight); }
                double lt = world.lavaTop(bx, by, bz);
                if (lt != 0 && lt >= minY) { inLava = true; lavaHeight = Math.max(lt - minY, lavaHeight); }
            }
        }
        double eye = y + eyeHeight() - 0.11111111;
        int ex = (int) Math.floor(x), ey = (int) Math.floor(eye), ez = (int) Math.floor(z);
        eyeInWater = world.waterTop(ex, ey, ez) > eye;
    }

    // ------------------------------------------------------------------ movement

    private float speed() { return (float) (speedBase * (sprinting ? 1.3 : 1.0)); }

    private float flyingSpeed() {
        if (flying) return sprinting ? flySpeed * 2.0f : flySpeed;
        return sprinting ? 0.025999999f : 0.02f;
    }

    private void moveRelative(float amount, double xxa, double zza, float yaw) {
        double d0 = xxa * xxa + zza * zza;
        if (d0 < 1.0E-7) return;
        double ix = xxa, iz = zza;
        if (d0 > 1.0) { double len = Math.sqrt(d0); ix /= len; iz /= len; }
        ix *= amount; iz *= amount;
        float f = mthSin(yaw * ((float) Math.PI / 180F)), f1 = mthCos(yaw * ((float) Math.PI / 180F));
        vx += ix * (double) f1 - iz * (double) f;
        vz += iz * (double) f1 + ix * (double) f;
    }

    private void jumpFromGround(float yaw) {
        float power = 0.42f * blockJumpFactor() + 0.1f * jumpBoost;
        vy = power;
        if (sprinting) {
            float f1 = yaw * 0.017453292F;
            vx += (double) (-mthSin(f1) * 0.2F);
            vz += (double) (mthCos(f1) * 0.2F);
        }
    }

    private void fluidFalling(double gravity, boolean falling) {
        if (sprinting) return;
        double d0;
        if (falling && Math.abs(vy - 0.005) >= 0.003 && Math.abs(vy - gravity / 16.0) < 0.003) d0 = -0.003;
        else d0 = vy - gravity / 16.0;
        vy = d0;
    }

    /** LivingEntity.travel for a player. */
    private void travel(double xxa, double zza, boolean jumping, float yaw) {
        double gravity = GRAVITY;
        boolean falling = vy <= 0;
        if (falling && slowFalling) { gravity = 0.01; fallDistance = 0; }
        double vyBeforeFlight = vy;
        if (inWater && !flying) {
            double y0 = y;
            float f = sprinting ? 0.9f : 0.8f;
            if (dolphinsGrace) f = 0.96f;
            moveRelative(0.02f, xxa, zza, yaw);
            move(vx, vy, vz);
            if (horizontalCollision && onClimbable()) vy = 0.2;
            vx *= f; vy *= 0.8f; vz *= f;
            fluidFalling(gravity, falling);
            if (horizontalCollision && isFree(vx, vy + 0.6f - y + y0, vz)) vy = 0.3f;
        } else if (inLava && !flying) {
            double y0 = y;
            moveRelative(0.02f, xxa, zza, yaw);
            move(vx, vy, vz);
            if (lavaHeight <= 0.4) {
                vx *= 0.5; vy *= 0.8f; vz *= 0.5;
                fluidFalling(gravity, falling);
            } else { vx *= 0.5; vy *= 0.5; vz *= 0.5; }
            vy += -gravity / 4.0;
            if (horizontalCollision && isFree(vx, vy + 0.6f - y + y0, vz)) vy = 0.3f;
        } else {
            int[] sup = supportCell(0.500001);
            float f3 = world.friction(sup[0], sup[1], sup[2]);
            lastFriction = f3;
            float f4 = onGround ? f3 * 0.91f : 0.91f;
            float accel = onGround ? speed() * (0.21600002f / (f3 * f3 * f3)) : flyingSpeed();
            moveRelative(accel, xxa, zza, yaw);
            if (onClimbable()) {
                fallDistance = 0;
                vx = Math.max(-0.15f, Math.min(0.15f, vx));
                vz = Math.max(-0.15f, Math.min(0.15f, vz));
                vy = Math.max(vy, -0.15f);
                if (vy < 0 && sneaking) vy = 0;
            }
            move(vx, vy, vz);
            double ry = vy;
            if ((horizontalCollision || jumping) && onClimbable()) ry = 0.2;
            double d3 = ry;
            if (levitation > 0) d3 += (0.05 * levitation - ry) * 0.2;
            else if (!world.isLoaded(sup[0], sup[2])) d3 = y > world.minY ? -0.1 : 0.0;
            else d3 -= gravity;
            vx *= f4; vz *= f4; vy = d3 * 0.98f;
        }
        if (flying) {
            vy = vyBeforeFlight * 0.6;
            fallDistance = 0;
        }
    }

    /**
     * Advances the player by one 20 Hz tick.
     * @param yaw the look direction the input is relative to (degrees, 0 = +Z, as in the protocol)
     * @return false when the player's chunk is not loaded (the real client does nothing then either)
     */
    public boolean tick(Input in, float yaw) {
        if (!world.isLoaded((int) Math.floor(x), (int) Math.floor(z))) return false;
        flightCancelled = false;
        updateFluids();
        sneaking = in.sneak;
        float fwd = in.forward, str = in.strafe;
        if (sneaking) { fwd *= 0.3f; str *= 0.3f; }
        // sprint start / stop like LocalPlayer.aiStep
        boolean hasFwd = fwd > 1.0E-5f;
        boolean enoughImpulse = eyeInWater ? hasFwd : fwd >= 0.8f;
        if (!sprinting && hasFwd && enoughImpulse && (enoughFood || mayFly) && in.sprint && !sneaking) sprinting = true;
        if (sprinting) {
            boolean stop = !hasFwd || !(enoughFood || mayFly) || (horizontalCollision && !minorCollision) || (inWater && !eyeInWater);
            if (stop) sprinting = false;
        }
        double xxa = str * 0.98f, zza = fwd * 0.98f;
        if (flying) {
            int dir = 0;
            if (in.sneak) dir--;
            if (in.jump) dir++;
            if (dir != 0) vy += dir * flySpeed * 3.0f;
        }
        // LivingEntity.aiStep
        if (noJumpDelay > 0) noJumpDelay--;
        if (Math.abs(vx) < 0.003) vx = 0;
        if (Math.abs(vy) < 0.003) vy = 0;
        if (Math.abs(vz) < 0.003) vz = 0;
        if (in.jump && !flying) {
            double fh = inLava ? lavaHeight : waterHeight;
            boolean flag = inWater && fh > 0;
            double threshold = eyeHeight() < 0.4 ? 0.0 : 0.4;
            if (flag && (!onGround || fh > threshold)) vy += 0.04f;
            else if (inLava && (!onGround || fh > threshold)) vy += 0.04f;
            else if ((onGround || (flag && fh <= threshold)) && noJumpDelay == 0) { jumpFromGround(yaw); noJumpDelay = 10; }
        } else noJumpDelay = 0;
        if (in.sneak && inWater && !flying) vy -= 0.04f; // LivingEntity.goDownInWater
        travel(xxa, zza, in.jump, yaw);
        if (flying && onGround) { flying = false; flightCancelled = true; }
        return true;
    }

    // ------------------------------------------------------------------ helpers for the action layer

    /** New life / new world: no motion, no sprint, default attributes (the server resends abilities, effects and attributes). */
    public void resetState() {
        vx = vy = vz = 0; onGround = false; sprinting = false; sneaking = false; flying = false; mayFly = false; flySpeed = 0.05f;
        speedBase = 0.1; jumpBoost = 0; levitation = 0; slowFalling = false; dolphinsGrace = false; noJumpDelay = 0; fallDistance = 0;
        horizontalCollision = verticalCollision = minorCollision = false; flightCancelled = false; stuck = null; enoughFood = true;
    }

    /** Resets motion after the server moved the player (join, /tp, respawn). */
    public void teleported(boolean keepX, boolean keepY, boolean keepZ) {
        if (!keepX) vx = 0;
        if (!keepY) vy = 0;
        if (!keepZ) vz = 0;
        stuck = null;
    }
}
