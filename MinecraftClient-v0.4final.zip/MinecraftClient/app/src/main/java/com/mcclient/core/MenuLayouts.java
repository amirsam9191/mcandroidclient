package com.mcclient.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Container screen layouts of Minecraft 1.20.4: menu type ids (the registry order of protocol 765, with crafter_3x3 at 7),
 * slot counts, the background texture and every slot position in texture pixels (taken from the vanilla menu classes).
 */
public final class MenuLayouts {
    private MenuLayouts() {}

    /** Menu type names by protocol id. */
    public static final String[] TYPE_NAMES = {"generic_9x1", "generic_9x2", "generic_9x3", "generic_9x4", "generic_9x5", "generic_9x6", "generic_3x3",
        "crafter_3x3", "anvil", "beacon", "blast_furnace", "brewing_stand", "crafting", "enchantment", "furnace", "grindstone", "hopper", "lectern",
        "loom", "merchant", "shulker_box", "smithing", "smoker", "cartography_table", "stonecutter"};

    public static final int GENERIC_9X1 = 0, GENERIC_9X3 = 2, GENERIC_9X6 = 5, GENERIC_3X3 = 6, CRAFTER = 7, ANVIL = 8, BEACON = 9, BLAST_FURNACE = 10,
        BREWING_STAND = 11, CRAFTING = 12, ENCHANTMENT = 13, FURNACE = 14, GRINDSTONE = 15, HOPPER = 16, LECTERN = 17, LOOM = 18, MERCHANT = 19,
        SHULKER_BOX = 20, SMITHING = 21, SMOKER = 22, CARTOGRAPHY = 23, STONECUTTER = 24;

    /** A clickable button (Click Container Button 0x0C) with its rectangle in texture pixels. */
    public static final class Button {
        public final int id, x, y, w, h;
        public Button(int id, int x, int y, int w, int h) { this.id = id; this.x = x; this.y = y; this.w = w; this.h = h; }
    }

    public static final class Layout {
        public final int type;
        /** Texture file under textures/gui/container/ (without .png). */
        public final String texture;
        /** GUI size in texture pixels (the part of the texture that is drawn). */
        public final int width, height;
        /** Size of the texture atlas file (256x256 for all but a few). */
        public final int texW, texH;
        /** [slot] -> {x, y} for every slot of the window, container slots first, then the 27 inventory slots, then the 9 hotbar slots. */
        public final int[][] slots;
        public final List<Button> buttons = new ArrayList<>();
        /** Title position and the "Inventory" label position. */
        public int titleX = 8, titleY = 6, invLabelX = 8, invLabelY;
        /** True when the slot positions follow the vanilla class (false = approximate placement). */
        public boolean exact = true;
        Layout(int type, String texture, int w, int h, int texW, int texH, int[][] slots) {
            this.type = type; this.texture = texture; width = w; height = h; this.texW = texW; this.texH = texH; this.slots = slots;
        }
        public int containerSlots() { return slots.length - 36; }
    }

    /** Number of non-player slots of a menu type. */
    public static int containerSlots(int type) {
        switch (type) {
            case 0: case 1: case 2: case 3: case 4: case 5: return 9 * (type + 1);
            case GENERIC_3X3: return 9;
            case CRAFTER: return 10;
            case ANVIL: return 3;
            case BEACON: return 1;
            case BLAST_FURNACE: case FURNACE: case SMOKER: return 3;
            case BREWING_STAND: return 5;
            case CRAFTING: return 10;
            case ENCHANTMENT: return 2;
            case GRINDSTONE: return 3;
            case HOPPER: return 5;
            case LECTERN: return 1;
            case LOOM: return 4;
            case MERCHANT: return 3;
            case SHULKER_BOX: return 27;
            case SMITHING: return 4;
            case CARTOGRAPHY: return 3;
            case STONECUTTER: return 2;
            default: return 27;
        }
    }

    public static String typeName(int type) { return type >= 0 && type < TYPE_NAMES.length ? TYPE_NAMES[type] : "unknown_" + type; }

    private static void playerSlots(int[][] s, int from, int x0, int yInv, int yHot) {
        for (int r = 0; r < 3; r++) for (int c = 0; c < 9; c++) s[from + r * 9 + c] = new int[]{x0 + c * 18, yInv + r * 18};
        for (int c = 0; c < 9; c++) s[from + 27 + c] = new int[]{x0 + c * 18, yHot};
    }

    private static Layout make(int type, String tex, int w, int h, int[][] containerXY, int px, int pyInv, int pyHot) {
        int[][] s = new int[containerXY.length + 36][];
        System.arraycopy(containerXY, 0, s, 0, containerXY.length);
        playerSlots(s, containerXY.length, px, pyInv, pyHot);
        Layout l = new Layout(type, tex, w, h, 256, 256, s);
        l.invLabelX = px; l.invLabelY = pyInv - 11;
        return l;
    }

    private static int[][] grid(int cols, int rows, int x0, int y0) {
        int[][] g = new int[cols * rows][];
        for (int r = 0; r < rows; r++) for (int c = 0; c < cols; c++) g[r * cols + c] = new int[]{x0 + c * 18, y0 + r * 18};
        return g;
    }

    /** Layout for a menu type id (never null: unknown types get a generic 9x3 look). */
    public static Layout of(int type) {
        switch (type) {
            case 0: case 1: case 2: case 3: case 4: case 5: {
                int rows = type + 1;
                int i = (rows - 4) * 18;
                Layout l = make(type, "generic_54", 176, 114 + rows * 18, grid(9, rows, 8, 18), 8, 103 + i, 161 + i);
                l.invLabelY = 114 + rows * 18 - 94;
                return l;
            }
            case GENERIC_3X3: return make(type, "dispenser", 176, 166, grid(3, 3, 62, 17), 8, 84, 142);
            case CRAFTER: {
                Layout l = make(type, "crafter", 176, 166, concat(grid(3, 3, 26, 17), new int[][]{{134, 35}}), 8, 84, 142);
                l.exact = false; // positions of the crafter grid were not verified against the vanilla class
                return l;
            }
            case ANVIL: return make(type, "anvil", 176, 166, new int[][]{{27, 47}, {76, 47}, {134, 47}}, 8, 84, 142);
            case BEACON: {
                Layout l = make(type, "beacon", 230, 219, new int[][]{{136, 110}}, 36, 137, 195);
                return l;
            }
            case BLAST_FURNACE: return make(type, "blast_furnace", 176, 166, new int[][]{{56, 17}, {56, 53}, {116, 35}}, 8, 84, 142);
            case FURNACE: return make(type, "furnace", 176, 166, new int[][]{{56, 17}, {56, 53}, {116, 35}}, 8, 84, 142);
            case SMOKER: return make(type, "smoker", 176, 166, new int[][]{{56, 17}, {56, 53}, {116, 35}}, 8, 84, 142);
            case BREWING_STAND: return make(type, "brewing_stand", 176, 166, new int[][]{{56, 51}, {79, 58}, {102, 51}, {79, 17}, {17, 17}}, 8, 84, 142);
            case CRAFTING: return make(type, "crafting_table", 176, 166, concat(new int[][]{{124, 35}}, grid(3, 3, 30, 17)), 8, 84, 142);
            case ENCHANTMENT: {
                Layout l = make(type, "enchanting_table", 176, 166, new int[][]{{15, 47}, {35, 47}}, 8, 84, 142);
                for (int i = 0; i < 3; i++) l.buttons.add(new Button(i, 60, 14 + 19 * i, 108, 19));
                return l;
            }
            case GRINDSTONE: return make(type, "grindstone", 176, 166, new int[][]{{49, 19}, {49, 40}, {129, 34}}, 8, 84, 142);
            case HOPPER: {
                Layout l = make(type, "hopper", 176, 133, grid(5, 1, 44, 20), 8, 51, 109);
                return l;
            }
            case LECTERN: {
                Layout l = make(type, "generic_54", 176, 166, new int[][]{{-100, -100}}, 8, 84, 142);
                l.exact = false;
                return l;
            }
            case LOOM: {
                Layout l = make(type, "loom", 176, 166, new int[][]{{13, 26}, {33, 26}, {23, 45}, {143, 57}}, 8, 84, 142);
                for (int i = 0; i < 24; i++) l.buttons.add(new Button(i + 1, 60 + (i % 4) * 14, 13 + (i / 4) * 14, 14, 14));
                l.exact = false; // the pattern button grid is numeric because the pattern list is not sent to clients
                return l;
            }
            case MERCHANT: return make(type, "villager2", 276, 166, new int[][]{{136, 37}, {162, 37}, {220, 37}}, 108, 84, 142);
            case SHULKER_BOX: return make(type, "shulker_box", 176, 167, grid(9, 3, 8, 18), 8, 84, 142);
            case SMITHING: return make(type, "smithing", 176, 166, new int[][]{{8, 48}, {26, 48}, {44, 48}, {98, 48}}, 8, 84, 142);
            case CARTOGRAPHY: return make(type, "cartography_table", 176, 166, new int[][]{{15, 15}, {15, 52}, {145, 39}}, 8, 84, 142);
            case STONECUTTER: {
                Layout l = make(type, "stonecutter", 176, 166, new int[][]{{20, 33}, {143, 33}}, 8, 84, 142);
                for (int i = 0; i < 12; i++) l.buttons.add(new Button(i, 52 + (i % 4) * 16, 14 + (i / 4) * 18, 16, 18));
                l.exact = false; // the recipe list is computed client side from the recipe manager; here the buttons are numbered
                return l;
            }
            default: {
                Layout l = make(type, "generic_54", 176, 168, grid(9, 3, 8, 18), 8, 85, 143);
                l.exact = false;
                return l;
            }
        }
    }

    private static int[][] concat(int[][] a, int[][] b) {
        int[][] r = new int[a.length + b.length][];
        System.arraycopy(a, 0, r, 0, a.length);
        System.arraycopy(b, 0, r, a.length, b.length);
        return r;
    }

    /** Player inventory window (inventory.png): crafting result, 2x2 grid, armor, 27 + 9 slots and the offhand (slot 45). */
    public static Layout playerInventory() {
        int[][] s = new int[46][];
        s[0] = new int[]{154, 28};
        s[1] = new int[]{98, 18}; s[2] = new int[]{116, 18}; s[3] = new int[]{98, 36}; s[4] = new int[]{116, 36};
        for (int i = 0; i < 4; i++) s[5 + i] = new int[]{8, 8 + i * 18};
        for (int r = 0; r < 3; r++) for (int c = 0; c < 9; c++) s[9 + r * 9 + c] = new int[]{8 + c * 18, 84 + r * 18};
        for (int c = 0; c < 9; c++) s[36 + c] = new int[]{8 + c * 18, 142};
        s[45] = new int[]{77, 62};
        Layout l = new Layout(-1, "inventory", 176, 166, 256, 256, s);
        l.invLabelX = 97; l.invLabelY = 8;
        return l;
    }
}
