package com.mcclient.core;

/**
 * Movement costs in game ticks, ported from baritone.api.pathing.movement.ActionCosts (baritone-api 1.8.6, read with javap).
 * The fall table is generated with the same formulas: velocity(t) = (0.98^t - 1) * -3.92 and distanceToTicks.
 */
public final class ActionCosts {
    private ActionCosts() {}

    public static final double WALK_ONE_BLOCK_COST = 4.63284688441047d;
    public static final double WALK_ONE_IN_WATER_COST = 9.09090909090909d;
    public static final double WALK_ONE_OVER_SOUL_SAND_COST = 9.26569376882094d;
    public static final double LADDER_UP_ONE_COST = 8.51063829787234d;
    public static final double LADDER_DOWN_ONE_COST = 6.666666666666667d;
    public static final double SNEAK_ONE_BLOCK_COST = 15.384615384615383d;
    public static final double SPRINT_ONE_BLOCK_COST = 3.563791874554526d;
    public static final double SPRINT_MULTIPLIER = 0.7692444761225944d;
    public static final double WALK_OFF_BLOCK_COST = 3.7062775075283763d;
    public static final double CENTER_AFTER_FALL_COST = 0.9265693768820937d;
    public static final double COST_INF = 1000000.0d;

    public static final double[] FALL_N_BLOCKS_COST = generateFallNBlocksCost();
    public static final double FALL_1_25_BLOCKS_COST = distanceToTicks(1.25);
    public static final double FALL_0_25_BLOCKS_COST = distanceToTicks(0.25);
    public static final double JUMP_ONE_BLOCK_COST = FALL_1_25_BLOCKS_COST - FALL_0_25_BLOCKS_COST;

    public static double[] generateFallNBlocksCost() {
        double[] costs = new double[4097];
        for (int i = 0; i < 4097; i++) costs[i] = distanceToTicks(i);
        return costs;
    }

    /** Downward speed after {@code ticks} of free fall (blocks per tick). */
    public static double velocity(int ticks) { return (Math.pow(0.98, ticks) - 1) * -3.92; }

    /** Ticks needed to fall {@code distance} blocks. */
    public static double distanceToTicks(double distance) {
        if (distance == 0) return 0;
        double tmpDistance = distance;
        int tickCount = 0;
        while (true) {
            double fallDistance = velocity(tickCount);
            if (tmpDistance <= fallDistance) return tickCount + tmpDistance / fallDistance;
            tmpDistance -= fallDistance;
            tickCount++;
        }
    }
}
