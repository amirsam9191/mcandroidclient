package com.mcclient.app.ui.mc

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.Rect
import android.graphics.RectF
import com.mcclient.app.game.ChatSpan
import com.mcclient.core.TextLayout

/** Drawing of a [TextLayout.Layout] (computed and unit-tested in the Java core) with Minecraft's bitmap font. */
object McLayout {
    fun build(spans: List<ChatSpan>, maxGp: Int): TextLayout.Layout = TextLayout.build(spans, maxGp, McFont)

    fun contentWidth(l: TextLayout.Layout): Int {
        var w = 0
        for (line in l.lines) for (s in line) w = maxOf(w, s.x + s.width)
        return w
    }

    private fun shadowOf(c: Int): Int {
        val r = ((c shr 16) and 0xFF) / 4
        val g = ((c shr 8) and 0xFF) / 4
        val b = (c and 0xFF) / 4
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }

    fun draw(canvas: Canvas, layout: TextLayout.Layout, unit: Int, shiftGp: Int = 0) {
        val paint = Paint()
        paint.isAntiAlias = false
        paint.isFilterBitmap = false
        val src = Rect()
        val dst = RectF()
        val u = unit.toFloat()
        val ascii = McFont.asciiBitmap
        val cell = McFont.cellSize
        for ((li, line) in layout.lines.withIndex()) {
            val top = 1 + li * McFont.LINE_H
            for (s in line) {
                val sp = s.span
                val isSpace = s.type == TextLayout.Type.SPACE
                if (isSpace && !sp.underline && !sp.strike) continue
                val sx = s.x + shiftGp
                val pf = sp.font?.let { PackFonts.get(it) }
                val pixel = pf == null && !isSpace && (TextLayout.needsPixelFont(s) || ascii == null)
                for (pass in 0..1) {
                    val shadow = pass == 0
                    val color = if (shadow) shadowOf(sp.color) else sp.color
                    val off = if (shadow) 1 else 0
                    paint.colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
                    canvas.save()
                    if (sp.italic) {
                        val by = (top + McFont.BASE + off) * u
                        canvas.translate(0f, by)
                        canvas.skew(-0.2f, 0f)
                        canvas.translate(0f, -by)
                    }
                    if (pf != null && !isSpace) {
                        paint.colorFilter = PackFonts.filter(color)
                        PackFonts.draw(canvas, pf, s.text, sx + off, top, u, paint, sp.bold)
                    } else if (pixel) {
                        val run = McFont.pixelRun(s.text, sp.bold, !TextLayout.needsPixelFont(s))
                        val l = (sx + off) * u
                        val t = (top + McFont.BASE - run.asc + off) * u
                        dst.set(l, t, l + run.w * u, t + run.bmp.height * u)
                        canvas.drawBitmap(run.bmp, null, dst, paint)
                    } else if (!isSpace && ascii != null) {
                        var x = sx + off
                        for (ch in s.text) {
                            val code = ch.code
                            if (McFont.hasGlyph(code)) {
                                src.set((code % 16) * cell, (code / 16) * cell, (code % 16) * cell + cell, (code / 16) * cell + cell)
                                val gl = x * u
                                val gt = (top + McFont.BASE - 7 + off) * u
                                dst.set(gl, gt, gl + 8 * u, gt + 8 * u)
                                canvas.drawBitmap(ascii, src, dst, paint)
                                if (sp.bold) {
                                    dst.offset(u, 0f)
                                    canvas.drawBitmap(ascii, src, dst, paint)
                                }
                            }
                            x += McFont.charAdv(code) + (if (sp.bold) 1 else 0)
                        }
                    }
                    if (pf != null) paint.colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
                    if (sp.underline) {
                        canvas.drawRect((sx + off) * u, (top + McFont.BASE + 1 + off) * u, (sx + s.width + off) * u, (top + McFont.BASE + 2 + off) * u, paint)
                    }
                    if (sp.strike) {
                        canvas.drawRect((sx + off) * u, (top + McFont.BASE - 3 + off) * u, (sx + s.width + off) * u, (top + McFont.BASE - 2 + off) * u, paint)
                    }
                    canvas.restore()
                }
            }
        }
    }

    /** The span under a point given in game pixels (relative to the text block), or null. Used for click and hover events. */
    fun hit(layout: TextLayout.Layout, gx: Float, gy: Float, shiftGp: Int = 0): ChatSpan? {
        val li = ((gy - 1f) / McFont.LINE_H).toInt()
        if (gy < 0f || li < 0 || li >= layout.lines.size) return null
        for (s in layout.lines[li]) {
            val x0 = s.x + shiftGp
            if (gx >= x0 && gx < x0 + maxOf(s.width, 1)) {
                if (s.type == TextLayout.Type.SPACE) return null
                return s.span
            }
        }
        return null
    }
}
