plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.mcclient.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mcclient.app"
        minSdk = 26
        targetSdk = 34
        // Updates over an installed copy need: the same applicationId, a HIGHER versionCode, and the same signing key.
        // Raise versionCode by one for every release you hand out (CI can override it with -PversionCode=N).
        versionCode = (project.findProperty("versionCode") as String?)?.toIntOrNull() ?: 4
        versionName = "0.4.0"
    }

    // One fixed key kept in the repository, used for debug AND release builds, so every APK built anywhere
    // (this machine, GitHub Actions) is signed identically and installs as an update of the previous one.
    signingConfigs {
        create("shared") {
            storeFile = rootProject.file("keystore/mcclient.jks")
            storePassword = "mcclient-signing"
            keyAlias = "mcclient"
            keyPassword = "mcclient-signing"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("shared")
        }
        release {
            signingConfig = signingConfigs.getByName("shared")
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
