# گزارش تست — نسخهٔ ۰٫۴

دستور کامل: `sh core-tests/run.sh all` (فقط JDK؛ کامپایل هسته با `-Xlint:all`). چون اجرای کامل چند دقیقه طول می‌کشد، گروه‌ها جدا هم اجرا می‌شوند:
`sh core-tests/run.sh` (سریع)، `... integration`، `... obstacle`، `... move`، `... fidelity`.

**نتیجه: 1242 بررسی پاس، 0 شکست.** (نسخهٔ ۰٫۳: ۷۰۵ پاس.)

| گروه | پاس | شکست |
|---|---|---|
| سریع (unit/layout/physics/goals/chat) | 380 | 0 |
| integration | 364 | 0 |
| obstacle | 165 | 0 |
| move | 200 | 0 |
| fidelity | 133 | 0 |

## آنچه این تست‌ها نشان می‌دهند و نشان نمی‌دهند
- هستهٔ Java (پروتکل، فیزیک، مسیریابی، اکشن‌ها، اینونتوری) با یک **سرور شبیه‌ساز** مستقل تست شده است: سروری که فقط همان چیزی را که ما در تست می‌گذاریم مدل می‌کند. این معادل اجرا روی سرور واقعی ماینکرافت یا روی پلاگین‌های ضد‌تقلب واقعی **نیست**.
- **لایهٔ Kotlin/Compose کامپایل و اجرا نشده** (کامپایلر Kotlin روی این ماشین نبود). فقط بررسی ایستا شد: تعادل آکولاد/پرانتز و تطبیق ارجاع‌های `session.*` / `session.core.*` / `prefs.*` با اعضای واقعی (صفر ارجاع ناشناخته).
- هیچ کدام APK نساخته یا روی دستگاه اجرا نکرده‌اند.

## همسانی با کلاینت رسمی (گروه fidelity و بخش‌هایی از گروه‌های دیگر)
هر مورد با منبع/کد اصلی مقایسه شد و تست دارد:

| موضوع | کلاینت رسمی | اندازه‌گیری |
|---|---|---|
| ترتیب Config | اول `minecraft:brand`، بعد Client Information | تست `Flow` |
| Client Information | en_us، view distance ۱۲، chat کامل، رنگ روشن، skin 0x7F، دست راست، listing روشن | تست `Flow` |
| salt چت/دستور | تصادفی (۶۴ بیت) | ۰ نبود؛ دو پیام salt متفاوت |
| Chunk Batch Received | `7e6 / (میانگین نانو‌ثانیه به‌ازای هر چانک)`، از Chunk Batch Start/Finished | مقدار محاسبه‌شده، نه عدد ثابت |
| sequence | فقط START/STOP کندن (۱،۲،۳،۴…)؛ دراپ/تعویض/رها کردن = ۰ با face پایین | تست |
| چرخش | ماوس: مضرب‌های ۰٫۱۵° (حساسیت پیش‌فرض)، تدریجی | همهٔ تغییرات مضرب ۰٫۱۵؛ حداکثر ۳۷٫۹۵° در یک تیک |
| کندن بلاک | START، Swing هر تیک، STOP وقتی پیشرفت ≥ ۱٫۰ (float)، سپس ۵ تیک `destroyDelay`؛ ۵× کندتر در هوا/زیر آب؛ Mining Fatigue؛ بدون Efficiency/Haste (کندتر از واقعی، نه تندتر) | ۱۵ تیک برای خاک، ۱۵ Swing، فاصلهٔ ≥۵ تیک |
| حرکت | `sendPosition`: Pos/PosRot/Rot/OnGround؛ یادآور هر ۲۰ تیک؛ Player Command دویدن/خزیدن | تست |
| sin/cos فیزیک | جدول ۶۵۵۳۶‌تایی `Mth` | جدول مثل ماینکرافت (نه `Math.sin`) |
| صفحهٔ باز (اینونتوری/منو) | ورودی حرکت صفر؛ بستن = Close Container | با کلیک روی اسلات، کاراکتر می‌ایستد؛ ۴ ثانیه بعد Close(0)؛ بستن دستی فوری |
| ریسپاون | دکمه بعد از ۲۰ تیک فعال می‌شود و انسان فوراً نمی‌زند | ۱٫۳–۳ ثانیه |
| نشستن پشت چانک نیامده | هیچ تیکی انجام نمی‌شود | تست |
| **حالت AFK (بدون حرکت و اکشن)** | فقط Pos هر ۲۰ تیک (۱ بار در ثانیه) با همان مختصات و `onGround=true`؛ جواب Keep Alive/Ping؛ هیچ چیز دیگر | ۹ ثانیه ضبط کامل با سرور پرحرف (Keep Alive، Ping، چت سیستمی، سرعت موجود دیگر، سلامت ثابت): فقط شناسه‌های 0x17، 0x15، 0x24؛ فاصلهٔ بسته‌ها ۱۰۰۰±۴۰ میلی‌ثانیه؛ مختصات بدون هیچ لرزشی |
| Teleport در حال AFK | Confirm، PosRot(`onGround=false`)، سپس چون سرعت عمودی صفر می‌شود OnGround(false) و OnGround(true) | همین دنباله، بعدش فقط یادآور |
| چت امضاشده (`LastSeenMessagesTracker`) | offset و بیت‌ست ۲۰ بیتی در پیام خروجی؛ Chat Ack فقط وقتی بیش از ۶۴ پیام امضاشده منتظر باشد؛ پیام بدون امضا هرگز | offset ۳ و بیت‌ست `0x0E0000`؛ Ack با مقدار ۶۵ (نه ۲۰)؛ ۸۰ پیام بدون امضا = بدون Ack |
| کارهای خودکار | کلاینت بیکار خودش هیچ نمی‌کند | خوردن خودکار به‌طور پیش‌فرض **خاموش** است |

### آنچه هنوز با کلاینت رسمی فرق دارد (ضد‌ربات‌های قوی ممکن است ببینند)
- مسیرها مرکز‌به‌مرکز و بسیار صاف‌اند؛ هیچ لرزش یا اشتباه انسانی ندارند. چرخش تدریجی است اما مسیر آن همیشه یک منحنی نرم ثابت است.
- زمان‌بندی کارها (کلیک، کندن، مکث‌ها) منظم‌تر از انسان است.
- پل‌زدن بدون خزیدن انجام می‌شود (بازیکن‌ها معمولاً با Shift پل می‌زنند).
- Efficiency و Haste در زمان کندن لحاظ نمی‌شوند (کندتر از کلاینت واقعی؛ این عمداً امن‌تر است).
- فیزیک مدل‌شدهٔ ما ممکن است در موارد نادر (جریان آب، لغزش روی یخ، برخورد جزئی در دویدن) از ماینکرافت واقعی چند هزارم بلوک فرق کند.
- **با هیچ ضد‌تقلب واقعی آزمایش نشده**؛ نمی‌توانم تضمین کنم «تشخیص‌ناپذیر» است، فقط می‌توانم بگویم رفتار پکتی را مو‌به‌مو با کد کلاینت 1.20.4 مقایسه و آزمون کرده‌ام.

## مقادیر مرجع فیزیک (از پرامپت) و نتیجهٔ اندازه‌گیری
| کمیت | مرجع | اندازه‌گیری |
|---|---|---|
| سرعت راه رفتن | 0٫2158/تیک | 0٫21586 |
| سرعت دویدن | 0٫2806/تیک | 0٫28062 |
| قلهٔ پرش | 1٫2522 | 1٫25220 |
| مدت پرش | ۱۲ تیک | ۱۲ تیک |
| سقوط ۷ بلوک از حالت سکون | ۱۵ تیک | ۱۵ تیک |
| سرعت حد سقوط | −3٫92 | −3٫92 |
| پرواز کریتیو | (۱۰٫۹ بلوک/ث) | 0٫5425/تیک |
| ‎Levitation I | ‎0٫9 بلوک/ث | 0٫0454/تیک |

## تست‌ها به تفکیک
| مجموعه | پاس | شکست |
|---|---|---|
| buffers | 13 | 0 |
| nbt | 11 | 0 |
| json | 5 | 0 |
| chat | 17 | 0 |
| framing | 20 | 0 |
| chunk data (paletted containers) | 10 | 0 |
| registry data | 11 | 0 |
| world queries | 4 | 0 |
| path finder | 12 | 0 |
| text layout: mixed Persian / English | 29 | 0 |
| chat: clickEvent / hoverEvent / font | 27 | 0 |
| layout: spans keep events, and pack fonts are measured by the metrics | 5 | 0 |
| physics: reference values | 15 | 0 |
| physics: input, sprint and jumping rules | 16 | 0 |
| physics: friction blocks | 7 | 0 |
| physics: water, lava and ladders | 11 | 0 |
| physics: collision shapes (step-up, slabs, stairs, ledges) | 9 | 0 |
| physics: flying, effects, unloaded chunks | 13 | 0 |
| planning: goals drive A*, stairs/slabs need real shapes | 8 | 0 |
| baritone: ActionCosts | 9 | 0 |
| baritone: goals | 18 | 0 |
| menus: types, sizes and layouts (protocol 765) | 63 | 0 |
| shapes: blockCollisionShapes.json loader and sanity checks | 10 | 0 |
| path finder: Baritone-style obstacles (planner) | 35 | 0 |
| render to PNG (visual check) | 2 | 0 |
| server list ping | 11 | 0 |
| login, compression, chat, health, players, suggestions | 44 | 0 |
| auto-login and startup commands | 29 | 0 |
| kick and auto-rejoin | 44 | 0 |
| online-mode servers | 1 | 0 |
| world loading, gravity and teleports | 22 | 0 |
| inventory, containers and item actions | 62 | 0 |
| death and respawn | 24 | 0 |
| robustness against odd or hostile servers | 14 | 0 |
| resource packs (download, hash cache, decline) | 43 | 0 |
| path finding + walking against server-side collision checks | 53 | 0 |
| follow a player | 17 | 0 |
| sim: dig through a stone wall with the right tool | 19 | 0 |
| sim: bare-hand digging of dirt, wrong tool timing | 16 | 0 |
| sim: digging off, and protected blocks | 26 | 0 |
| sim: bridge a gap with placed blocks | 30 | 0 |
| sim: pillar up by jumping and placing underneath | 17 | 0 |
| sim: swim across a pond | 28 | 0 |
| sim: climb a ladder | 14 | 0 |
| sim: open a door in a wall | 15 | 0 |
| session: movement packets like LocalPlayer.sendPosition | 20 | 0 |
| session: server-driven motion (velocity, explosion, attributes, effects, abilities) | 72 | 0 |
| actions: open a block with a screen, mine, explore, waypoints, auto-eat | 108 | 0 |
| fidelity: rotation like a mouse (0.15 degree counts, eased, never a snap) | 17 | 0 |
| fidelity: digging timeline of MultiPlayerGameMode | 20 | 0 |
| fidelity: drop / swap packets and chat salts | 15 | 0 |
| fidelity: an open screen means no movement input | 19 | 0 |
| fidelity: respawn pacing | 13 | 0 |
| fidelity: an idle (AFK) client sends only what the official client sends | 20 | 0 |
| fidelity: signed chat tracking (LastSeenMessagesTracker) | 18 | 0 |
| fidelity: formulas and tables | 11 | 0 |

## تغییرات نسبت به ۰٫۳
- **حذف‌شده:** ۷ بررسی `physics()` قدیمی (به API حذف‌شده وابسته بودند؛ در مجموعهٔ physics جدید دقیق‌تر پوشش داده شده‌اند).
- **تغییر رفتار عمدی (به‌خاطر همسانی با کلاینت رسمی):** شیفت‌کلیک پیش‌بینی محلی دارد؛ ترتیب Brand/Client Information؛ Chunk Batch محاسبه‌ای؛ salt تصادفی؛ ریسپاون با تأخیر؛ کندن با زمان‌بندی واقعی.
- **سرور شبیه‌ساز:** 0x17/0x18/0x19/0x1A و 0x22 را می‌پذیرد، ردیاب حرکت مستقل (`MockServer.Tracker` با تاریخچهٔ yaw/pitch) و خط‌زمان پکت‌های Player Action/Swing/Close/Chat/ClientStatus دارد.
- **جدید:** `PhysicsTests` (71)، `GoalTests` (Baritone، منوها، شکل‌ها، برنامه‌ریزی)، `ChatEventTests`، `MoveTests` (200)، `FidelityTests` (95).

## باگ‌هایی که تست/بازبینی پیدا کردند
1. ترتیب انواع منو در ۰٫۳ برای ۷۶۵ غلط بود (`crafter_3x3` = ۷ جا افتاده بود؛ اندازهٔ enchanting و beacon هم اشتباه).
2. پورت اولیهٔ `GoalGetToBlock` قدر مطلق را دور کل عبارت نمی‌گذاشت؛ با خواندن مجدد bytecode اصلاح شد.
3. بررسی سلامت شکل‌ها جعبه‌های با ارتفاع بیش از ۱ (حصار/دیوار ۱٫۵) را رد می‌کرد.
4. شرط «کار معلق» در Walker استاتیک بود و بعد از کندن بلاک بازیکن را ثابت نگه می‌داشت.
5. هدف `GoalNear` با `ceil` ساخته می‌شد و با شرط رسیدن هم‌خوان نبود.
6. در آب، بدون نگه‌داشتن پرش بازیکن غرق می‌شد.
7. **(همسانی)** پایان کندن بلاک در ۷۵٪ زمان لازم فرستاده می‌شد، Swing هر ۵ تیک بود و `destroyDelay` نداشت؛ salt چت ۰ بود؛ Chunk Batch عدد ثابت ۱۰ بود؛ Brand و Client Information برعکس بودند؛ sequence برای همهٔ Player Actionها شمرده می‌شد؛ چرخش پرش ناگهانی با درجهٔ دلخواه بود؛ هنگام کلیک اینونتوری بازیکن راه می‌رفت.
8. در تست‌ها: اسلب «waterlogged=true» (اولین مقدار بول در ماینکرافت) آب حساب می‌شد.

## چه چیزی تست **نشده**
- رندر Compose، لمس، گردش‌کار دانلود (فونت وزیر، `blockCollisionShapes.json`، `effects.json`، jar ماینکرافت)، ریسورس‌پک واقعی، فونت‌های bitmap/space پک واقعی، سرویس پس‌زمینه، دیالوگ‌ها.
- فایل واقعی `blockCollisionShapes.json` (فقط نمونهٔ هم‌قالب).
- رفتار روی یخ، slime و جریان آب در سرور واقعی؛ اتصال به سرور واقعی ۱٫۲۰٫۴؛ هر ضد‌تقلب واقعی.
