#!/bin/sh
# Compiles the pure-Java core and runs every test. Needs only a JDK (java + jdk.compiler module).
set -e
cd "$(dirname "$0")/.."
OUT=${TMPDIR:-/tmp}/mcclient-test-out
rm -rf "$OUT" && mkdir -p "$OUT"
JAVAC="javac"; command -v javac >/dev/null 2>&1 || JAVAC="java -m jdk.compiler/com.sun.tools.javac.Main"
$JAVAC -Xlint:all -d "$OUT" app/src/main/java/com/mcclient/core/*.java core-tests/src/*.java
java -cp "$OUT" Main "$@"
