import com.mcclient.core.*;
import java.util.*;

/** clickEvent / hoverEvent / font on Chat.Span (protocol 765 text components). */
public final class ChatEventTests {
    static Chat.Span first(List<Chat.Span> l, String text) { for (Chat.Span s : l) if (s.text.equals(text)) return s; return null; }

    static void run() {
        T.suite("chat: clickEvent / hoverEvent / font");

        for (String action : new String[]{"run_command", "suggest_command", "open_url", "copy_to_clipboard", "change_page", "open_file"}) {
            String json = "{\"text\":\"btn\",\"clickEvent\":{\"action\":\"" + action + "\",\"value\":\"v " + action + "\"}}";
            Chat.Span sp = first(Chat.fromJsonText(json), "btn");
            T.check("clickEvent " + action + " parsed", sp != null && sp.click != null && sp.click.action.equals(action) && sp.click.value.equals("v " + action));
        }

        List<Chat.Span> l = Chat.fromJsonText("{\"text\":\"a\",\"clickEvent\":{\"action\":\"open_url\",\"value\":\"https://x.y\"},\"extra\":[{\"text\":\"b\"},{\"text\":\"c\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/hi\"}}]}");
        T.check("child inherits the parent's click event", first(l, "b").click != null && first(l, "b").click.action.equals("open_url"));
        T.check("child can override the click event", first(l, "c").click.action.equals("run_command") && first(l, "c").click.value.equals("/hi"));

        l = Chat.fromJsonText("{\"text\":\"h\",\"hoverEvent\":{\"action\":\"show_text\",\"contents\":{\"text\":\"line1\\nline2\",\"color\":\"red\"}}}");
        Chat.Span h = first(l, "h");
        T.check("hoverEvent show_text (contents) parsed", h.hover != null && h.hover.action.equals("show_text") && h.hover.text.size() == 1);
        T.eq("hover text keeps its colour", h.hover.text.get(0).color, Chat.LEGACY[12]);
        T.eq("hover lines are split at newline", h.hover.lines().size(), 2);
        l = Chat.fromJsonText("{\"text\":\"h\",\"hoverEvent\":{\"action\":\"show_text\",\"value\":\"old style\"}}");
        T.check("hoverEvent show_text with the old 'value' key", first(l, "h").hover != null && first(l, "h").hover.text.get(0).text.equals("old style"));

        l = Chat.fromJsonText("{\"text\":\"i\",\"hoverEvent\":{\"action\":\"show_item\",\"contents\":{\"id\":\"minecraft:diamond_sword\",\"count\":1,\"tag\":\"{display:{Name:'x'}}\"}}}");
        T.check("hoverEvent show_item parsed", first(l, "i").hover.action.equals("show_item") && first(l, "i").hover.id.equals("minecraft:diamond_sword") && first(l, "i").hover.count == 1);
        l = Chat.fromJsonText("{\"text\":\"e\",\"hoverEvent\":{\"action\":\"show_entity\",\"contents\":{\"type\":\"minecraft:player\",\"id\":\"00000000-0000-0000-0000-000000000001\",\"name\":{\"text\":\"Steve\"}}}}");
        Chat.Span e = first(l, "e");
        T.check("hoverEvent show_entity parsed", e.hover.action.equals("show_entity") && e.hover.entityType.equals("minecraft:player") && e.hover.text.get(0).text.equals("Steve"));
        T.check("show_entity tooltip has name and type lines", e.hover.lines().size() == 2);

        l = Chat.fromJsonText("{\"text\":\"f\",\"font\":\"minecraft:uniform\",\"extra\":[{\"text\":\"g\"},{\"text\":\"k\",\"font\":\"ns:icons\"}]}");
        T.eq("font id parsed", first(l, "f").font, "minecraft:uniform");
        T.eq("font is inherited by children", first(l, "g").font, "minecraft:uniform");
        T.eq("font can be overridden", first(l, "k").font, "ns:icons");
        T.check("no font means null", Chat.fromJsonText("{\"text\":\"n\"}").get(0).font == null);

        l = Chat.fromJsonText("{\"text\":\"\\u00a7cred \\u00a7lbold\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/x\"}}");
        T.check("legacy colour codes keep the component's click event", l.size() == 2 && l.get(0).click != null && l.get(1).click != null && l.get(1).bold);

        // NBT-style maps: booleans arrive as Byte, hover/click as nested maps
        Map<String, Object> click = new LinkedHashMap<>(); click.put("action", "suggest_command"); click.put("value", "/msg Bob ");
        Map<String, Object> name = new LinkedHashMap<>(); name.put("text", "Bob"); name.put("clickEvent", click); name.put("bold", (byte) 1);
        Map<String, Object> node = new LinkedHashMap<>(); node.put("translate", "chat.type.text"); node.put("with", new ArrayList<Object>(Arrays.asList(name, "hello")));
        l = Chat.fromAny(node);
        Chat.Span bob = first(l, "Bob");
        T.check("chat.type.text: the sender component keeps its suggest_command and bold", bob != null && bob.bold && bob.click != null && bob.click.action.equals("suggest_command") && bob.click.value.equals("/msg Bob "));
        T.check("the message part carries no event", first(l, "hello") != null && first(l, "hello").click == null);
        T.check("hasEvents() reflects click/hover", bob.hasEvents() && !first(l, "hello").hasEvents());

        Chat.Span cut = bob.withText("Bo");
        T.check("withText keeps style, font and events", cut.text.equals("Bo") && cut.bold && cut.click == bob.click);
        T.check("unknown click/hover shapes are ignored without crashing", Chat.fromJsonText("{\"text\":\"z\",\"clickEvent\":5,\"hoverEvent\":{\"action\":\"nope\"}}").get(0).click == null);
        List<List<Chat.Span>> lines = Chat.splitLines(Chat.fromJsonText("{\"text\":\"a\\nb\\n\\nc\",\"color\":\"red\"}"));
        T.eq("splitLines: 4 lines", lines.size(), 4);
        T.check("splitLines keeps the colour", lines.get(1).get(0).color == Chat.LEGACY[12] && lines.get(2).isEmpty());

        T.suite("layout: spans keep events, and pack fonts are measured by the metrics");
        TextLayout.Metrics fonts = new TextLayout.Metrics() {
            @Override public int width(String t, TextLayout.Type ty, boolean b) { return t.length() * 6; }
            @Override public int charWidth(TextLayout.Seg s, char c) { return 6; }
            @Override public int fontWidth(String font, String t, boolean b) { return font.equals("ns:icons") ? t.length() * 11 : Integer.MIN_VALUE; }
        };
        List<Chat.Span> in = Chat.fromJsonText("{\"text\":\"ab\",\"font\":\"ns:icons\",\"extra\":[{\"text\":\" cd\",\"font\":\"minecraft:default\"}]}");
        TextLayout.Layout lay = TextLayout.build(in, 200, fonts);
        TextLayout.Seg first = lay.lines.get(0).get(0);
        T.check("a run with a pack font uses fontWidth (2 chars x 11)", first.text.equals("ab") && first.width == 22);
        T.check("a run with an unknown font falls back to the default metrics", lay.lines.get(0).get(lay.lines.get(0).size() - 1).width == 12);
        T.check("layout segments still carry the font id", first.span.font.equals("ns:icons"));
        List<Chat.Span> ev = Chat.fromJsonText("{\"text\":\"click me\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/spawn\"}}");
        TextLayout.Layout l2 = TextLayout.build(ev, 200, fonts);
        boolean all = true;
        for (List<TextLayout.Seg> line : l2.lines) for (TextLayout.Seg sg : line) if (sg.type != TextLayout.Type.SPACE && (sg.span.click == null || !sg.span.click.value.equals("/spawn"))) all = false;
        T.check("every laid-out word of a clickable component still has its click event (hit testing works on segments)", all);
        TextLayout.Layout l3 = TextLayout.build(Chat.fromJsonText("{\"text\":\"aaaa bbbb cccc dddd eeee ffff\",\"clickEvent\":{\"action\":\"open_url\",\"value\":\"https://x\"}}"), 60, fonts);
        boolean wrapped = l3.lines.size() > 1, kept = true;
        for (List<TextLayout.Seg> line : l3.lines) for (TextLayout.Seg sg : line) if (sg.type != TextLayout.Type.SPACE && sg.span.click == null) kept = false;
        T.check("wrapped lines keep the event on every word", wrapped && kept);
    }
}
