import com.mcclient.core.*;
import java.util.*;

/**
 * "No difference from the official client" checks: what the server sees must match LocalPlayer / MultiPlayerGameMode.
 * Rotation granularity, digging timeline, sequence numbers, screens blocking input, respawn pacing, chat salts, break formula, Mth tables.
 */
public final class FidelityTests {
    static boolean multiple(double d, double step) { double q = d / step; return Math.abs(q - Math.round(q)) < 0.02; }

    static List<long[]> entries(ObstacleTests.Stats st, long id) {
        List<long[]> out = new ArrayList<>();
        synchronized (st.log) { for (long[] e : st.log) if (e[0] == id) out.add(e); }
        return out;
    }

    static boolean has(ObstacleTests.Stats st, long id, long value) { for (long[] e : entries(st, id)) if (e[1] == value) return true; return false; }

    static Buf.Writer signedChat(Random rg, int index) {
        byte[] sig = new byte[256]; rg.nextBytes(sig);
        return new Buf.Writer().uuid(UUID.fromString("00000000-0000-0000-0000-000000000009")).varInt(index).bool(true).bytes(sig)
            .str("hello " + index).i64(0).i64(0).varInt(0).bool(false).varInt(0).varInt(0).nbt("Bob").bool(false);
    }

    static Buf.Writer unsignedChat(int index) {
        return new Buf.Writer().uuid(UUID.fromString("00000000-0000-0000-0000-000000000009")).varInt(index).bool(false)
            .str("plain " + index).i64(0).i64(0).varInt(0).bool(false).varInt(0).varInt(0).nbt("Bob").bool(false);
    }

    static void run() throws Exception {
        T.suite("fidelity: rotation like a mouse (0.15 degree counts, eased, never a snap)");
        MoveTests.with("Mouse", MoveTests.flat(), MoveTests.NO_HOTBAR, 0.5, 5, 0.5, n -> { }, (cs, rec, st, ms) -> {
            cs.startAction(new Actions.GoTo(10, 5, -10, false));   // needs a ~135 degree turn
            T.check("walks the diagonal", Rec.waitFor(() -> ObstacleTests.arrived(rec), 25000));
            List<Float> yaws = new ArrayList<>(st.tracker.yaws), pitches = new ArrayList<>(st.tracker.pitches);
            T.check("the turn takes several ticks (" + yaws.size() + " rotation packets)", yaws.size() >= 4);
            boolean grain = true, speed = true; double prev = 0, maxStep = 0;
            for (float y : yaws) { double d = y - prev; if (!multiple(d, 0.15)) grain = false; maxStep = Math.max(maxStep, Math.abs(d)); prev = y; }
            T.check("every yaw change is a whole number of mouse counts of 0.15 degrees (the GCD a real sensitivity produces)", grain);
            T.check("no rotation snap: at most 38 degrees in one tick (max " + String.format("%.2f", maxStep) + ")", maxStep <= 38.2);
            boolean pg = true; double pp = 0; for (float y : pitches) { if (!multiple(y - pp, 0.15) || y < -90 || y > 90) pg = false; pp = y; }
            T.check("pitch also moves in mouse counts and stays within +-90", pg);
            T.check("the final heading points at the goal (-135 degrees, got " + String.format("%.1f", st.tracker.yaw) + ")", Math.abs(st.tracker.yaw + 135) < 5);
        });

        T.suite("fidelity: digging timeline of MultiPlayerGameMode");
        ObstacleTests.SimWorld two = new ObstacleTests.SimWorld((x, y, z) -> y <= 4 ? ObstacleTests.STONE : ((x == 3 && z == 0 && (y == 5 || y == 6)) ? ObstacleTests.DIRT : 0));
        MoveTests.with("Digger", two, MoveTests.NO_HOTBAR, 0.5, 5, 0.5, n -> { }, (cs, rec, st, ms) -> {
            int need = Tools.breakTicks(cs.world.hardness(3, 5, 0), "dirt", null, true, false, 0); // before the block is gone
            cs.startAction(new Actions.Mine("dirt", new String[]{"dirt"}, 2));
            T.check("both blocks dug", Rec.waitFor(() -> st.digs.size() >= 2, 40000));
            Thread.sleep(400);
            List<long[]> log = new ArrayList<>(); synchronized (st.log) { log.addAll(st.log); }
            List<Integer> starts = new ArrayList<>(), stops = new ArrayList<>();
            for (int i = 0; i < log.size(); i++) if (log.get(i)[0] == 0x21) { if (log.get(i)[1] == 0) starts.add(i); else if (log.get(i)[1] == 2) stops.add(i); }
            T.eq("two START and two STOP destroy actions", starts.size() + stops.size(), 4);
            long t0 = log.get(starts.get(0))[4], t1 = log.get(stops.get(0))[4];
            T.check("STOP only after the full progress: " + need + " ticks of work (" + (t1 - t0) / 1_000_000 + " ms)", (t1 - t0) / 1e6 >= (need - 1) * 45.0);
            T.check("a Swing follows START in the same tick", log.get(starts.get(0) + 1)[0] == 0x33);
            int swings = 0; for (int i = starts.get(0); i < stops.get(0); i++) if (log.get(i)[0] == 0x33) swings++;
            T.check("a Swing in EVERY tick while digging (" + swings + " swings for " + need + " ticks)", swings >= need - 1 && swings <= need + 2);
            T.check("a Swing right after STOP too", log.get(stops.get(0) + 1)[0] == 0x33);
            long gap = (log.get(starts.get(1))[4] - log.get(stops.get(0))[4]) / 1_000_000;
            T.check("destroyDelay: at least 5 ticks between STOP and the next START (" + gap + " ms)", gap >= 200);
            T.check("sequence numbers of START/STOP are consecutive 1,2,3,4",
                log.get(starts.get(0))[2] == 1 && log.get(stops.get(0))[2] == 2 && log.get(starts.get(1))[2] == 3 && log.get(stops.get(1))[2] == 4);
            T.check("START carries a face and STOP the same face", log.get(starts.get(0))[3] == log.get(stops.get(0))[3]);
        });

        T.suite("fidelity: drop / swap packets and chat salts");
        MoveTests.with("Misc", MoveTests.flat(), MoveTests.NO_HOTBAR, 0.5, 5, 0.5, n -> { }, (cs, rec, st, ms) -> {
            Thread.sleep(800);
            cs.dropHeld(false); cs.dropHeld(true); cs.swapHands();
            T.check("drop one, drop stack and swap hands arrive", Rec.waitFor(() -> has(st, 0x21, 4) && has(st, 0x21, 3) && has(st, 0x21, 6), 3000));
            boolean zero = true; for (long[] e : entries(st, 0x21)) if (e[1] >= 3 && (e[2] != 0 || e[3] != 0)) zero = false;
            T.check("their sequence is 0 and their face DOWN (only destroy START/STOP are predicted)", zero);
            cs.sendUserText("hello"); cs.sendUserText("hello");
            T.check("two chat messages arrive", Rec.waitFor(() -> entries(st, 0x05).size() >= 2, 3000));
            List<long[]> chats = entries(st, 0x05);
            T.check("each chat message has its own random salt", chats.get(0)[1] != 0 && chats.get(1)[1] != 0 && chats.get(0)[1] != chats.get(1)[1]);
        });

        T.suite("fidelity: an open screen means no movement input");
        MoveTests.with("Screen", MoveTests.flat(), MoveTests.NO_HOTBAR, 0.5, 5, 0.5, n -> { }, (cs, rec, st, ms) -> {
            Thread.sleep(1200);
            Thread pad = new Thread(() -> { try { MoveTests.hold(cs, 1, 0, false, false, false, 6500); } catch (Exception e) { /* test over */ } });
            pad.start();
            Thread.sleep(900);
            T.check("the pad walks while no screen is open", st.z > 1.0);
            cs.clickSlot(9, 0, 0);
            T.check("clicking in the player's window opens its screen", Rec.waitFor(cs::isScreenOpen, 2000));
            Thread.sleep(700);
            double zStop = st.z; Thread.sleep(1500);
            T.check("the player stops walking while the screen is open (moved " + String.format("%.2f", st.z - zStop) + " in 1.5 s)", st.z - zStop < 0.05);
            T.check("no sprint/jump either: still on the ground", st.tracker.ground);
            T.check("the screen closes itself after a few idle seconds with Close Container(0)", Rec.waitFor(() -> has(st, 0x0E, 0), 7000));
            T.check("...and the screen is closed afterwards", Rec.waitFor(() -> !cs.isScreenOpen(), 1000));
            pad.join();
            double z2 = st.z; MoveTests.hold(cs, 1, 0, false, false, false, 1200);
            T.check("walking works again after closing (" + String.format("%.2f", st.z - z2) + ")", st.z - z2 > 2.0);
            int closes = entries(st, 0x0E).size();
            cs.clickSlot(10, 0, 0);
            Thread.sleep(300);
            cs.closeWindow();
            T.check("closing the inventory by hand sends Close Container(0) at once", Rec.waitFor(() -> entries(st, 0x0E).size() > closes, 1500));
        });

        T.suite("fidelity: respawn pacing");
        MoveTests.with("Death", MoveTests.flat(), MoveTests.NO_HOTBAR, 0.5, 5, 0.5, n -> { }, (cs, rec, st, ms) -> {
            Thread.sleep(800);
            long t0 = System.nanoTime();
            st.client.send(0x5B, new Buf.Writer().f32(0f).varInt(20).f32(0f));
            T.check("a respawn request follows", Rec.waitFor(() -> has(st, 0x08, 0), 6000));
            long ms1 = (entries(st, 0x08).get(0)[4] - t0) / 1_000_000;
            T.check("...after 1.3 - 3 seconds like a person pressing the button (" + ms1 + " ms)", ms1 >= 1200 && ms1 <= 3600);
        });

        T.suite("fidelity: an idle (AFK) client sends only what the official client sends");
        MoveTests.with("Idle", MoveTests.flat(), MoveTests.NO_HOTBAR, 0.5, 5, 0.5, n -> { }, (cs, rec, st, ms) -> {
            Thread.sleep(2500);                                   // join, land, settle
            int from = st.ids.size();
            int posFrom = st.posLog.size();
            long t0 = System.nanoTime();
            // a busy server talks to us the whole time; none of this may provoke anything but the protocol replies
            long ka = 1000;
            for (int sec = 0; sec < 9; sec++) {
                st.client.send(0x24, new Buf.Writer().i64(ka + sec));                         // Keep Alive
                st.client.send(0x33, new Buf.Writer().i32(500 + sec));                        // Ping
                st.client.send(0x69, new Buf.Writer().nbt(Chat.fromJsonText("{\"text\":\"server says hi\"}").isEmpty() ? "x" : "server says hi").bool(false)); // system chat
                st.client.send(0x58, new Buf.Writer().varInt(99).s16(100).s16(0).s16(0));     // another entity's velocity
                st.client.send(0x5B, new Buf.Writer().f32(20f).varInt(20).f32(5f));           // unchanged health / food
                Thread.sleep(1000);
            }
            Thread.sleep(300);
            List<long[]> ids; synchronized (st.ids) { ids = new ArrayList<>(st.ids.subList(from, st.ids.size())); }
            Set<Long> kinds = new TreeSet<>(); for (long[] e : ids) kinds.add(e[0]);
            T.check("only Pos (0x17), Keep Alive reply (0x15) and Pong (0x24) were sent in 9 s: " + kinds, kinds.equals(new TreeSet<>(Arrays.asList(0x17L, 0x15L, 0x24L))));
            int pos = 0, kaCount = 0, pong = 0; for (long[] e : ids) { if (e[0] == 0x17) pos++; else if (e[0] == 0x15) kaCount++; else if (e[0] == 0x24) pong++; }
            T.check("exactly one Keep Alive reply and one Pong per server packet (" + kaCount + "/" + pong + " for 9)", kaCount == 9 && pong == 9);
            T.check("the position reminder goes out once per second, every 20 ticks (" + pos + " in 9.3 s)", pos >= 8 && pos <= 10);
            List<double[]> pl; synchronized (st.posLog) { pl = new ArrayList<>(st.posLog.subList(posFrom, st.posLog.size())); }
            boolean same = true, ground = true;
            for (double[] e : pl) { if (e[0] != 0.5 || e[1] != 5.0 || e[2] != 0.5) same = false; if (e[3] != 1) ground = false; }
            T.check("every reminder carries exactly the same coordinates (no drift, no jitter) and onGround=true", same && ground && !pl.isEmpty());
            double sum = 0; int n = 0; double min = 1e9, max = 0;
            for (int i = 1; i < pl.size(); i++) { double dt = (pl.get(i)[4] - pl.get(i - 1)[4]) / 1e6; sum += dt; n++; min = Math.min(min, dt); max = Math.max(max, dt); }
            T.check("the reminders are 1000 ms apart (" + String.format("%.0f", sum / Math.max(1, n)) + " ms on average, " + String.format("%.0f-%.0f", min, max) + ")", n > 5 && Math.abs(sum / n - 1000) < 40 && min > 850 && max < 1200);
            
            // a teleport to where we already are: Confirm, PosRot(onGround=false), then silence like the official client
            int mark = st.ids.size();
            st.client.send(0x3E, new Buf.Writer().f64(0.5).f64(5.0).f64(0.5).f32(0f).f32(0f).b(0).varInt(77));
            Thread.sleep(700);
            List<long[]> after; synchronized (st.ids) { after = new ArrayList<>(st.ids.subList(mark, st.ids.size())); }
            T.check("teleport: Confirm Teleportation (0x00) first, then PosRot (0x18): " + (after.size() > 1 ? after.get(0)[0] + "," + after.get(1)[0] : "?"), after.size() >= 2 && after.get(0)[0] == 0x00 && after.get(1)[0] == 0x18);
            double[] echo = null; synchronized (st.posLog) { for (int i = st.posLog.size() - 1; i >= 0; i--) if (st.posLog.get(i)[5] == 0x18) { echo = st.posLog.get(i); break; } }
            T.check("...with onGround=false and the teleport position", echo != null && echo[3] == 0 && echo[0] == 0.5 && echo[1] == 5.0 && echo[2] == 0.5);
            // ClientPacketListener.handleMovePlayer zeroes the vertical speed, so the next tick has onGround=false (vy 0 moves nowhere) and the one
            // after lands again: the official client sends exactly Confirm, PosRot(false), OnGround(false), OnGround(true) and then only the reminder.
            List<double[]> grounds = new ArrayList<>(); synchronized (st.posLog) { for (double[] e : st.posLog) if (e[5] == 0x1A && e[4] >= after.get(0)[1]) grounds.add(e); }
            T.check("then OnGround(false) and OnGround(true) from the one-tick hop, exactly like the official client (" + grounds.size() + " status packets)",
                after.size() >= 4 && after.get(2)[0] == 0x1A && after.get(3)[0] == 0x1A && grounds.size() >= 2 && grounds.get(0)[3] == 0 && grounds.get(1)[3] == 1);
            boolean quiet = true; for (int i = 4; i < after.size(); i++) if (after.get(i)[0] != 0x17) quiet = false;
            T.check("...and nothing besides at most one 1 Hz reminder afterwards (" + after.size() + " packets in 700 ms)", quiet && after.size() <= 5);
        });

        T.suite("fidelity: signed chat tracking (LastSeenMessagesTracker)");
        MoveTests.with("Signed", MoveTests.flat(), MoveTests.NO_HOTBAR, 0.5, 5, 0.5, n -> { }, (cs, rec, st, ms) -> {
            Thread.sleep(800);
            Random rg = new Random(3);
            for (int i = 0; i < 3; i++) st.client.send(0x37, signedChat(rg, i));
            Thread.sleep(400);
            cs.sendUserText("one");
            T.check("the outgoing chat message arrives", Rec.waitFor(() -> entries(st, 0x05).size() >= 1, 3000));
            long[] m1 = entries(st, 0x05).get(0);
            T.check("after 3 signed messages the next message carries offset 3 and acknowledges them (bits 17-19 of the ring: 0x0E0000, got 0x" + Long.toHexString(m1[3]) + ", offset " + m1[2] + ")", m1[2] == 3 && m1[3] == 0x0E0000L);
            cs.sendUserText("two");
            Rec.waitFor(() -> entries(st, 0x05).size() >= 2, 3000);
            long[] m2 = entries(st, 0x05).get(1);
            T.check("the offset was consumed (0 now) while the acknowledged ring stays", m2[2] == 0 && m2[3] == 0x0E0000L);
            T.check("no ChatAck so far (the real client waits for more than 64)", entries(st, 0x03).isEmpty());
            for (int i = 3; i < 3 + 64; i++) st.client.send(0x37, signedChat(rg, i));
            Thread.sleep(600);
            T.check("64 more signed messages (offset 64) are still not acknowledged", entries(st, 0x03).isEmpty());
            st.client.send(0x37, signedChat(rg, 99));
            T.check("the 65th pending message triggers Chat Ack with value 65 (not 20)", Rec.waitFor(() -> entries(st, 0x03).size() == 1, 3000) && entries(st, 0x03).get(0)[1] == 65);
            // unsigned messages (offline servers) are never tracked
            for (int i = 0; i < 80; i++) st.client.send(0x37, unsignedChat(i));
            Thread.sleep(600);
            T.check("unsigned chat never produces a Chat Ack", entries(st, 0x03).size() == 1);
        });

        T.suite("fidelity: formulas and tables");
        T.check("Mth.sin / cos table: quarter turns are exact", Physics.mthSin(0f) == 0f && Physics.mthCos(0f) == 1f && Physics.mthSin((float) (Math.PI / 2)) == 1f);
        Random rnd = new Random(7);
        double maxErr = 0;
        for (int i = 0; i < 5000; i++) { float a = (rnd.nextFloat() - 0.5f) * 20f; maxErr = Math.max(maxErr, Math.max(Math.abs(Physics.mthSin(a) - Math.sin(a)), Math.abs(Physics.mthCos(a) - Math.cos(a)))); }
        T.check("the table is within 1e-4 of the true sine (max " + maxErr + ") but not identical to Math.sin", maxErr < 1e-4 && maxErr > 1e-8);
        T.check("break ticks: dirt by hand 15-16 (hardness 0.5, 1/0.5/30)", Tools.breakTicks(0.5, "dirt", null) >= 15 && Tools.breakTicks(0.5, "dirt", null) <= 16);
        T.check("break ticks: stone with an iron pickaxe 8 (6/1.5/30)", Tools.breakTicks(1.5, "stone", "iron_pickaxe") == 8);
        T.check("in the air everything takes 5x longer (iron pickaxe, stone: " + Tools.breakTicks(1.5, "stone", "iron_pickaxe", false, false, 0) + ")", Tools.breakTicks(1.5, "stone", "iron_pickaxe", false, false, 0) >= 38 && Tools.breakTicks(1.5, "stone", "iron_pickaxe", false, false, 0) <= 41);
        T.check("with the head under water also 5x", Tools.breakTicks(1.5, "stone", "iron_pickaxe", true, true, 0) >= 38);
        T.check("Mining Fatigue I slows to 0.3 (25 ticks)", Tools.breakTicks(1.5, "stone", "iron_pickaxe", true, false, 1) >= 25 && Tools.breakTicks(1.5, "stone", "iron_pickaxe", true, false, 1) <= 27);
        T.check("a wooden pickaxe does not harvest diamond ore: speed 2 but 100 instead of 30 (150+ ticks)", Tools.breakTicks(3.0, "diamond_ore", "wooden_pickaxe") >= 150);
        T.check("an iron pickaxe does: 6/3/30 = 15 ticks", Tools.breakTicks(3.0, "diamond_ore", "iron_pickaxe") >= 15 && Tools.breakTicks(3.0, "diamond_ore", "iron_pickaxe") <= 16);
        T.check("obsidian with a diamond pickaxe ~188 ticks", Math.abs(Tools.breakTicks(50.0, "obsidian", "diamond_pickaxe") - 188) <= 2);
        T.check("instant and unbreakable", Tools.breakTicks(0.0, "grass", null) == 1 && Tools.breakTicks(-1.0, "bedrock", "diamond_pickaxe") == Integer.MAX_VALUE);
    }
}
