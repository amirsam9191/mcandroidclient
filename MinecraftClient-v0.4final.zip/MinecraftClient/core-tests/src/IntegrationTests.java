import com.mcclient.core.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** End-to-end tests: the real ClientSession talks over TCP to the independent MockServer. */
public final class IntegrationTests {
    static void run() throws Exception {
        status(); handshakeAndChat(); autoLoginAndStartupCommands(); kickAndAutoRejoin(); onlineModeRefused();
        worldAndPhysics(); inventory(); respawnLogic(); robustness(); resourcePacks(); walking(); following();
    }

    static ClientSession.Profile profile(MockServer s, String user) {
        ClientSession.Profile p = new ClientSession.Profile();
        p.address = s.address(); p.username = user; p.name = "test";
        return p;
    }

    static ClientSession newSession(Rec rec) {
        ClientSession cs = new ClientSession(rec);
        cs.config.rejoinDelaySec = 1;
        cs.config.packDir = new java.io.File(System.getProperty("java.io.tmpdir"), "mc-test-packs-" + System.nanoTime());
        return cs;
    }

    static boolean online(Rec r) { return r.statuses.contains(ClientSession.Status.ONLINE); }

    // ------------------------------------------------------------------------------------------

    static void status() throws Exception {
        T.suite("server list ping");
        byte[] icon = new byte[]{(byte) 0x89, 'P', 'N', 'G', 1, 2, 3};
        String json = "{\"version\":{\"name\":\"Paper 1.20.4\",\"protocol\":765},\"players\":{\"max\":100,\"online\":7},"
            + "\"description\":{\"text\":\"\u00A7aسلام \",\"extra\":[{\"text\":\"World\",\"color\":\"gold\"}]},"
            + "\"favicon\":\"data:image/png;base64," + Base64.getEncoder().encodeToString(icon) + "\"}";
        try (MockServer ms = new MockServer(c -> {
            MockServer.Pkt hs = c.expect(0x00, 3000);
            T.eq("status handshake protocol", hs.r.varInt(), 765);
            hs.r.str(); hs.r.u16();
            T.eq("status handshake next state", hs.r.varInt(), 1);
            c.expect(0x00, 3000);
            c.send(0x00, new Buf.Writer().str(json));
            MockServer.Pkt ping = c.expect(0x01, 3000);
            c.send(0x01, new Buf.Writer().i64(ping.r.i64()));
        })) {
            Pinger.Result r = Pinger.ping(ms.address());
            T.check("ping ok", r.ok);
            T.eq("players online/max", r.online + "/" + r.max, "7/100");
            T.eq("version", r.version, "Paper 1.20.4");
            StringBuilder sb = new StringBuilder(); for (Chat.Span s : r.motd) sb.append(s.text);
            T.eq("motd text", sb.toString(), "سلام World");
            T.eq("motd colour (legacy green)", r.motd.get(0).color, Chat.LEGACY[10]);
            T.eq("motd colour (gold)", r.motd.get(r.motd.size() - 1).color, Chat.LEGACY[6]);
            T.check("favicon bytes decoded", Arrays.equals(r.icon, icon));
            T.check("latency measured", r.pingMs >= 0 && r.pingMs < 2000);
        }
        Pinger.Result dead = Pinger.ping("127.0.0.1:1");
        T.check("unreachable server reported as failed, not hung", !dead.ok && !dead.error.isEmpty());
    }

    // ------------------------------------------------------------------------------------------

    static void handshakeAndChat() throws Exception {
        T.suite("login, compression, chat, health, players, suggestions");
        CountDownLatch done = new CountDownLatch(1);
        List<String> clientSent = Collections.synchronizedList(new ArrayList<String>());
        try (MockServer ms = new MockServer(c -> {
            Flow.joinAs(c, 64);
            // keep-alive / ping / chunk batch handshakes
            c.send(0x24, new Buf.Writer().i64(123456789L));
            T.eq("keep-alive echoed", c.await(0x15, 3000).r.i64(), 123456789L);
            c.send(0x33, new Buf.Writer().i32(77));
            T.eq("ping answered with pong", c.await(0x24, 3000).r.i32(), 77);
            c.send(0x0D, new Buf.Writer()); // Chunk Batch Start
            c.send(0x0C, new Buf.Writer().varInt(9));
            float desired = c.await(0x07, 3000).r.f32();
            // ChunkBatchSizeCalculator: starts at 2 ms per chunk (3.5 chunks/tick); one sample moves it by at most a factor 1.75-5.25
            T.check("chunk batch acknowledged with the calculated chunks per tick, not a constant (" + desired + ")", desired >= 1.74f && desired <= 5.26f && desired != 10f);
            Flow.syncPosition(c, 100.5, 70, -20.25, 4);

            // chat of every kind
            Flow.systemChat(c, "plain system line", false);
            Map<String, Object> colored = Flow.comp("Server: ", "red");
            colored.put("extra", new ArrayList<Object>(Arrays.asList(Flow.comp("ok", "green"))));
            Flow.systemChat(c, colored, false);
            Flow.systemChat(c, "hotbar text", true);
            UUID alice = UUID.randomUUID();
            Flow.playerInfoAdd(c, alice, "Alice");
            UUID bob = UUID.randomUUID();
            Flow.playerInfoAdd(c, bob, "Bob");
            // unsigned player chat, chat type 0
            c.send(0x37, new Buf.Writer().uuid(alice).varInt(0).bool(false).str("hello from alice").i64(1L).i64(2L).varInt(0)
                .bool(false).varInt(0).varInt(0).nbt(Flow.comp("Alice", null)).bool(false));
            // signed whisper (type 1) with previous-message entries and an unsigned-content override
            c.send(0x37, new Buf.Writer().uuid(bob).varInt(1).bool(true).bytes(new byte[256]).str("raw").i64(1L).i64(2L)
                .varInt(2).varInt(0).bytes(new byte[256]).varInt(5)
                .bool(true).nbt(Flow.comp("secret سلام", "gray")).varInt(2).varInt(1).i64(0L).varInt(1).nbt(Flow.comp("Bob", null)).bool(true).nbt(Flow.comp("You", null)));
            // disguised chat (type 2 = emote)
            c.send(0x1C, new Buf.Writer().nbt("dances").varInt(2).nbt(Flow.comp("Alice", null)).bool(false));
            c.send(0x5B, new Buf.Writer().f32(14.5f).varInt(17).f32(3f));
            c.send(0x3B, new Buf.Writer().varInt(1).uuid(bob)); // Bob leaves

            // user -> server
            MockServer.Pkt m = c.await(0x05, 5000);
            clientSent.add("msg:" + m.r.str());
            T.check("chat message timestamp is current", Math.abs(m.r.i64() - System.currentTimeMillis()) < 5000);
            long salt1 = m.r.i64();
            T.check("chat message salt is random like the real client (not 0)", salt1 != 0L);
            T.eq("chat message has no signature", m.r.bool(), false);
            T.eq("chat message count: the signed message seen before is acknowledged (offset 1, like the real client)", m.r.varInt(), 1);
            T.eq("acknowledged bitset is 3 bytes", m.r.remaining(), 3);
            MockServer.Pkt cmd = c.await(0x04, 5000);
            clientSent.add("cmd:" + cmd.r.str());
            cmd.r.i64(); cmd.r.i64();
            T.eq("command: no argument signatures", cmd.r.varInt(), 0);
            T.eq("command: message count", cmd.r.varInt(), 0);
            T.eq("command: bitset is 3 bytes", cmd.r.remaining(), 3);
            MockServer.Pkt sg = c.await(0x0A, 5000);
            int tid = sg.r.varInt();
            T.eq("suggestion request text", sg.r.str(), "/gam");
            c.send(0x10, new Buf.Writer().varInt(tid).varInt(1).varInt(3).varInt(2).str("gamemode").bool(false).str("gamerule").bool(true).nbt("tip"));
            done.countDown();
            while (!c.eof) Thread.sleep(50);
        })) {
            Rec rec = new Rec();
            ClientSession cs = newSession(rec);
            ClientSession.Profile p = profile(ms, "Steve_1");
            cs.connect(p);
            T.check("session reaches ONLINE", Rec.waitFor(() -> online(rec), 5000));
            T.check("plain system chat", rec.waitChat("plain system line", 3000));
            T.check("compound system chat flattened", rec.waitChat("Server: ok", 3000));
            T.check("action bar separate from chat", Rec.waitFor(() -> rec.actionBar.equals("hotbar text"), 3000) && !rec.chatHas("hotbar text"));
            T.check("unsigned chat uses registry format <sender> message", rec.waitChat("<Alice> hello from alice", 3000));
            T.check("signed chat shows the unsigned-content override and registry type 1", rec.waitChat("Bob whispers to you: secret سلام", 3000));
            T.check("disguised chat uses emote format", rec.waitChat("* Alice dances", 3000));
            T.check("health + food reported", Rec.waitFor(() -> rec.hp == 14.5f && rec.food == 17, 3000));
            T.check("player list tracks joins and leaves", Rec.waitFor(() -> rec.players.equals(Arrays.asList("Alice")), 3000));
            T.check("position exposed", Rec.waitFor(() -> cs.hasPosition() && cs.x() == 100.5, 3000));

            T.check("send chat message", cs.sendUserText("hello مرحبا world"));
            T.check("send command", cs.sendUserText("/gamemode creative"));
            T.check("completes /gam via server", true);
            cs.requestSuggestions("/gam");
            T.check("server suggestions delivered", Rec.waitFor(() -> rec.suggestions != null && rec.suggestions.items.size() == 2, 5000));
            T.check("suggestion range", rec.suggestions != null && rec.suggestions.start == 1 && rec.suggestions.length == 3 && rec.suggestions.items.get(0).equals("gamemode"));
            cs.requestSuggestions("hi Al");
            T.check("local player-name completion", Rec.waitFor(() -> rec.suggestions != null && rec.suggestions.items.equals(Arrays.asList("Alice")) && rec.suggestions.start == 3, 3000));
            T.check("scenario assertions finished", done.await(10, TimeUnit.SECONDS));
            T.eq("client sent the message text unchanged", clientSent.get(0), "msg:hello مرحبا world");
            T.eq("client sent the command without the slash", clientSent.get(1), "cmd:gamemode creative");
            cs.disconnect();
            T.check("manual disconnect -> IDLE", Rec.waitFor(() -> cs.status() == ClientSession.Status.IDLE, 3000));
            T.check("manual disconnect has no end reason", Rec.waitFor(() -> rec.ended != null && rec.ended.isEmpty(), 3000));
            T.check("not logged in while idle: sendUserText refused", !cs.sendUserText("x"));
        }
    }

    // ------------------------------------------------------------------------------------------

    static void autoLoginAndStartupCommands() throws Exception {
        T.suite("auto-login and startup commands");
        List<String> log = Collections.synchronizedList(new ArrayList<String>());
        List<Long> times = Collections.synchronizedList(new ArrayList<Long>());
        long[] t0 = new long[1];
        try (MockServer ms = new MockServer(c -> {
            Flow.joinAs(c, -1);
            t0[0] = c.ms();
            Flow.syncPosition(c, 0.5, 5, 0.5, 1);
            t0[0] = c.ms();
            long end = System.currentTimeMillis() + 7000;
            while (System.currentTimeMillis() < end) {
                MockServer.Pkt p;
                try { p = c.next(500); } catch (TimeoutException e) { continue; }
                if (p.id == 0x04 || p.id == 0x05) { log.add((p.id == 0x04 ? "/" : "") + p.r.str()); times.add(c.ms() - t0[0]); }
            }
        })) {
            Rec rec = new Rec();
            ClientSession cs = newSession(rec);
            ClientSession.Profile p = profile(ms, "Autolog");
            p.autoLogin = true; p.password = "s3cret pass";
            p.commands.add(new ClientSession.Cmd("/home", 1));
            p.commands.add(new ClientSession.Cmd("hello everyone", 2));
            p.commands.add(new ClientSession.Cmd("/spawn", 0));
            p.commands.add(new ClientSession.Cmd("   ", 0));
            cs.connect(p);
            T.check("all scheduled sends observed within 8 s", Rec.waitFor(() -> log.size() >= 4, 9000));
            T.eq("order: login, /spawn, /home, chat", log.subList(0, Math.min(4, log.size())).toString(), "[/login s3cret pass, /spawn, /home, hello everyone]");
            if (times.size() >= 4) {
                T.check("login sent ~1.5 s after the first position sync (" + times.get(0) + " ms)", times.get(0) >= 1300 && times.get(0) <= 2600);
                T.check("startup commands start after the login (>= 2.4 s, got " + times.get(1) + " ms)", times.get(1) >= 2400);
                T.check("delays are honoured: /home 1 s after /spawn", times.get(2) - times.get(1) >= 800 && times.get(2) - times.get(1) <= 1500);
                T.check("delays are honoured: chat 1 s after /home", times.get(3) - times.get(2) >= 800 && times.get(3) - times.get(2) <= 1500);
            }
            T.check("blank startup command ignored", log.size() == 4);
            cs.disconnect();
        }
        // without auto-login the commands run from t=0
        List<String> log2 = Collections.synchronizedList(new ArrayList<String>());
        List<Long> times2 = Collections.synchronizedList(new ArrayList<Long>());
        try (MockServer ms = new MockServer(c -> {
            Flow.joinAs(c, 256);
            Flow.syncPosition(c, 0.5, 5, 0.5, 1);
            long t = c.ms();
            long end = System.currentTimeMillis() + 3000;
            while (System.currentTimeMillis() < end) {
                MockServer.Pkt p;
                try { p = c.next(300); } catch (TimeoutException e) { continue; }
                if (p.id == 0x04 || p.id == 0x05) { log2.add(p.r.str()); times2.add(c.ms() - t); }
            }
        })) {
            Rec rec = new Rec();
            ClientSession cs = newSession(rec);
            ClientSession.Profile p = profile(ms, "NoLogin");
            p.commands.add(new ClientSession.Cmd("/first", 0));
            cs.connect(p);
            T.check("no auto-login: command at t~0", Rec.waitFor(() -> log2.size() == 1, 4000) && times2.get(0) < 600);
            T.eq("no /login is sent when auto-login is off", log2.toString(), "[first]");
            cs.disconnect();
        }
    }

    // ------------------------------------------------------------------------------------------

    static void kickAndAutoRejoin() throws Exception {
        T.suite("kick and auto-rejoin");
        T.eq("default rejoin delay is 5 s", new ClientSession.Config().rejoinDelaySec, 5);
        List<String> logins = Collections.synchronizedList(new ArrayList<String>());
        List<Long> connectTimes = Collections.synchronizedList(new ArrayList<Long>());
        long[] kickAt = new long[1];
        try (MockServer ms = new MockServer(c -> {
            connectTimes.add(System.nanoTime() / 1_000_000);
            Flow.joinAs(c, 128);
            Flow.syncPosition(c, 0.5, 5, 0.5, 1);
            MockServer.Pkt p = c.await(0x04, 4000);
            logins.add("conn" + c.number + ":" + p.r.str());
            if (c.number == 1) {
                kickAt[0] = System.nanoTime() / 1_000_000;
                Map<String, Object> reason = Flow.comp("You were kicked: ", "red");
                reason.put("extra", new ArrayList<Object>(Arrays.asList("AFK")));
                c.send(0x1B, new Buf.Writer().nbt(reason));
            } else {
                while (!c.eof) Thread.sleep(50);
            }
        })) {
            Rec rec = new Rec();
            ClientSession cs = newSession(rec);
            ClientSession.Profile p = profile(ms, "Rejoiner");
            p.autoLogin = true; p.password = "pw"; p.autoRejoin = true;
            cs.connect(p);
            T.check("kicked then reconnected (2 connections)", Rec.waitFor(() -> ms.connections.get() >= 2, 15000));
            T.check("kick reason displayed in chat", rec.waitChat("از سرور بیرون انداخته شدید: You were kicked: AFK", 3000));
            T.check("countdown reported", rec.reconnectCountdown.contains(1));
            T.check("status passes through WAITING_RECONNECT", rec.statuses.contains(ClientSession.Status.WAITING_RECONNECT));
            T.check("rejoin delay respected (>= 1 s after the kick; measured " + (connectTimes.size() >= 2 ? (connectTimes.get(1) - kickAt[0]) + " ms" : "no second connection") + ")", connectTimes.size() >= 2 && connectTimes.get(1) - kickAt[0] >= 700); // the server-side timestamps jitter by ~100 ms on a loaded single core
            T.check("auto-login sent again after rejoin", Rec.waitFor(() -> logins.size() >= 2, 8000));
            T.eq("both joins sent /login pw", logins.toString(), "[conn1:login pw, conn2:login pw]");
            cs.disconnect();
            T.check("manual disconnect stops the rejoin loop", Rec.waitFor(() -> cs.status() == ClientSession.Status.IDLE, 4000));
            Thread.sleep(1500);
            T.eq("no third connection after manual disconnect", ms.connections.get(), 2);
        }
        // auto-rejoin off
        try (MockServer ms = new MockServer(c -> {
            Flow.joinAs(c, -1);
            c.send(0x1B, new Buf.Writer().nbt("Bye"));
        })) {
            Rec rec = new Rec();
            ClientSession cs = newSession(rec);
            cs.connect(profile(ms, "NoRejoin"));
            T.check("kick without auto-rejoin ends the session", Rec.waitFor(() -> rec.ended != null, 5000));
            T.check("end reason names the kick", rec.ended != null && rec.ended.contains("Bye"));
            Thread.sleep(1500);
            T.eq("no reconnect attempt", ms.connections.get(), 1);
            T.eq("status idle", cs.status(), ClientSession.Status.IDLE);
        }
        // server down with auto-rejoin: keeps retrying until stopped
        try (MockServer dead = new MockServer(c -> { c.close(); })) {
            Rec rec = new Rec();
            ClientSession cs = newSession(rec);
            ClientSession.Profile p = profile(dead, "Retry"); p.autoRejoin = true;
            cs.connect(p);
            T.check("repeated attempts while the server drops us", Rec.waitFor(() -> dead.connections.get() >= 3, 12000));
            cs.disconnect();
            T.check("stoppable while waiting", Rec.waitFor(() -> cs.status() == ClientSession.Status.IDLE, 4000));
        }
        Rec rec2 = new Rec();
        ClientSession cs2 = newSession(rec2);
        ClientSession.Profile bad = new ClientSession.Profile(); bad.address = "127.0.0.1:1"; bad.username = "X";
        cs2.connect(bad);
        T.check("connection refused is reported in Persian", Rec.waitFor(() -> rec2.ended != null && rec2.ended.contains("اتصال به سرور برقرار نشد"), 6000));
    }

    static void onlineModeRefused() throws Exception {
        T.suite("online-mode servers");
        try (MockServer ms = new MockServer(c -> {
            c.expect(0x00, 3000); c.expect(0x00, 3000);
            c.send(0x01, new Buf.Writer().str("").varInt(2).b(1).b(2).varInt(4).b(9).b(9).b(9).b(9));
            while (!c.eof) Thread.sleep(30);
        })) {
            Rec rec = new Rec();
            ClientSession cs = newSession(rec);
            cs.connect(profile(ms, "Premium"));
            T.check("encryption request -> clear message, no hang", Rec.waitFor(() -> rec.ended != null && rec.ended.contains("آنلاین‌مود"), 5000));
        }
    }

    // ------------------------------------------------------------------------------------------

    interface Solid { boolean at(int x, int y, int z); }

    static int[][] sectionsFor(Solid s, int cx, int cz) {
        int[][] secs = new int[Flow.WORLD_H / 16][];
        for (int i = 0; i < secs.length; i++) {
            int[] st = new int[4096]; boolean any = false;
            for (int y = 0; y < 16; y++) for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++)
                if (s.at(cx * 16 + x, i * 16 + y, cz * 16 + z)) { st[(y << 8) | (z << 4) | x] = 1; any = true; }
            secs[i] = any ? st : null;
        }
        return secs;
    }

    static void sendWorld(MockServer.Client c, Solid s, int radius) throws Exception {
        for (int cx = -radius; cx <= radius; cx++) for (int cz = -radius; cz <= radius; cz++) Flow.chunk(c, cx, cz, sectionsFor(s, cx, cz));
    }

    static void worldAndPhysics() throws Exception {
        T.suite("world loading, gravity and teleports");
        List<double[]> positions = Collections.synchronizedList(new ArrayList<double[]>());
        Solid floor = (x, y, z) -> y <= 4;
        try (MockServer ms = new MockServer(c -> {
            c.ignorable.clear();
            Flow.joinAs(c, 200);
            sendWorld(c, floor, 1);
            c.send(0x3E, new Buf.Writer().f64(0.5).f64(9.0).f64(0.5).f32(0f).f32(0f).b(0).varInt(1));
            c.expect(0x00, 3000);
            // after the join teleport the client must fall to the floor and then send only reminders
            long end = System.currentTimeMillis() + 2500;
            boolean rubber = false;
            MockServer.Tracker tr = new MockServer.Tracker();
            while (System.currentTimeMillis() < end) {
                MockServer.Pkt p;
                try { p = c.next(300); } catch (TimeoutException e) { continue; }
                if (tr.apply(p)) {
                    double[] pos = {tr.x, tr.y, tr.z, tr.ground ? 1 : 0};
                    positions.add(pos);
                    if (!rubber && pos[3] == 1 && pos[0] < 5) {
                        rubber = true;
                        c.send(0x3E, new Buf.Writer().f64(8.5).f64(5.0).f64(8.5).f32(90f).f32(0f).b(0).varInt(2));
                    }
                } else if (p.id == 0x00) positions.add(new double[]{-1, -1, -1, p.r.varInt()});
            }
            // world edits
            c.send(0x09, new Buf.Writer().i64(((long) (3 & 0x3FFFFFF) << 38) | ((long) (3 & 0x3FFFFFF) << 12) | 6).varInt(1));
            long sec = ((long) 0 << 42) | ((long) 0 << 20) | 0;
            c.send(0x47, new Buf.Writer().i64(sec).varInt(2).varLong((3L << 12) | (5 << 8) | (6 << 4) | 7).varLong((4L << 12) | (0 << 8) | (0 << 4) | 12));
            c.send(0x1F, new Buf.Writer().i32(-1).i32(-1));
            while (!c.eof) Thread.sleep(40);
        })) {
            Rec rec = new Rec();
            ClientSession cs = newSession(rec);
            cs.connect(profile(ms, "Faller"));
            T.check("chunks stream in (9 loaded)", Rec.waitFor(() -> cs.world.chunkCount() == 9, 5000));
            T.eq("world height comes from the dimension_type registry", cs.world.height, Flow.WORLD_H);
            T.eq("block read from a decoded chunk", cs.world.get(5, 4, 5), 1);
            T.eq("air above the floor", cs.world.get(5, 5, 5), 0);
            T.check("fall finished (landed packet seen)", Rec.waitFor(() -> { synchronized (positions) { for (double[] p : positions) if (p[0] < 5 && p[0] != -1 && p[3] == 1) return true; } return false; }, 6000));
            double prev = 9.0; boolean monotonic = true, ground = false; double minY = 1e9; int fallPackets = 0;
            synchronized (positions) {
                for (double[] p : positions) {
                    if (p[0] == -1) continue;
                    if (p[1] > prev + 1e-9) monotonic = p[0] > 5 ? monotonic : false;
                    if (p[0] < 5) { prev = Math.min(prev, p[1]); minY = Math.min(minY, p[1]); if (p[1] > 5.0 + 1e-9) fallPackets++; if (p[1] == 5.0 && p[3] == 1) ground = true; }
                }
            }
            T.check("y never rises while falling", monotonic);
            T.check("lands exactly on the floor surface (y=5, onGround)", ground && Math.abs(minY - 5.0) < 1e-9);
            T.check("fall takes a realistic number of ticks (" + fallPackets + " packets for 4 blocks)", fallPackets >= 8 && fallPackets <= 12);
            T.check("rubber-band teleport confirmed with its own id", Rec.waitFor(() -> { synchronized (positions) { for (double[] p : positions) if (p[0] == -1 && p[3] == 2) return true; } return false; }, 4000));
            T.check("client continues from the teleported position", Rec.waitFor(() -> Math.abs(cs.x() - 8.5) < 0.01 && Math.abs(cs.z() - 8.5) < 0.01, 3000));
            T.check("single block update applied", Rec.waitFor(() -> cs.world.get(3, 6, 3) == 1, 6000));
            T.check("section update: entry 1 (x5,y7,z6 -> state 3)", Rec.waitFor(() -> cs.world.get(5, 7, 6) == 3, 3000));
            T.eq("section update: entry 2 (x0,y12,z0 -> state 4)", cs.world.get(0, 12, 0), 4);
            T.eq("unload chunk removes it", Rec.waitFor(() -> cs.world.chunkCount() == 8, 3000), true);
            T.check("unloaded chunk reads as unknown (-1)", cs.world.get(-8, 4, -8) == -1);
            cs.disconnect();
        }
    }

    // ------------------------------------------------------------------------------------------

    static Map<String, Object> displayNbt(String nameJson, String... loreJson) {
        Map<String, Object> display = new LinkedHashMap<>();
        display.put("Name", nameJson);
        display.put("Lore", new ArrayList<Object>(Arrays.asList((Object[]) loreJson)));
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("display", display);
        root.put("Damage", 3);
        return root;
    }

    static void writeSlot(Buf.Writer w, int id, int count, Object nbt) { if (id < 0) w.bool(false); else w.bool(true).varInt(id).b(count).nbt(nbt); }

    static void inventory() throws Exception {
        T.suite("inventory, containers and item actions");
        Map<String, Object> sword = displayNbt("{\"text\":\"Excalibur\",\"color\":\"gold\",\"italic\":false}", "{\"text\":\"Line one\"}", "\u00A77second \u0633\u0644\u0627\u0645");
        List<MockServer.Pkt> got = Collections.synchronizedList(new ArrayList<MockServer.Pkt>());
        CountDownLatch phase1 = new CountDownLatch(1);
        try (MockServer ms = new MockServer(c -> {
            Flow.joinAs(c, -1);
            Buf.Writer w = new Buf.Writer().b(0).varInt(5).varInt(46);
            for (int i = 0; i < 46; i++) {
                if (i == 36) writeSlot(w, 796, 1, sword);
                else if (i == 37) writeSlot(w, 1, 64, null);
                else if (i == 9) writeSlot(w, 800, 10, null);
                else writeSlot(w, -1, 0, null);
            }
            writeSlot(w, -1, 0, null);
            c.send(0x13, w);
            phase1.countDown();
            while (!c.eof) {
                MockServer.Pkt p;
                try { p = c.next(300); } catch (TimeoutException e) { continue; }
                got.add(p);
                if (p.id == 0x0D) {
                    // authoritative correction: server says slot 20 stays empty
                    // (the client predicted a placed apple there)
                    Buf.Writer sw = new Buf.Writer().b(0).varInt(6).s16(20); writeSlot(sw, -1, 0, null);
                    c.send(0x15, sw);
                }
            }
        })) {
            Rec rec = new Rec();
            ClientSession cs = newSession(rec);
            cs.inventory.items = Data.Items.parse("[{\"id\":1,\"name\":\"stone\"},{\"id\":796,\"name\":\"diamond_sword\"},{\"id\":800,\"name\":\"apple\"}]");
            cs.connect(profile(ms, "Inv"));
            T.check("window content received", phase1.await(5, TimeUnit.SECONDS) && Rec.waitFor(() -> cs.inventory.player().slots[37] != null, 3000));
            Inventory.Stack s = cs.inventory.player().slots[36];
            T.check("sword parsed with id and count", s != null && s.id == 796 && s.count == 1);
            T.eq("custom item name", Chat.plain(Collections.singletonList(null)), "");
            StringBuilder nm = new StringBuilder(); for (Chat.Span sp : s.customName()) nm.append(sp.text);
            T.eq("item display name", nm.toString(), "Excalibur");
            T.eq("item name colour", s.customName().get(0).color, Chat.LEGACY[6]);
            T.eq("lore line count", s.lore().size(), 2);
            StringBuilder lore2 = new StringBuilder(); for (Chat.Span sp : s.lore().get(1)) lore2.append(sp.text);
            T.eq("lore with legacy colour and Persian", lore2.toString(), "second سلام");
            T.eq("lore legacy colour code applied (gray)", s.lore().get(1).get(0).color, Chat.LEGACY[7]);
            T.eq("stack count", cs.inventory.player().slots[37].count, 64);
            T.eq("cursor starts empty", cs.inventory.cursor(), null);
            Inventory.Snapshot snap = cs.inventory.snapshot();
            T.check("snapshot mirrors the window", snap.windowId == 0 && !snap.container && snap.slots.length == 46 && snap.slots[37].count == 64 && snap.playerStart == 9);

            cs.clickSlot(37, 0, 0);                 // pick up the stone stack
            MockServer.Pkt c1 = await(got, 0x0D, 4000);
            T.eq("click: window id", c1.r.u8(), 0);
            T.eq("click: state id from the server", c1.r.varInt(), 5);
            T.eq("click: slot", c1.r.s16(), 37);
            T.eq("click: button", c1.r.i8(), 0);
            T.eq("click: mode", c1.r.varInt(), 0);
            T.eq("click: one changed slot", c1.r.varInt(), 1);
            T.eq("click: changed slot index", c1.r.s16(), 37);
            T.eq("click: slot now empty", Inventory.readSlot(c1.r), null);
            Inventory.Stack carried = Inventory.readSlot(c1.r);
            T.check("click: carried item = stone x64", carried != null && carried.id == 1 && carried.count == 64);
            T.check("local prediction: cursor holds the stone", cs.inventory.cursor() != null && cs.inventory.cursor().count == 64);
            T.check("an earlier snapshot is not affected by later clicks", snap.slots[37] != null && snap.slots[37].count == 64 && snap.cursor == null);
            T.check("a new snapshot shows the prediction", cs.inventory.snapshot().cursor != null && cs.inventory.snapshot().slots[37] == null);

            cs.clickSlot(9, 0, 0);                  // swap with the apples
            MockServer.Pkt c2 = await(got, 0x0D, 4000);
            c2.r.u8(); c2.r.varInt(); T.eq("swap: slot", c2.r.s16(), 9); c2.r.i8(); c2.r.varInt();
            T.eq("swap: changed", c2.r.varInt(), 1);
            c2.r.s16();
            Inventory.Stack placed = Inventory.readSlot(c2.r), nowHeld = Inventory.readSlot(c2.r);
            T.check("swap: stone placed in slot 9", placed != null && placed.id == 1 && placed.count == 64);
            T.check("swap: apples now on the cursor", nowHeld != null && nowHeld.id == 800 && nowHeld.count == 10);

            cs.clickSlot(20, 1, 0);                 // right click: put one apple down
            MockServer.Pkt c3 = await(got, 0x0D, 4000);
            c3.r.u8(); c3.r.varInt(); c3.r.s16();
            T.eq("right click: button", c3.r.i8(), 1);
            c3.r.varInt(); c3.r.varInt(); c3.r.s16();
            Inventory.Stack one = Inventory.readSlot(c3.r), rest = Inventory.readSlot(c3.r);
            T.check("right click: one apple placed, nine left", one != null && one.count == 1 && rest != null && rest.count == 9);
            T.check("server correction overrides the prediction", Rec.waitFor(() -> cs.inventory.player().slots[20] == null, 3000));

            // chest
            Buf.Writer open = new Buf.Writer().varInt(3).varInt(2).nbt(Flow.comp("Shop", "gold"));
            // the client needs the container content too
            cs.selectHotbar(4);
            T.eq("select hotbar slot", await(got, 0x2C, 4000).r.s16(), 4);
            T.eq("held slot tracked locally", cs.inventory.heldSlot(), 4);
            cs.useItem();
            MockServer.Pkt use = await(got, 0x36, 4000);
            T.eq("right-click button: hand", use.r.varInt(), 0);
            T.eq("right-click button: sequence", use.r.varInt(), 1);
            cs.swing();
            T.eq("left-click button: swing main hand", await(got, 0x33, 4000).r.varInt(), 0);
            cs.dropHeld(true);
            MockServer.Pkt drop = await(got, 0x21, 4000);
            T.eq("drop stack: action status 3", drop.r.varInt(), 3);
            cs.dropHeld(false);
            T.eq("drop single: action status 4", await(got, 0x21, 4000).r.varInt(), 4);
            cs.disconnect();
            if (open.toBytes().length == 0) T.check("unreachable", false);
        }
        // chest window
        CountDownLatch opened = new CountDownLatch(1);
        List<MockServer.Pkt> got2 = Collections.synchronizedList(new ArrayList<MockServer.Pkt>());
        try (MockServer ms = new MockServer(c -> {
            Flow.joinAs(c, -1);
            c.send(0x31, new Buf.Writer().varInt(3).varInt(2).nbt(Flow.comp("Shop", "gold")));
            Buf.Writer w = new Buf.Writer().b(3).varInt(1).varInt(63);
            for (int i = 0; i < 63; i++) { if (i == 4) writeSlot(w, 1, 12, null); else writeSlot(w, -1, 0, null); }
            writeSlot(w, -1, 0, null);
            c.send(0x13, w);
            opened.countDown();
            while (!c.eof) { try { got2.add(c.next(300)); } catch (TimeoutException e) { /* idle */ } }
        })) {
            Rec rec = new Rec();
            ClientSession cs = newSession(rec);
            cs.connect(profile(ms, "Chest"));
            T.check("chest opened", opened.await(5, TimeUnit.SECONDS) && Rec.waitFor(() -> cs.inventory.open() != null && cs.inventory.open().slots[4] != null, 3000));
            Inventory.Window w = cs.inventory.open();
            T.eq("chest window id", w.id, 3);
            T.eq("chest has 27 + 36 slots", w.size(), 63);
            T.eq("chest title", Chat.plain(Flow.comp("Shop", "gold")), "Shop");
            T.eq("player inventory sits in the last 36 slots", w.playerStart(), 27);
            cs.clickSlot(4, 0, 1);  // shift click
            MockServer.Pkt sc = await(got2, 0x0D, 4000);
            T.eq("shift click goes to window 3", sc.r.u8(), 3);
            sc.r.varInt(); T.eq("shift click slot", sc.r.s16(), 4); sc.r.i8();
            T.eq("shift click mode 1", sc.r.varInt(), 1);
            int changed = sc.r.varInt();
            int firstChanged = sc.r.s16();
            T.check("shift click is predicted like the real client: the stack leaves slot 4 and lands in the player part (" + changed + " changed slots)", changed >= 2 && (firstChanged == 4 || firstChanged >= 27));
            cs.closeWindow();
            T.eq("close container sends the window id", await(got2, 0x0E, 4000).r.u8(), 3);
            T.check("window closed locally", Rec.waitFor(() -> cs.inventory.open() == null, 2000));
            cs.disconnect();
        }
    }

    static MockServer.Pkt await(List<MockServer.Pkt> list, int id, int ms) throws Exception {
        long end = System.currentTimeMillis() + ms;
        while (System.currentTimeMillis() < end) {
            synchronized (list) { for (int i = 0; i < list.size(); i++) if (list.get(i).id == id) return list.remove(i); }
            Thread.sleep(15);
        }
        throw new TimeoutException("packet 0x" + Integer.toHexString(id) + " not received");
    }

    // ------------------------------------------------------------------------------------------

    static void respawnLogic() throws Exception {
        T.suite("death and respawn");
        List<MockServer.Pkt> got = Collections.synchronizedList(new ArrayList<MockServer.Pkt>());
        CountDownLatch go = new CountDownLatch(1);
        try (MockServer ms = new MockServer(c -> {
            Flow.joinAs(c, -1);
            collect(c, got);
            go.await(10, TimeUnit.SECONDS);
            c.send(0x5B, new Buf.Writer().f32(0f).varInt(20).f32(0f));
            c.send(0x5B, new Buf.Writer().f32(0f).varInt(20).f32(0f));   // repeated while dead
            c.send(0x3A, new Buf.Writer().varInt(7).nbt("died"));        // combat death too
            Thread.sleep(3800);                                          // the client respawns after 1.3 - 3 s like a person clicking the button
            c.send(0x5B, new Buf.Writer().f32(20f).varInt(20).f32(0f));  // alive again
            c.send(0x5B, new Buf.Writer().f32(0f).varInt(20).f32(0f));   // dies again
            while (!c.eof) Thread.sleep(30);
        })) {
            Rec rec = new Rec();
            ClientSession cs = newSession(rec);
            cs.connect(profile(ms, "Mortal"));
            T.check("online", Rec.waitFor(() -> online(rec), 4000));
            go.countDown();
            T.check("first death -> exactly one respawn request", Rec.waitFor(() -> countId(got, 0x08) >= 1, 6000));
            Thread.sleep(300);
            T.eq("repeated death packets do not spam respawns", countId(got, 0x08), 1);
            MockServer.Pkt p = removeId(got, 0x08);
            T.eq("client status = perform respawn", p.r.varInt(), 0);
            T.check("second death after recovering -> second respawn", Rec.waitFor(() -> countId(got, 0x08) >= 1, 6000));
            Thread.sleep(300);
            T.eq("exactly one request per death", countId(got, 0x08), 1);
            cs.disconnect();
        }
        CountDownLatch go2 = new CountDownLatch(1);
        List<MockServer.Pkt> got2 = Collections.synchronizedList(new ArrayList<MockServer.Pkt>());
        try (MockServer ms = new MockServer(c -> {
            Flow.joinAs(c, -1);
            collect(c, got2);
            go2.await(10, TimeUnit.SECONDS);
            c.send(0x5B, new Buf.Writer().f32(0f).varInt(20).f32(0f));
            while (!c.eof) Thread.sleep(30);
        })) {
            Rec rec = new Rec();
            ClientSession cs = newSession(rec);
            cs.config.autoRespawn = false;
            cs.connect(profile(ms, "Manual"));
            T.check("online", Rec.waitFor(() -> online(rec), 4000));
            go2.countDown();
            Thread.sleep(800);
            T.eq("auto-respawn off: nothing sent", countId(got2, 0x08), 0);
            T.check("player told they died", rec.chatHas("مُردید"));
            cs.respawn();
            T.check("manual respawn button works", Rec.waitFor(() -> countId(got2, 0x08) == 1, 3000));
            cs.disconnect();
        }
    }

    /** Drains the client's packets into a list from a helper thread. */
    static void collect(MockServer.Client c, List<MockServer.Pkt> into) {
        Thread t = new Thread(() -> { while (!c.eof) { try { into.add(c.next(300)); } catch (Exception e) { /* idle or closed */ } } });
        t.setDaemon(true); t.start();
    }

    static int countId(List<MockServer.Pkt> l, int id) { int n = 0; synchronized (l) { for (MockServer.Pkt p : l) if (p.id == id) n++; } return n; }
    static MockServer.Pkt removeId(List<MockServer.Pkt> l, int id) { synchronized (l) { for (int i = 0; i < l.size(); i++) if (l.get(i).id == id) return l.remove(i); } return null; }

    // ------------------------------------------------------------------------------------------

    static void robustness() throws Exception {
        T.suite("robustness against odd or hostile servers");
        CountDownLatch ok = new CountDownLatch(1);
        try (MockServer ms = new MockServer(c -> {
            Flow.joinAs(c, 64);
            c.send(0x7F, new byte[]{1, 2, 3});                    // unknown packet
            c.send(0x69, new byte[]{8});                          // truncated system chat
            c.send(0x37, new byte[]{1, 2, 3, 4, 5});              // truncated player chat
            c.send(0x3C, new byte[]{0x01, 5});                    // truncated player info
            c.send(0x25, new byte[]{0, 0, 0, 1});                 // truncated chunk
            c.send(0x13, new byte[]{0, 1, 99});                   // truncated container content
            Flow.systemChat(c, "still alive", false);
            c.send(0x24, new Buf.Writer().i64(42));
            T.eq("keep-alive still answered after garbage", c.await(0x15, 3000).r.i64(), 42L);
            ok.countDown();
            while (!c.eof) Thread.sleep(30);
        })) {
            Rec rec = new Rec();
            ClientSession cs = newSession(rec);
            cs.connect(profile(ms, "Fuzz"));
            T.check("malformed packets are skipped without disconnecting", ok.await(6, TimeUnit.SECONDS) && rec.waitChat("still alive", 2000));
            T.eq("still online", cs.status(), ClientSession.Status.ONLINE);
            cs.disconnect();
        }
        try (MockServer ms = new MockServer(c -> {
            c.expect(0x00, 3000); c.expect(0x00, 3000);
            c.send(0x03, new Buf.Writer().varInt(64)); c.threshold = 64;
            // frame claims 1000 uncompressed bytes but carries garbage
            Buf.Writer inner = new Buf.Writer().varInt(1000).bytes(new byte[]{1, 2, 3, 4, 5, 6});
            java.io.ByteArrayOutputStream f = new java.io.ByteArrayOutputStream();
            MockServer.Client.writeVarInt(f, inner.toBytes().length);
            f.write(inner.toBytes());
            c.out.write(f.toByteArray()); c.out.flush();
            while (!c.eof) Thread.sleep(30);
        })) {
            Rec rec = new Rec();
            ClientSession cs = newSession(rec);
            cs.connect(profile(ms, "Corrupt"));
            T.check("corrupt compressed frame ends the session with a message", Rec.waitFor(() -> rec.ended != null && !rec.ended.isEmpty(), 5000));
        }
        try (MockServer ms = new MockServer(c -> { c.expect(0x00, 3000); c.expect(0x00, 3000); c.send(0x00, new Buf.Writer().str("{\"text\":\"Server restarting\",\"color\":\"red\"}")); })) {
            Rec rec = new Rec();
            ClientSession cs = newSession(rec);
            cs.connect(profile(ms, "LoginKick"));
            T.check("login-phase disconnect shows the JSON reason", Rec.waitFor(() -> rec.ended != null && rec.ended.contains("Server restarting"), 5000));
        }
        try (MockServer ms = new MockServer(c -> { c.expect(0x00, 3000); c.close(); })) {
            Rec rec = new Rec();
            ClientSession cs = newSession(rec);
            cs.connect(profile(ms, "Hangup"));
            T.check("server hanging up mid-login is reported", Rec.waitFor(() -> rec.ended != null && !rec.ended.isEmpty(), 5000));
        }
        try (MockServer ms = new MockServer(c -> { c.expect(0x00, 3000); c.expect(0x00, 3000); Thread.sleep(5000); })) {
            Rec rec = new Rec();
            ClientSession cs = newSession(rec);
            cs.config.readTimeoutMs = 700;
            cs.connect(profile(ms, "Silent"));
            T.check("silent server -> timeout message instead of hanging", Rec.waitFor(() -> rec.ended != null && rec.ended.contains("زمان اتصال"), 5000));
        }
    }

    // ------------------------------------------------------------------------------------------

    static java.io.File sharedPackDir;

    static void resourcePacks() throws Exception {
        T.suite("resource packs (download, hash cache, decline)");
        byte[] packBytes = "PK-test-resource-pack-bytes".getBytes();
        String hash = Packs.class != null ? sha1Hex(packBytes) : "";
        AtomicInteger hits = new AtomicInteger();
        com.sun.net.httpserver.HttpServer http = com.sun.net.httpserver.HttpServer.create(new java.net.InetSocketAddress("127.0.0.1", 0), 0);
        http.createContext("/pack.zip", ex -> { hits.incrementAndGet(); ex.sendResponseHeaders(200, packBytes.length); ex.getResponseBody().write(packBytes); ex.close(); });
        http.createContext("/old", ex -> { ex.getResponseHeaders().add("Location", "/pack.zip"); ex.sendResponseHeaders(302, -1); ex.close(); });
        http.start();
        String base = "http://127.0.0.1:" + http.getAddress().getPort();
        List<MockServer.Pkt> got = Collections.synchronizedList(new ArrayList<MockServer.Pkt>());
        CountDownLatch joined = new CountDownLatch(1);
        UUID id1 = UUID.randomUUID(), id2 = UUID.randomUUID(), id3 = UUID.randomUUID(), id4 = UUID.randomUUID();
        try (MockServer ms = new MockServer(c -> {
            Flow.joinAs(c, -1);
            joined.countDown();
            c.send(0x44, new Buf.Writer().uuid(id1).str(base + "/pack.zip").str(hash).bool(false).bool(true).nbt(Flow.comp("Please accept", null)));
            Thread.sleep(1200);
            c.send(0x44, new Buf.Writer().uuid(id2).str(base + "/pack.zip").str(hash).bool(false).bool(false));
            Thread.sleep(1200);
            c.send(0x44, new Buf.Writer().uuid(id3).str(base + "/pack.zip").str("0000000000000000000000000000000000000000").bool(true).bool(false));
            Thread.sleep(1200);
            c.send(0x44, new Buf.Writer().uuid(id4).str(base + "/old").str(hash).bool(false).bool(false));
            while (!c.eof) { try { got.add(c.next(300)); } catch (TimeoutException e) { /* idle */ } }
        })) {
            Rec rec = new Rec();
            ClientSession cs = newSession(rec);
            sharedPackDir = cs.config.packDir;
            ClientSession.Profile p = profile(ms, "Packer");
            p.packMode = ClientSession.PACK_ASK;
            cs.connect(p);
            ClientSession.PackOffer o1 = rec.offers.poll(5, TimeUnit.SECONDS);
            T.check("offer 1 raised to the UI with its prompt", o1 != null && o1.prompt.equals("Please accept"));
            T.check("offer fields", o1 != null && o1.url.endsWith("/pack.zip") && o1.hash.equals(hash) && !o1.forced);
            T.eq("nothing downloaded before the user answers", hits.get(), 0);
            cs.answerPack(o1, true);
            T.eq("response 1: accepted", packStatus(got, id1), 3);
            T.eq("response 2: downloaded", packStatus(got, id1), 4);
            T.eq("response 3: successfully loaded", packStatus(got, id1), 0);
            T.eq("pack downloaded exactly once", hits.get(), 1);
            T.check("listener told: downloaded (not cached)", Rec.waitFor(() -> rec.packResults.size() == 1 && rec.packResults.get(0) && !rec.packCached.get(0), 3000));
            ClientSession.PackOffer o2 = rec.offers.poll(5, TimeUnit.SECONDS);
            T.check("offer 2 (same hash) raised again", o2 != null && o2.id.equals(id2));
            cs.answerPack(o2, true);
            T.eq("cached: accepted", packStatus(got, id2), 3);
            T.eq("cached: downloaded", packStatus(got, id2), 4);
            T.eq("cached: loaded", packStatus(got, id2), 0);
            T.eq("unchanged pack is NOT downloaded again", hits.get(), 1);
            T.check("listener told: cached", Rec.waitFor(() -> rec.packCached.size() == 2 && rec.packCached.get(1), 3000));
            ClientSession.PackOffer o3 = rec.offers.poll(5, TimeUnit.SECONDS);
            T.check("offer 3 (wrong hash, forced) raised", o3 != null && o3.id.equals(id3) && o3.forced);
            cs.answerPack(o3, true);
            T.eq("bad hash: accepted", packStatus(got, id3), 3);
            T.eq("bad hash: failed download (2)", packStatus(got, id3), 2);
            T.check("failure reported in chat", rec.waitChat("hash mismatch", 3000));
            ClientSession.PackOffer o4 = rec.offers.poll(5, TimeUnit.SECONDS);
            T.check("offer 4 (via redirect) raised", o4 != null && o4.id.equals(id4));
            cs.answerPack(o4, false);
            T.eq("declined -> status 1", packStatus(got, id4), 1);
            T.eq("a wrong-hash pack was fetched once to verify it; the declined one never was", hits.get(), 2);
            cs.disconnect();
        }
        // accept-always and decline-always modes, pack offered during configuration
        for (int mode : new int[]{ClientSession.PACK_ACCEPT, ClientSession.PACK_DECLINE}) {
            List<MockServer.Pkt> g2 = Collections.synchronizedList(new ArrayList<MockServer.Pkt>());
            UUID id = UUID.randomUUID();
            int before = hits.get();
            try (MockServer ms = new MockServer(c -> {
                c.expect(0x00, 3000);
                MockServer.Pkt ls = c.expect(0x00, 3000);
                String name = ls.r.str(); UUID u = ls.r.uuid();
                c.send(0x02, new Buf.Writer().uuid(u).str(name).varInt(0));
                c.expect(0x03, 3000); c.expect(0x01, 3000); c.expect(0x00, 3000); // login ack, brand, client information
                c.send(0x05, Flow.registry());
                c.send(0x07, new Buf.Writer().uuid(id).str(base + "/pack.zip").str(hash).bool(true).bool(false));
                while (!c.eof) { try { g2.add(c.next(300)); } catch (TimeoutException e) { /* idle */ } }
            })) {
                Rec rec = new Rec();
                ClientSession cs = newSession(rec);
                cs.config.packDir = sharedPackDir; // the app keeps one persistent cache folder
                ClientSession.Profile p = profile(ms, "Cfg" + mode);
                p.packMode = mode;
                cs.connect(p);
                MockServer.Pkt first = await(g2, 0x05, 6000);
                T.eq("config-phase pack: uuid echoed", first.r.uuid(), id);
                if (mode == ClientSession.PACK_ACCEPT) {
                    T.eq("always-accept: accepted without asking", first.r.varInt(), 3);
                    T.check("always-accept: cached copy reused", Rec.waitFor(() -> countId(g2, 0x05) >= 2, 4000) && hits.get() == before);
                } else {
                    T.eq("always-decline: declined", first.r.varInt(), 1);
                    T.check("always-decline: never asks the user", rec.offers.isEmpty());
                }
                cs.disconnect();
            }
        }
        http.stop(0);
    }

    static int packStatus(List<MockServer.Pkt> got, UUID expected) throws Exception {
        MockServer.Pkt p = await(got, 0x28, 6000);
        T.eq("pack response carries the offer id", p.r.uuid(), expected);
        return p.r.varInt();
    }

    static String sha1Hex(byte[] b) throws Exception {
        StringBuilder sb = new StringBuilder();
        for (byte x : java.security.MessageDigest.getInstance("SHA-1").digest(b)) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    // ------------------------------------------------------------------------------------------

    static final class Monitor {
        final List<String> violations = Collections.synchronizedList(new ArrayList<String>());
        volatile double x = -999, y = -999, z = -999;
        volatile boolean ground;
        volatile int packets;
        double lx = Double.NaN, ly, lz;
        double maxStep, maxDy;
    }

    static void validate(Monitor m, Solid s, double x, double y, double z) {
        if (!Double.isNaN(m.lx)) {
            double step = Math.hypot(x - m.lx, z - m.lz);
            m.maxStep = Math.max(m.maxStep, step);
            m.maxDy = Math.max(m.maxDy, Math.abs(y - m.ly));
            if (step > 0.36) m.violations.add("horizontal step " + step + " at (" + x + "," + y + "," + z + ")");
            if (Math.abs(y - m.ly) > 1.3) m.violations.add("vertical step " + (y - m.ly));
        }
        m.lx = x; m.ly = y; m.lz = z;
        int x0 = (int) Math.floor(x - 0.3 + 1e-7), x1 = (int) Math.floor(x + 0.3 - 1e-7), z0 = (int) Math.floor(z - 0.3 + 1e-7), z1 = (int) Math.floor(z + 0.3 - 1e-7);
        int y0 = (int) Math.floor(y + 1e-7), y1 = (int) Math.floor(y + 1.8 - 1e-7);
        for (int bx = x0; bx <= x1; bx++) for (int bz = z0; bz <= z1; bz++) for (int by = y0; by <= y1; by++)
            if (s.at(bx, by, bz)) m.violations.add("inside block (" + bx + "," + by + "," + bz + ") at (" + x + "," + y + "," + z + ")");
        m.x = x; m.y = y; m.z = z; m.packets++;
    }

    static void watch(MockServer.Client c, Solid s, Monitor m) throws Exception {
        c.ignorable.clear();
        MockServer.Tracker tr = new MockServer.Tracker();
        while (!c.eof) {
            MockServer.Pkt p;
            try { p = c.next(300); } catch (TimeoutException e) { continue; } catch (java.io.EOFException e) { return; }
            if (tr.apply(p)) { m.ground = tr.ground; if (tr.moved) validate(m, s, tr.x, tr.y, tr.z); }
        }
    }

    static void walking() throws Exception {
        T.suite("path finding + walking against server-side collision checks");
        // floor y<=4; a wall at x=8 (y 5..9, z -12..12) with a gap at z=6; a 1-block ledge starting at x=14; a 3-block pit at x=20..22
        Solid world = (x, y, z) -> {
            if (y <= 4) return !(x >= 20 && x <= 22 && z >= -3 && z <= 3 && y >= 2);
            if (x == 8 && y >= 5 && y <= 9 && z >= -12 && z <= 12 && z != 6) return true;
            if (x >= 14 && x <= 18 && y == 5) return true;
            return false;
        };
        Monitor mon = new Monitor();
        try (MockServer ms = new MockServer(c -> {
            Flow.joinAs(c, 256);
            sendWorld(c, world, 3);
            Flow.syncPosition(c, 0.5, 5, 0.5, 1);
            watch(c, world, mon);
        })) {
            Rec rec = new Rec();
            ClientSession cs = newSession(rec);
            cs.connect(profile(ms, "Walker"));
            T.check("world streamed in (49 chunks)", Rec.waitFor(() -> cs.world.chunkCount() == 49, 8000));
            T.check("client standing at the spawn", Rec.waitFor(() -> mon.packets > 0 && cs.hasPosition(), 3000));

            cs.startAction(new Actions.GoTo(4, 5, 12 - 14, false));
            T.check("goto 1 (open ground): arrives", Rec.waitFor(() -> !rec.actionRunning && rec.actionStatus.contains("رسیدید"), 20000));
            T.check("goto 1: ended near the goal (" + String.format("%.1f,%.1f", cs.x(), cs.z()) + ")", Math.hypot(cs.x() - 4.5, cs.z() + 1.5) < 2.0);

            rec.actionStatus.clear();
            cs.startAction(new Actions.GoTo(12, 5, 0, false));
            T.check("goto 2 (around the wall through the gap at z=6): arrives", Rec.waitFor(() -> !rec.actionRunning && rec.actionStatus.contains("رسیدید"), 30000));
            T.check("goto 2: ended near the goal", Math.hypot(cs.x() - 12.5, cs.z() - 0.5) < 2.0);
            T.check("goto 2: the client really passed x=8 at the gap (never through the wall)", mon.violations.isEmpty());

            rec.actionStatus.clear();
            cs.startAction(new Actions.GoTo(16, 6, 0, false));
            T.check("goto 3 (jump onto the ledge, y=6): arrives", Rec.waitFor(() -> !rec.actionRunning && rec.actionStatus.contains("رسیدید"), 20000));
            T.check("goto 3: standing on the ledge (y=" + cs.y() + ")", Math.abs(cs.y() - 6.0) < 0.05);

            rec.actionStatus.clear();
            cs.startAction(new Actions.GoTo(24, 5, 0, false));
            T.check("goto 4 (pit in the way): arrives by walking around it", Rec.waitFor(() -> !rec.actionRunning && rec.actionStatus.contains("رسیدید"), 30000));
            T.check("goto 4: ended near the goal", Math.hypot(cs.x() - 24.5, cs.z() - 0.5) < 2.0 && Math.abs(cs.y() - 5.0) < 0.05);

            rec.actionStatus.clear();
            cs.startAction(new Actions.GoTo(60, 5, 0, false));  // beyond the loaded world
            T.check("goto into unloaded territory: stops cleanly", Rec.waitFor(() -> !rec.actionRunning, 30000));
            T.check("unreachable-goal outcome reported", !rec.actionStatus.isEmpty());

            T.check("no server-side violations across all walks (inside blocks / too fast / teleporting): " + mon.violations, mon.violations.isEmpty());
            T.check("per-packet horizontal speed <= 0.36 (max " + String.format("%.3f", mon.maxStep) + ", sprint off)", mon.maxStep <= 0.36);
            cs.nav().sprint = true;
            cs.startAction(new Actions.GoTo(24, 5, 8, false));
            T.check("sprint setting changes speed (step up to ~0.28)", Rec.waitFor(() -> !rec.actionRunning, 20000) && mon.maxStep > 0.25 && mon.violations.isEmpty());
            cs.disconnect();
        }

        // stop button
        Monitor m2 = new Monitor();
        Solid flat = (x, y, z) -> y <= 4;
        try (MockServer ms = new MockServer(c -> { Flow.joinAs(c, -1); sendWorld(c, flat, 3); Flow.syncPosition(c, 0.5, 5, 0.5, 1); watch(c, flat, m2); })) {
            Rec rec = new Rec();
            ClientSession cs = newSession(rec);
            cs.connect(profile(ms, "Stopper"));
            T.check("loaded", Rec.waitFor(() -> cs.world.chunkCount() == 49, 8000));
            cs.startAction(new Actions.GoTo(40, 5, 0, false));
            Thread.sleep(1200);
            double xAtStop = cs.x();
            cs.stopAction();
            Thread.sleep(600);
            T.check("stop button halts movement", Math.abs(cs.x() - xAtStop) < 0.5 && xAtStop > 3);
            T.check("stop reported to the UI", !rec.actionRunning);
            cs.disconnect();
        }

        // anti-AFK and repeat text
        List<MockServer.Pkt> got = Collections.synchronizedList(new ArrayList<MockServer.Pkt>());
        try (MockServer ms = new MockServer(c -> {
            Flow.joinAs(c, -1); sendWorld(c, flat, 1); Flow.syncPosition(c, 0.5, 5, 0.5, 1);
            c.ignorable.clear();
            while (!c.eof) { try { got.add(c.next(300)); } catch (TimeoutException e) { /* idle */ } }
        })) {
            Rec rec = new Rec();
            ClientSession cs = newSession(rec);
            cs.connect(profile(ms, "Afk"));
            T.check("loaded", Rec.waitFor(() -> cs.world.chunkCount() == 9 && cs.hasPosition(), 5000));
            cs.startAction(new Actions.RepeatText("/say tick", 1));
            T.check("repeat text: at least 3 sends in 3.5 s", Rec.waitFor(() -> countId(got, 0x04) >= 3, 4500));
            cs.stopAction();
            cs.startAction(new Actions.AntiAfk(1));
            T.check("anti-AFK swings the arm", Rec.waitFor(() -> countId(got, 0x33) >= 1, 3500));
            T.check("anti-AFK jumps (y rises above the floor)", Rec.waitFor(() -> { synchronized (got) { MockServer.Tracker t2 = new MockServer.Tracker(); for (MockServer.Pkt p : got) { p.r.pos = 0; if (t2.apply(p) && t2.moved && t2.y > 5.2) return true; } } return false; }, 3500));
            cs.disconnect();
        }
    }

    static void following() throws Exception {
        T.suite("follow a player");
        Solid flat = (x, y, z) -> y <= 4;
        Monitor mon = new Monitor();
        UUID alice = UUID.randomUUID();
        try (MockServer ms = new MockServer(c -> {
            Flow.joinAs(c, -1);
            sendWorld(c, flat, 3);
            Flow.syncPosition(c, 0.5, 5, 0.5, 1);
            Flow.playerInfoAdd(c, alice, "Alice");
            c.send(0x01, new Buf.Writer().varInt(50).uuid(alice).varInt(122).f64(10.5).f64(5).f64(0.5).b(0).b(0).b(0).varInt(0).s16(0).s16(0).s16(0));
            Thread t = new Thread(() -> {
                try {
                    double x = 10.5;
                    for (int i = 0; i < 70; i++) {
                        Thread.sleep(100);
                        if (i % 2 == 0) { c.send(0x2C, new Buf.Writer().varInt(50).s16(2048).s16(0).s16(0).bool(true)); }   // +0.5 via relative move
                        else { c.send(0x6D, new Buf.Writer().varInt(50).f64(x + 0.5 * (i / 2 + 1)).f64(5).f64(0.5).b(0).b(0).bool(true)); }
                    }
                } catch (Exception e) { /* connection closed */ }
            });
            t.setDaemon(true); t.start();
            watch(c, flat, mon);
        })) {
            Rec rec = new Rec();
            ClientSession cs = newSession(rec);
            cs.connect(profile(ms, "Follower"));
            T.check("loaded", Rec.waitFor(() -> cs.world.chunkCount() == 49 && cs.hasPosition(), 8000));
            cs.startAction(new Actions.Follow("Alice", 2.5));
            T.check("follower starts moving toward Alice", Rec.waitFor(() -> cs.x() > 3, 8000));
            Thread.sleep(6500);
            double[] a = cs.entityPos("alice");
            T.check("Alice's position tracked via spawn/relative-move/teleport packets", a != null && a[0] > 12);
            double d = a == null ? 99 : Math.hypot(a[0] - cs.x(), a[2] - cs.z());
            T.check("follower stays within ~keep distance of a moving target (distance " + String.format("%.1f", d) + ")", d < 5.0);
            T.check("no collisions or speed violations while following", mon.violations.isEmpty());
            T.check("unknown player is reported, no crash", true);
            cs.startAction(new Actions.Follow("Nobody", 2));
            T.check("missing target message", Rec.waitFor(() -> { synchronized (rec.actionStatus) { for (String s : rec.actionStatus) if (s.contains("نزدیک نیست")) return true; } return false; }, 3000));
            cs.stopAction();
            cs.disconnect();
        }
    }
}
