import com.mcclient.core.*;
import java.awt.*;
import java.awt.font.FontRenderContext;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.*;
import java.util.List;
import javax.imageio.ImageIO;

/**
 * Renders the layout with Java2D (DejaVu fonts stand in for Minecraft's bitmap font) to a PNG so the
 * Persian/English ordering can be inspected visually. Persian runs use the same "draw without anti-aliasing at a
 * small size, then scale with nearest-neighbour" trick as the Android renderer.
 */
public final class RenderTest {
    static final int SCALE = 4;

    static boolean hasNonAscii(String t) { for (int i = 0; i < t.length(); i++) if (t.charAt(i) > 0x7E) return true; return false; }

    static void run(String outFile) throws Exception {
        System.setProperty("java.awt.headless", "true");
        T.suite("render to PNG (visual check)");
        final Font latin = new Font("DejaVu Sans Mono", Font.PLAIN, 9);
        final Font arabic = new Font("DejaVu Sans", Font.PLAIN, 10);
        final FontRenderContext frc = new FontRenderContext(null, false, false);
        TextLayout.Metrics m = new TextLayout.Metrics() {
            @Override public int width(String t, TextLayout.Type type, boolean bold) {
                boolean pixel = type == TextLayout.Type.AR || type == TextLayout.Type.EXT || hasNonAscii(t);
                if (!pixel) return (int) Math.ceil(latin.getStringBounds(t, frc).getWidth()) + (bold ? t.length() : 0);
                // shaped advance, like Paint.measureText on Android
                return (int) Math.ceil(new java.awt.font.TextLayout(t, arabic, frc).getAdvance()) + 1;
            }
            @Override public int charWidth(TextLayout.Seg s, char ch) { return (int) Math.ceil(latin.getStringBounds(String.valueOf(ch), frc).getWidth()); }
        };
        String[] msgs = {
            "<Steve> Hello everyone!",
            "<Ali> \u00A7bسلام دوستان، امروز هوا خیلی خوبه",
            "\u00A7aسلام \u00A7fSteve\u00A77: \u00A7fHello دنیا 123 ماینکرافت ۱۲۳",
            "امروز ۱۴۰۳/۰۷/۲۴ ساعت ۱۴:۳۰ — قیمت ۱۲٫۵٪ تخفیف و 50% off",
            "\u00A76[VIP] \u00A7fReza\u00A77 » \u00A7fآدرس سرور play.example.com:25565 است",
            "سلام! نام من \u00A7eAlex\u00A7f است و ۱۰ الماس دارم (diamonds x10)",
            "\u00A7cخطا: \u00A7fدستور /home پیدا نشد. از /sethome استفاده کنید",
            "این یک پیام خیلی طولانی فارسی است که باید در چند خط شکسته شود و همچنان درست و راست‌چین نمایش داده شود، همراه با English words inside it.",
            "A very long English message that should wrap around nicely, mixed with فارسی in the middle and ending with numbers 2024/10/24 14:30",
        };
        int widthGp = 170;
        List<TextLayout.Layout> layouts = new ArrayList<>();
        int heightGp = 4;
        for (String s : msgs) { TextLayout.Layout l = TextLayout.build(Chat.legacy(s), widthGp, m); layouts.add(l); heightGp += l.heightGp + 1; }
        BufferedImage small = new BufferedImage(widthGp, heightGp, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = small.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
        g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
        g.setColor(new Color(0x14, 0x18, 0x16));
        g.fillRect(0, 0, widthGp, heightGp);
        int y = 2;
        boolean allDrawn = true;
        for (TextLayout.Layout l : layouts) {
            g.setColor(new Color(0, 0, 0, 110));
            g.fillRect(0, y, widthGp, l.heightGp);
            for (int li = 0; li < l.lines.size(); li++) {
                int base = y + 1 + li * TextLayout.LINE_H + TextLayout.BASE;
                for (TextLayout.Seg s : l.lines.get(li)) {
                    if (s.type == TextLayout.Type.SPACE) continue;
                    Font f = TextLayout.needsPixelFont(s) ? arabic : latin;
                    g.setFont(f);
                    Color c = new Color(s.span.color);
                    g.setColor(new Color(c.getRed() / 4, c.getGreen() / 4, c.getBlue() / 4));
                    g.drawString(s.text, s.x + 1, base + 1);
                    g.setColor(c);
                    g.drawString(s.text, s.x, base);
                    if (s.x < 0 || s.x + s.width > widthGp + 2) allDrawn = false;
                }
            }
            y += l.heightGp + 1;
        }
        g.dispose();
        BufferedImage big = new BufferedImage(widthGp * SCALE, heightGp * SCALE, BufferedImage.TYPE_INT_RGB);
        Graphics2D bg = big.createGraphics();
        bg.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
        bg.drawImage(small, 0, 0, widthGp * SCALE, heightGp * SCALE, null);
        bg.dispose();
        new File(outFile).getParentFile().mkdirs();
        ImageIO.write(big, "png", new File(outFile));
        T.check("every segment lies inside the chat width", allDrawn);
        T.check("PNG written (" + big.getWidth() + "x" + big.getHeight() + ") -> " + outFile, new File(outFile).length() > 2000);
    }
}
