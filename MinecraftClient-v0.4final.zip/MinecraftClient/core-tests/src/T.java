import java.util.ArrayList;
import java.util.List;

/** Tiny test harness: counts checks, prints failures, exits non-zero when anything failed. */
public final class T {
    static int pass, fail;
    static final List<String> failures = new ArrayList<>();
    static String suite = "";

    synchronized static void suite(String s) { suite = s; System.out.println("== " + s); }
    synchronized static void check(String name, boolean ok) {
        if (ok) { pass++; System.out.println("  PASS " + name); }
        else { fail++; failures.add(suite + " / " + name); System.out.println("  FAIL " + name); }
    }
    synchronized static void eq(String name, Object a, Object b) {
        boolean ok = a == null ? b == null : a.equals(b);
        if (!ok) System.out.println("     expected: " + b + "\n     actual:   " + a);
        check(name, ok);
    }
    static void done() {
        System.out.println("\nRESULT: " + pass + " passed, " + fail + " failed");
        for (String f : failures) System.out.println("  FAILED: " + f);
        System.exit(fail == 0 ? 0 : 1);
    }
}
