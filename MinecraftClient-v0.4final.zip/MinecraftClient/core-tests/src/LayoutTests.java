import com.mcclient.core.*;
import java.util.*;

/** Tests of the bidi/wrapping text layout with fixed-width fake metrics. */
public final class LayoutTests {
    static final TextLayout.Metrics M = new TextLayout.Metrics() {
        @Override public int width(String t, TextLayout.Type type, boolean bold) {
            int per = type == TextLayout.Type.AR ? 5 : type == TextLayout.Type.EXT ? 8 : 6;
            return t.length() * per + (bold ? t.length() : 0);
        }
        @Override public int charWidth(TextLayout.Seg s, char ch) { return s.type == TextLayout.Type.AR ? 5 : 6; }
    };

    static String visual(TextLayout.Layout l, int line) {
        StringBuilder sb = new StringBuilder();
        for (TextLayout.Seg s : l.lines.get(line)) { if (sb.length() > 0) sb.append('|'); sb.append(s.text.equals(" ") ? "_" : s.text); }
        return sb.toString();
    }

    static TextLayout.Layout lay(String legacy, int w) { return TextLayout.build(Chat.legacy(legacy), w, M); }

    static void run() {
        T.suite("text layout: mixed Persian / English");
        TextLayout.Layout l = lay("Hello world", 200);
        T.eq("English only keeps order", visual(l, 0), "Hello|_|world");
        T.check("English is left aligned", l.lines.get(0).get(0).x == 0 && !l.rtl);

        l = lay("سلام دنیا خوبی", 200);
        T.eq("Persian only: words run right-to-left", visual(l, 0), "خوبی|_|دنیا|_|سلام");
        List<TextLayout.Seg> line = l.lines.get(0);
        T.check("Persian block is right aligned", l.rtl && line.get(line.size() - 1).x + line.get(line.size() - 1).width == 200);

        l = lay("<Ali> سلام دنیا", 200);
        T.eq("chat line '<Ali> persian': English first, Persian words reversed", visual(l, 0), "<Ali>|_|دنیا|_|سلام");

        l = lay("سلام Steve چطوری", 200);
        T.eq("Persian around an English name: name stays readable in the middle", visual(l, 0), "چطوری|_|Steve|_|سلام");

        l = lay("سلام 123 دنیا", 200);
        T.eq("digits stay left-to-right inside Persian", visual(l, 0), "دنیا|_|123|_|سلام");

        l = lay("Hi سلام دنیا Bye", 200);
        T.eq("Persian island inside an English sentence", visual(l, 0), "Hi|_|دنیا|_|سلام|_|Bye");

        l = lay("قیمت 3.5 تومان", 200);
        T.eq("decimal number stays one unit", visual(l, 0), "تومان|_|3.5|_|قیمت");

        l = lay("سال ۱۴۰۳/۰۷/۲۴ بود", 200);
        T.eq("Persian date stays one left-to-right unit", visual(l, 0), "بود|_|۱۴۰۳/۰۷/۲۴|_|سال");
        l = lay("سال۱۴۰۳", 200);
        T.eq("digits glued to a Persian word go to its left", visual(l, 0), "۱۴۰۳|سال");
        l = lay("۱۲٫۵٪ تخفیف", 200);
        T.eq("Persian decimal separator and percent sign stay in the number", visual(l, 0), "تخفیف|_|۱۲٫۵٪");
        l = lay("Price: ۱۲۳ and 456", 200);
        T.check("Persian digits use the pixel font, ASCII digits the bitmap font",
            TextLayout.needsPixelFont(l.lines.get(0).get(2)) && !TextLayout.needsPixelFont(l.lines.get(0).get(l.lines.get(0).size() - 1)));

        l = lay("می\u200Cخواهم", 200);
        T.eq("ZWNJ keeps the word in one run", l.lines.get(0).size(), 1);

        l = lay("caf\u00E9 \u2605 ok", 200);
        T.check("non-ASCII glyphs ('é', '★') are laid out left-to-right", visual(l, 0).startsWith("caf") && l.lines.get(0).get(0).x == 0);

        l = lay("\u00A7aسلام \u00A7fSteve", 200);
        T.eq("styled spans reorder together with their colours", visual(l, 0), "Steve|_|سلام");
        TextLayout.Seg steve = l.lines.get(0).get(0), salam = l.lines.get(0).get(2);
        T.check("colours stay attached (white Steve, green salam)", steve.span.color == Chat.WHITE && salam.span.color == Chat.LEGACY[10]);

        // wrapping
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 30; i++) sb.append("word").append(i).append(' ');
        l = lay(sb.toString().trim(), 60);
        boolean fits = true; StringBuilder all = new StringBuilder();
        for (List<TextLayout.Seg> ln : l.lines) {
            int w = 0; for (TextLayout.Seg s : ln) { w += s.width; all.append(s.text); } if (w > 60) fits = false; all.append(' ');
        }
        T.check("wrapped lines never exceed the width (" + l.lines.size() + " lines)", fits && l.lines.size() > 5);
        T.eq("wrapping loses no words", all.toString().replaceAll("\\s+", " ").trim(), sb.toString().trim());

        l = lay("x" + "abcdefghij".repeat(4), 100);
        fits = true; StringBuilder joined = new StringBuilder();
        for (List<TextLayout.Seg> ln : l.lines) { int w = 0; for (TextLayout.Seg s : ln) { w += s.width; joined.append(s.text); } if (w > 100) fits = false; }
        T.check("an over-long word is broken to fit", fits && l.lines.size() >= 3);
        T.eq("broken word keeps all characters", joined.toString(), "x" + "abcdefghij".repeat(4));

        l = lay("line one\nسطر دوم\n\nlast", 200);
        T.eq("newlines create lines (including an empty one)", l.lines.size(), 4);
        T.eq("each Persian line is ordered on its own", visual(l, 1), "دوم|_|سطر");

        l = lay("سلام ".repeat(12).trim(), 60);
        fits = true;
        for (List<TextLayout.Seg> ln : l.lines) { int w = 0; for (TextLayout.Seg s : ln) w += s.width; if (w > 60) fits = false; }
        T.check("Persian paragraphs wrap and stay right aligned", fits && l.lines.size() > 3 && l.rtl);
        for (List<TextLayout.Seg> ln : l.lines) {
            TextLayout.Seg last = ln.get(ln.size() - 1);
            if (last.x + last.width != 60) { T.check("every wrapped Persian line ends at the right edge", false); break; }
        }

        l = TextLayout.build(new ArrayList<Chat.Span>(), 100, M);
        T.eq("empty message -> one empty line", l.lines.size(), 1);
        l = lay("     ", 100);
        T.check("only spaces -> no crash", l.lines.size() == 1 && l.lines.get(0).isEmpty());
        TextLayout.Layout a = lay("سلام Steve 12", 100), b = lay("سلام Steve 12", 100);
        T.eq("layout is deterministic", visual(a, 0), visual(b, 0));
        T.check("height grows with lines", lay("a\nb\nc", 100).heightGp == 3 * TextLayout.LINE_H + 2);

        // a full-size message: 2000 characters of mixed text must lay out quickly
        StringBuilder big = new StringBuilder();
        for (int i = 0; i < 250; i++) big.append("سلام Steve ").append(i).append(' ');
        long t0 = System.nanoTime();
        TextLayout.Layout bl = lay(big.toString(), 220);
        long ms = (System.nanoTime() - t0) / 1_000_000;
        T.check("2750-character mixed message lays out in < 300 ms (took " + ms + " ms, " + bl.lines.size() + " lines)", ms < 300);
    }
}
