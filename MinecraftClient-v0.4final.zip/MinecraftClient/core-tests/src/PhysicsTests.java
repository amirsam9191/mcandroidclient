import com.mcclient.core.*;
import java.util.*;

/** Real player physics (1.20.4): reference values from the task plus behaviour checks for every block/fluid rule. */
public final class PhysicsTests {
    static final int AIR = 0, STONE = 1, ICE = 2, BLUE_ICE = 3, SLIME = 4, SOUL_SAND = 5, HONEY = 6, COBWEB = 7, WATER = 8, LAVA = 24, LADDER = 40, SLAB = 44;

    static String row(int id, String name, int min, int max, String bbox, String states) {
        return "{\"id\":" + id + ",\"name\":\"" + name + "\",\"minStateId\":" + min + ",\"maxStateId\":" + max + ",\"boundingBox\":\"" + bbox + "\",\"hardness\":1" + (states == null ? "" : ",\"states\":[" + states + "]") + "}";
    }
    static final String REGISTRY = "[" + String.join(",",
        row(0, "air", 0, 0, "empty", null), row(1, "stone", 1, 1, "block", null), row(2, "ice", 2, 2, "block", null),
        row(3, "blue_ice", 3, 3, "block", null), row(4, "slime_block", 4, 4, "block", null), row(5, "soul_sand", 5, 5, "block", null),
        row(6, "honey_block", 6, 6, "block", null), row(7, "cobweb", 7, 7, "empty", null),
        row(8, "water", 8, 23, "empty", "{\"name\":\"level\",\"type\":\"int\",\"num_values\":16}"),
        row(9, "lava", 24, 39, "empty", "{\"name\":\"level\",\"type\":\"int\",\"num_values\":16}"),
        row(10, "ladder", 40, 43, "block", "{\"name\":\"facing\",\"type\":\"enum\",\"num_values\":4,\"values\":[\"north\",\"south\",\"west\",\"east\"]}"),
        row(11, "oak_slab", 44, 49, "block", "{\"name\":\"type\",\"type\":\"enum\",\"num_values\":3,\"values\":[\"top\",\"bottom\",\"double\"]},{\"name\":\"waterlogged\",\"type\":\"bool\",\"num_values\":2}"),
        row(12, "oak_stairs", 50, 50, "block", null), row(13, "bedrock", 51, 51, "block", null)) + "]";

    /** minecraft-data blockCollisionShapes format. shape ids: 0 none, 1 full, 2 bottom slab, 3 top slab, 4 soul sand, 5-8 ladder boards, 9 stairs (2 boxes). */
    static final String SHAPES = "{\"blocks\":{\"air\":0,\"stone\":1,\"ice\":1,\"blue_ice\":1,\"slime_block\":1,\"soul_sand\":4,\"honey_block\":1,\"cobweb\":0,\"water\":0,\"lava\":0,"
        + "\"ladder\":[5,6,7,8],\"oak_slab\":[3,3,2,2,1,1],\"oak_stairs\":9,\"bedrock\":1},"
        + "\"shapes\":{\"0\":[],\"1\":[[0,0,0,1,1,1]],\"2\":[[0,0,0,1,0.5,1]],\"3\":[[0,0.5,0,1,1,1]],\"4\":[[0,0,0,1,0.875,1]],"
        + "\"5\":[[0,0,0.8125,1,1,1]],\"6\":[[0,0,0,1,1,0.1875]],\"7\":[[0.8125,0,0,1,1,1]],\"8\":[[0,0,0,0.1875,1,1]],\"9\":[[0,0,0,1,0.5,1],[0,0.5,0.5,1,1,1]]}}";

    static Data.Blocks registry(boolean shapes) {
        Data.Blocks b = Data.Blocks.parse(REGISTRY);
        if (shapes) { String r = b.loadShapes(SHAPES); if (r != null) throw new IllegalStateException("shapes rejected: " + r); }
        return b;
    }

    /** Stone up to and including floorY (so the floor surface is floorY+1), chunks 0..1 loaded. */
    static World flat(int floorY, boolean shapes) {
        World w = new World();
        w.minY = 0; w.height = 64;
        w.blocks = registry(shapes);
        for (int cx = 0; cx <= 1; cx++) for (int cz = 0; cz <= 1; cz++) w.ensureChunk(cx, cz);
        for (int x = 0; x < 32; x++) for (int z = 0; z < 32; z++) for (int y = 0; y <= floorY; y++) w.set(x, y, z, STONE);
        return w;
    }

    static Physics at(World w, double x, double y, double z) {
        Physics p = new Physics(w);
        p.x = x; p.y = y; p.z = z; p.onGround = true;
        return p;
    }

    static Physics.Input fwd() { Physics.Input i = new Physics.Input(); i.forward = 1; return i; }
    static Physics.Input sprint() { Physics.Input i = fwd(); i.sprint = true; return i; }

    /** Runs n ticks and returns the distance moved in the last tick. */
    static double lastStep(Physics p, Physics.Input in, float yaw, int n) {
        double d = 0;
        for (int i = 0; i < n; i++) { double px = p.x, pz = p.z; p.tick(in, yaw); d = Math.hypot(p.x - px, p.z - pz); }
        return d;
    }

    static void run() {
        T.suite("physics: reference values");
        World w = flat(4, false);
        Physics p = at(w, 8.5, 5, 2.5);
        T.eq("standing still stays on the ground", tickAndGround(p), true);

        p = at(w, 8.5, 5, 2.5);
        double step = lastStep(p, fwd(), 0, 60);
        T.check("walking speed 0.2158/tick (got " + String.format("%.5f", step) + ")", Math.abs(step - 0.2158) < 0.0004);
        p = at(w, 8.5, 5, 2.5);
        step = lastStep(p, sprint(), 0, 60);
        T.check("sprinting speed 0.2806/tick (got " + String.format("%.5f", step) + ")", Math.abs(step - 0.2806) < 0.0004);
        T.check("sprint flag is set by forward + sprint", p.sprinting);

        // first tick on 0.6 friction ground: accel 0.1*0.98 = 0.098 along +Z
        p = at(w, 8.5, 5, 2.5);
        p.tick(fwd(), 0);
        T.check("first tick moves 0.098 (got " + String.format("%.5f", p.z - 2.5) + ")", Math.abs(p.z - 2.5 - 0.098) < 1e-6);
        T.check("then friction 0.6*0.91 leaves vz = 0.098*0.546", Math.abs(p.vz - 0.098 * 0.546) < 1e-6);
        // yaw 90 = -X, yaw -90 = +X, yaw 180 = -Z
        p = at(w, 8.5, 5, 8.5); p.tick(fwd(), 90);
        T.check("yaw 90 walks toward -X", p.x < 8.5 - 0.09 && Math.abs(p.z - 8.5) < 1e-6);
        p = at(w, 8.5, 5, 8.5); p.tick(fwd(), -90);
        T.check("yaw -90 walks toward +X", p.x > 8.5 + 0.09);
        p = at(w, 8.5, 5, 8.5); p.tick(fwd(), 180);
        T.check("yaw 180 walks toward -Z", p.z < 8.5 - 0.09);
        // diagonal input is not faster than straight (the vector is normalised above length 1)
        Physics.Input diag = fwd(); diag.strafe = 1;
        p = at(w, 8.5, 5, 2.5); double dd = lastStep(p, diag, 0, 60);
        p = at(w, 8.5, 5, 2.5); double ds = lastStep(p, fwd(), 0, 60);
        T.check("forward+strafe is normalised: at most 1/0.98 faster than forward (" + String.format("%.4f vs %.4f", dd, ds) + ")", dd >= ds - 1e-4 && dd <= ds / 0.98 + 1e-3);

        // jump: peak 1.2522 above the floor, 12 ticks in the air
        p = at(w, 8.5, 5, 8.5);
        Physics.Input jump = new Physics.Input(); jump.jump = true;
        p.tick(jump, 0);
        double peak = p.y - 5; int air = 1;
        Physics.Input none = new Physics.Input();
        while (!p.onGround && air < 100) { p.tick(none, 0); peak = Math.max(peak, p.y - 5); air++; }
        T.check("jump peak 1.2522 (got " + String.format("%.5f", peak) + ")", Math.abs(peak - 1.2522) < 0.0005);
        T.eq("jump lasts 12 ticks", air, 12);
        T.check("jump lands exactly on the floor", Math.abs(p.y - 5) < 1e-9);

        // free fall from rest: 7 blocks take 15 ticks
        p = at(w, 8.5, 12, 8.5); p.onGround = false;
        int t = 0;
        while (!p.onGround && t < 200) { p.tick(none, 0); t++; }
        T.eq("falling 7 blocks takes 15 ticks", t, 15);
        double term = terminal(); T.check("terminal velocity approaches -3.92 (" + String.format("%.4f", term) + ")", term < -3.91 && term > -3.93);

        T.suite("physics: input, sprint and jumping rules");
        // air acceleration 0.02, sprinting 0.026 (checked on the very first airborne tick, vy is irrelevant)
        p = at(w, 8.5, 30, 8.5); p.onGround = false; p.tick(fwd(), 0);
        T.check("air acceleration 0.02*0.98*0.91", Math.abs(p.vz - 0.02 * 0.98 * 0.91) < 1e-6);
        p = at(w, 8.5, 30, 8.5); p.onGround = false; p.tick(sprint(), 0);
        T.check("sprinting air acceleration 0.026*0.98*0.91", Math.abs(p.vz - 0.025999999 * 0.98 * 0.91) < 1e-6);
        // sneak: input x0.3, never sprints
        Physics.Input sn = fwd(); sn.sneak = true; sn.sprint = true;
        p = at(w, 8.5, 5, 8.5); double sneakStep = lastStep(p, sn, 0, 60);
        T.check("sneaking walks at ~0.3 of the speed (" + String.format("%.4f", sneakStep) + ")", Math.abs(sneakStep - 0.2158 * 0.3) < 0.004 && !p.sprinting);
        // sprint needs forward >= 0.8
        Physics.Input half = sprint(); half.forward = 0.5f;
        p = at(w, 8.5, 5, 8.5); p.tick(half, 0);
        T.check("forward 0.5 does not start a sprint", !p.sprinting);
        half.forward = 0.8f; p = at(w, 8.5, 5, 8.5); p.tick(half, 0);
        T.check("forward 0.8 starts a sprint", p.sprinting);
        p = at(w, 8.5, 5, 8.5); p.enoughFood = false; p.tick(sprint(), 0);
        T.check("no sprint with food <= 6", !p.sprinting);
        p = at(w, 8.5, 5, 8.5); p.tick(sprint(), 0); p.tick(none, 0);
        T.check("releasing forward ends the sprint", !p.sprinting);
        // sprint stops when running into a wall
        for (int y = 5; y <= 8; y++) for (int x = 0; x < 32; x++) w.set(x, y, 12, STONE);
        p = at(w, 8.5, 5, 8.5); lastStep(p, sprint(), 0, 40);
        T.check("running into a wall stops the sprint and the player", !p.sprinting && p.z <= 12 - 0.3 + 1e-6 && p.z > 11.6);
        for (int y = 5; y <= 8; y++) for (int x = 0; x < 32; x++) w.set(x, y, 12, AIR);

        // jump delay and the sprint kick
        p = at(w, 8.5, 5, 8.5); jump.jump = true; p.tick(jump, 0);
        T.eq("jump sets the 10 tick delay", p.noJumpDelay, 10);
        p.tick(jump, 0);
        T.eq("the delay counts down while jump is held", p.noJumpDelay, 9);
        p.tick(none, 0);
        T.eq("releasing jump clears the delay", p.noJumpDelay, 0);
        World low = flat(4, false);
        for (int x = 0; x < 32; x++) for (int z = 0; z < 32; z++) low.set(x, 7, z, STONE); // ceiling bottom at y=7 (head room 2.0)
        p = at(low, 8.5, 5, 8.5);
        List<Integer> jumpsAt = new ArrayList<>();
        for (int i = 0; i < 60; i++) { boolean was = p.onGround; double y0 = p.y; p.tick(jump, 0); if (p.y > y0 + 0.1 && was) jumpsAt.add(i); }
        boolean spaced = jumpsAt.size() >= 3;
        for (int i = 1; i < jumpsAt.size(); i++) if (jumpsAt.get(i) - jumpsAt.get(i - 1) < 10) spaced = false;
        T.check("holding jump under a low ceiling jumps at most every 10 ticks " + jumpsAt, spaced);
        T.check("the ceiling stops the head (y+1.8 <= 7)", true);
        p = at(low, 8.5, 5, 8.5); double maxHead = 0; for (int i = 0; i < 30; i++) { p.tick(jump, 0); maxHead = Math.max(maxHead, p.y + 1.8); }
        T.check("head never enters the ceiling (max " + String.format("%.4f", maxHead) + ")", maxHead <= 7 + 1e-6);

        p = at(w, 8.5, 5, 8.5); p.jumpBoost = 1; p.tick(jump, 0);
        double bp = p.y - 5; while (!p.onGround) { p.tick(none, 0); bp = Math.max(bp, p.y - 5); }
        T.check("jump boost I jumps higher (" + String.format("%.3f", bp) + ")", bp > 1.7 && bp < 2.0);
        p = at(w, 8.5, 5, 8.5); Physics.Input sj = sprint(); sj.jump = true;
        double sx = 0; p.tick(sj, 0); while (!p.onGround) { p.tick(sj, 0); sx = p.z - 8.5; }
        p = at(w, 8.5, 5, 8.5); Physics.Input pj = fwd(); pj.jump = true;
        double px = 0; p.tick(pj, 0); while (!p.onGround) { p.tick(pj, 0); px = p.z - 8.5; }
        T.check("a sprint jump covers more ground than a walking jump (" + String.format("%.2f vs %.2f", sx, px) + ")", sx > px + 0.8);

        T.suite("physics: friction blocks");
        World iceW = flat(4, false);
        for (int x = 0; x < 32; x++) for (int z = 0; z < 32; z++) iceW.set(x, 4, z, ICE);
        p = at(iceW, 8.5, 5, 2.5); lastStep(p, fwd(), 0, 80);
        double z0 = p.z; for (int i = 0; i < 80; i++) p.tick(none, 0);
        double iceSlide = p.z - z0;
        p = at(w, 8.5, 5, 2.5); lastStep(p, fwd(), 0, 80);
        z0 = p.z; for (int i = 0; i < 80; i++) p.tick(none, 0);
        double stoneSlide = p.z - z0;
        T.check("ice: slides much further after releasing (" + String.format("%.2f vs %.2f", iceSlide, stoneSlide) + ")", iceSlide > stoneSlide * 4);
        T.check("friction of ice is 0.98", at(iceW, 8.5, 5, 8.5).world.friction(8, 4, 8) == 0.98f);
        World blue = flat(4, false); blue.set(8, 4, 8, BLUE_ICE);
        T.check("blue ice friction 0.989, slime 0.8, stone 0.6", blue.friction(8, 4, 8) == 0.989f && registry(false).friction(SLIME) == 0.8f && blue.friction(8, 3, 8) == 0.6f);
        World slow = flat(4, false);
        for (int x = 0; x < 32; x++) for (int z = 0; z < 32; z++) slow.set(x, 4, z, SOUL_SAND);
        p = at(slow, 8.5, 5, 2.5); double ss = lastStep(p, fwd(), 0, 80);
        T.check("soul sand: the 0.4 factor applies to the carried speed, walking drops to ~0.125/tick (" + String.format("%.4f", ss) + ")", ss > 0.115 && ss < 0.135);
        World honey = flat(4, false);
        for (int x = 0; x < 32; x++) for (int z = 0; z < 32; z++) honey.set(x, 4, z, HONEY);
        p = at(honey, 8.5, 5, 8.5); p.tick(jump, 0);
        T.check("honey halves the jump (vy " + String.format("%.3f", p.vy) + ")", p.vy < 0.21 && p.vy > 0.1);
        World slimeW = flat(4, false);
        for (int x = 0; x < 32; x++) for (int z = 0; z < 32; z++) slimeW.set(x, 4, z, SLIME);
        p = at(slimeW, 8.5, 12, 8.5); p.onGround = false;
        boolean bounced = false; for (int i = 0; i < 40; i++) { p.tick(none, 0); if (p.vy > 0.3) bounced = true; }
        T.check("slime block bounces a falling player", bounced);
        World web = flat(4, false);
        for (int y = 5; y <= 6; y++) for (int x = 0; x < 32; x++) for (int z = 0; z < 32; z++) web.set(x, y, z, COBWEB);
        p = at(web, 8.5, 5, 2.5); double ws = lastStep(p, fwd(), 0, 40);
        T.check("cobweb crawls (" + String.format("%.4f", ws) + " per tick)", ws < 0.06);

        T.suite("physics: water, lava and ladders");
        World pool = flat(4, false);
        for (int x = 0; x < 32; x++) for (int z = 0; z < 32; z++) for (int y = 5; y <= 9; y++) pool.set(x, y, z, WATER);
        p = at(pool, 8.5, 8, 8.5); p.onGround = false;
        for (int i = 0; i < 60; i++) p.tick(none, 0);
        T.check("sinking speed in water ~ -0.025 (" + String.format("%.4f", p.vy) + ")", p.vy < -0.02 && p.vy > -0.03);
        p = at(pool, 8.5, 5, 8.5); p.onGround = false;
        Physics.Input up = new Physics.Input(); up.jump = true;
        double y0 = 0; for (int i = 0; i < 40; i++) { y0 = p.y; p.tick(up, 0); if (p.y > 8.5) break; }
        T.check("holding jump rises in water at ~0.175/tick (carried 0.135 + 0.04) (" + String.format("%.3f", p.y - y0) + ")", Math.abs(p.y - y0 - 0.175) < 0.01);
        p = at(pool, 8.5, 5, 2.5); p.onGround = false; lastStep(p, fwd(), 0, 60);
        double ws2 = lastStep(p, fwd(), 0, 5);
        T.check("swimming speed ~0.098 (" + String.format("%.4f", ws2) + ")", Math.abs(ws2 - 0.098) < 0.01);
        T.check("water is detected", p.inWater());
        // swim to the bank and climb out: pool x<10, bank x>=10 with its top one block above the water
        World bank = flat(4, false);
        for (int x = 0; x < 10; x++) for (int z = 0; z < 32; z++) { bank.set(x, 4, z, AIR); bank.set(x, 3, z, STONE); for (int y = 4; y <= 5; y++) bank.set(x, y, z, WATER); }
        for (int x = 0; x < 32; x++) for (int z = 0; z < 32; z++) if (x >= 10) bank.set(x, 5, z, STONE); // the bank is 2 above the pool floor
        p = at(bank, 5.5, 4, 8.5); p.onGround = false;
        Physics.Input swimOut = fwd(); swimOut.jump = true;
        float east = -90; // +X
        for (int i = 0; i < 80 && !(p.onGround && p.x > 10.3); i++) p.tick(swimOut, east);
        T.check("swimming out of the pool onto the bank (x=" + String.format("%.2f", p.x) + ", y=" + String.format("%.2f", p.y) + ")", p.onGround && p.x > 10.3 && Math.abs(p.y - 6) < 1e-6);
        World lava = flat(4, false);
        for (int y = 5; y <= 8; y++) for (int x = 0; x < 32; x++) for (int z = 0; z < 32; z++) lava.set(x, y, z, LAVA);
        p = at(lava, 8.5, 8, 8.5); p.onGround = false;
        for (int i = 0; i < 30; i++) p.tick(none, 0);
        T.check("lava is detected and sinks slowly (" + String.format("%.3f", p.vy) + ")", p.inLava() && p.vy > -0.1 && p.vy < 0);
        // ladder
        World lad = flat(4, true);
        for (int y = 5; y <= 15; y++) { lad.set(8, y, 8, LADDER); lad.set(8, y, 9, STONE); }
        p = at(lad, 8.5, 5, 8.5);
        p.tick(up, 0); p.tick(up, 0);
        double ly = p.y; p.tick(up, 0);
        T.check("on a ladder holding jump climbs 0.1176/tick (" + String.format("%.4f", p.y - ly) + ")", p.onClimbable() && Math.abs(p.y - ly - 0.1176) < 0.003);
        for (int i = 0; i < 120; i++) p.tick(up, 0);
        T.check("the ladder takes the player up to its top (y=" + String.format("%.2f", p.y) + ")", p.y > 15.5 && p.y < 17.5);
        p = at(lad, 8.5, 12, 8.5); p.onGround = false; p.tick(none, 0); p.tick(none, 0);
        ly = p.y; p.tick(none, 0);
        T.check("without input the player slides down at 0.15/tick (" + String.format("%.4f", p.y - ly) + ")", Math.abs(p.y - ly + 0.15) < 0.005);
        Physics.Input sneakIn = new Physics.Input(); sneakIn.sneak = true;
        p = at(lad, 8.5, 12, 8.5); p.onGround = false; for (int i = 0; i < 10; i++) p.tick(sneakIn, 0);
        double held = p.y; for (int i = 0; i < 20; i++) p.tick(sneakIn, 0);
        T.check("sneaking on a ladder holds the position (" + String.format("%.3f -> %.3f", held, p.y) + ")", Math.abs(p.y - held) < 0.01);
        p = at(lad, 8.5, 8, 8.5); p.onGround = false; p.vx = 1; p.tick(none, 0);
        T.check("horizontal speed on a ladder is clamped to 0.15", Math.abs(p.x - 8.5) <= 0.15 + 1e-6);

        T.suite("physics: collision shapes (step-up, slabs, stairs, ledges)");
        World sh = flat(4, true);
        sh.set(8, 5, 6, SLAB + 3); // bottom slab (waterlogged=false), 0.5 high
        p = at(sh, 8.5, 5, 2.5); boolean onSlab = false; for (int i = 0; i < 40; i++) { p.tick(fwd(), 0); if (p.z > 6.0 && p.z < 7.0 && Math.abs(p.y - 5.5) < 1e-6 && p.onGround) onSlab = true; }
        T.check("a bottom slab is walked up without jumping", onSlab);
        World full = flat(4, true); full.set(8, 5, 6, STONE);
        p = at(full, 8.5, 5, 2.5); lastStep(p, fwd(), 0, 40);
        T.check("a full block is not stepped up (blocked at z=" + String.format("%.3f", p.z) + ")", Math.abs(p.y - 5) < 1e-6 && p.z < 6 - 0.3 + 1e-6 && p.z > 5.6);
        p = at(full, 8.5, 5, 2.5); Physics.Input fj = fwd(); fj.jump = true; double hi = 0; for (int i = 0; i < 60; i++) { p.tick(fj, 0); if (p.onGround) hi = Math.max(hi, p.y); }
        T.check("with jumping the player gets onto the full block (standing at y=" + String.format("%.2f", hi) + ")", Math.abs(hi - 6.0) < 1e-6);
        World top = flat(4, true); top.set(8, 5, 6, SLAB + 1); // top slab (dry) floats at 5.5..6
        p = at(top, 8.5, 5, 2.5); lastStep(p, fwd(), 0, 40);
        T.check("a top slab has 0.5 of head room underneath: walking through is blocked at the shape (z=" + String.format("%.3f", p.z) + ")", p.z < 6 - 0.3 + 1e-6);
        World st = flat(4, true); st.set(8, 5, 6, 50);
        p = at(st, 8.5, 5, 2.5); double stairMax = 5; boolean halfStep = false;
        for (int i = 0; i < 30; i++) { p.tick(fwd(), 0); if (p.onGround) { stairMax = Math.max(stairMax, p.y); if (Math.abs(p.y - 5.5) < 1e-6) halfStep = true; } }
        T.check("stairs are climbed in two 0.5 steps without jumping (5.0 -> 5.5 -> 6.0)", halfStep && Math.abs(stairMax - 6.0) < 1e-6);
        World soul = flat(4, true); soul.set(8, 4, 8, SOUL_SAND);
        p = at(soul, 8.5, 4.875, 8.5); for (int i = 0; i < 3; i++) p.tick(none, 0);
        T.check("soul sand has its 0.875 collision shape (stands at 4.875)", Math.abs(p.y - 4.875) < 1e-6 && p.onGround);
        // ceiling-side: wall slide, corner (axis order)
        for (int y = 5; y <= 8; y++) for (int z = 0; z < 32; z++) w.set(12, y, z, STONE);
        Physics.Input fs = fwd(); fs.strafe = -1; // forward + right
        p = at(w, 8.5, 5, 8.5); float yawEast = -90;
        double zBefore = p.z; for (int i = 0; i < 30; i++) p.tick(fs, yawEast);
        T.check("pushing diagonally into a wall slides along it (z moved " + String.format("%.2f", p.z - zBefore) + ")", p.x <= 12 - 0.3 + 1e-6 && Math.abs(p.z - zBefore) > 1.0);
        for (int y = 5; y <= 8; y++) for (int z = 0; z < 32; z++) w.set(12, y, z, AIR);
        // sneaking at a ledge
        World ledge = flat(4, false);
        for (int x = 8; x < 32; x++) for (int z = 0; z < 32; z++) for (int y = 0; y <= 4; y++) ledge.set(x, y, z, AIR);
        Physics.Input sneakFwd = fwd(); sneakFwd.sneak = true;
        p = at(ledge, 5.5, 5, 8.5); for (int i = 0; i < 80; i++) p.tick(sneakFwd, -90);
        T.check("sneaking never walks off the ledge (x=" + String.format("%.3f", p.x) + ")", p.y == 5 && p.onGround && p.x < 8 + 0.3 + 0.05);
        p = at(ledge, 5.5, 5, 8.5); for (int i = 0; i < 60; i++) p.tick(fwd(), -90);
        T.check("walking does walk off the ledge", p.y < 4);

        T.suite("physics: flying, effects, unloaded chunks");
        World sky = flat(4, false);
        p = at(sky, 8.5, 20, 8.5); p.onGround = false; p.flying = true; p.mayFly = true;
        for (int i = 0; i < 20; i++) p.tick(none, 0);
        T.check("flying: no gravity (y stays 20)", Math.abs(p.y - 20) < 1e-9);
        Physics.Input fup = new Physics.Input(); fup.jump = true;
        for (int i = 0; i < 40; i++) p.tick(fup, 0);
        double fy = p.y; p.tick(fup, 0);
        T.check("flying up: 3*flySpeed with vy x0.6 -> 0.375/tick (" + String.format("%.4f", p.y - fy) + ")", Math.abs(p.y - fy - 0.375) < 0.003);
        p = at(sky, 8.5, 20, 30.5); p.onGround = false; p.flying = true; p.mayFly = true; p.vz = -0.4949;
        double fl = lastStep(p, fwd(), 180, 15);
        T.check("creative flight 0.544/tick = 10.9 blocks/s (" + String.format("%.4f", fl) + ")", Math.abs(fl - 0.544) < 0.004);
        p = at(sky, 8.5, 20, 31.5); p.onGround = false; p.flying = true; p.mayFly = true; p.vz = -0.99;
        fl = lastStep(p, sprint(), 180, 12);
        T.check("sprint flight doubles the flying speed (" + String.format("%.4f", fl) + ")", fl > 1.0 && fl < 1.15);
        p = at(w, 8.5, 6.5, 8.5); p.onGround = false; p.flying = true; p.mayFly = true;
        for (int i = 0; i < 10; i++) p.tick(none, 0);
        T.check("flying without vertical input hovers", p.flying && Math.abs(p.y - 6.5) < 1e-9);
        Physics.Input down = new Physics.Input(); down.sneak = true; boolean cancelled = false;
        for (int i = 0; i < 30 && p.flying; i++) { p.tick(down, 0); cancelled = p.flightCancelled; }
        T.check("sneaking down to the ground ends the flight and flags it for the session", !p.flying && cancelled && p.onGround);
        p = at(sky, 8.5, 3000, 8.5); p.onGround = false; p.slowFalling = true;
        for (int i = 0; i < 300; i++) p.tick(none, 0);
        T.check("slow falling: gravity 0.01 -> terminal ~ -0.49 (" + String.format("%.3f", p.vy) + ")", Math.abs(p.vy + 0.49) < 0.01);
        p = at(sky, 8.5, 20, 8.5); p.onGround = false; p.levitation = 1;
        for (int i = 0; i < 40; i++) p.tick(none, 0);
        T.check("levitation I rises 0.9 blocks/s = 0.045/tick (vy " + String.format("%.4f", p.vy) + ")", p.vy > 0.04 && p.vy < 0.05 && p.y > 20);
        p = at(sky, 8.5, 20, 8.5); p.onGround = false; p.vx = 0.002; p.vz = -0.002; p.vy = 0.002; p.tick(none, 0);
        T.check("velocities under 0.003 are zeroed", p.x == 8.5 && p.z == 8.5);
        p = at(sky, 8.5, 5, 8.5); p.speedBase = 0.1 * 1.2; double fast = lastStep(p, fwd(), 0, 60);
        T.check("a speed attribute of 0.12 scales walking by 1.2 (" + String.format("%.4f", fast) + ")", Math.abs(fast - 0.2158 * 1.2) < 0.001);

        World edge = new World(); edge.minY = 0; edge.height = 64; edge.blocks = registry(false);
        edge.ensureChunk(0, 0);
        for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) edge.set(x, 4, z, STONE);
        p = at(edge, 15.9, 5, 8.5); boolean ok = true; for (int i = 0; i < 10; i++) ok &= p.tick(none, 0);
        T.check("standing at a chunk edge with the neighbour chunk missing keeps ticking and stays up", ok && p.onGround && p.y == 5);
        p = at(edge, 40.5, 5, 8.5);
        T.check("no physics at all when the player's own chunk is missing", !p.tick(none, 0) && p.y == 5);
        T.check("a loaded chunk ticks normally", at(edge, 8.5, 5, 8.5).tick(none, 0));
    }

    static boolean tickAndGround(Physics p) { for (int i = 0; i < 10; i++) p.tick(new Physics.Input(), 0); return p.onGround && p.y == 5; }

    static double terminal() {
        World a = flat(4, false);
        Physics p = at(a, 8.5, 3000, 8.5); p.onGround = false;
        for (int i = 0; i < 400; i++) p.tick(new Physics.Input(), 0);
        return p.vy;
    }
}
