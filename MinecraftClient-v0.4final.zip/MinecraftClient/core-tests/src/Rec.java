import com.mcclient.core.*;
import java.util.*;
import java.util.concurrent.*;

/** Records everything the session reports. */
final class Rec implements ClientSession.Listener {
    final List<String> chat = Collections.synchronizedList(new ArrayList<String>());
    final List<List<Chat.Span>> chatSpans = Collections.synchronizedList(new ArrayList<List<Chat.Span>>());
    final List<ClientSession.Status> statuses = Collections.synchronizedList(new ArrayList<ClientSession.Status>());
    volatile float hp = -1; volatile int food = -1;
    volatile List<String> players = new ArrayList<>();
    volatile ClientSession.Suggestions suggestions;
    volatile ClientSession.PackOffer offer;
    final BlockingQueue<ClientSession.PackOffer> offers = new LinkedBlockingQueue<>();
    volatile String actionBar = "";
    final List<String> actionStatus = Collections.synchronizedList(new ArrayList<String>());
    volatile boolean actionRunning;
    volatile String ended;
    final List<Boolean> packResults = Collections.synchronizedList(new ArrayList<Boolean>());
    final List<Boolean> packCached = Collections.synchronizedList(new ArrayList<Boolean>());
    final List<Integer> reconnectCountdown = Collections.synchronizedList(new ArrayList<Integer>());
    volatile int inventoryEvents;

    @Override public void onStatus(ClientSession.Status s, String info) { statuses.add(s); }
    @Override public void onReconnectIn(int s) { reconnectCountdown.add(s); }
    @Override public void onChat(List<Chat.Span> spans) {
        StringBuilder sb = new StringBuilder(); for (Chat.Span s : spans) sb.append(s.text);
        chat.add(sb.toString()); chatSpans.add(spans);
    }
    @Override public void onActionBar(List<Chat.Span> spans) { StringBuilder sb = new StringBuilder(); for (Chat.Span s : spans) sb.append(s.text); actionBar = sb.toString(); }
    @Override public void onHealth(float h, int f) { hp = h; food = f; }
    @Override public void onPlayers(List<String> n) { players = n; }
    @Override public void onPackOffer(ClientSession.PackOffer o) { offer = o; offers.add(o); }
    @Override public void onPackResult(boolean ok, boolean cached, String err) { packResults.add(ok); packCached.add(cached); }
    @Override public void onSuggestions(ClientSession.Suggestions s) { suggestions = s; }
    @Override public void onInventory() { inventoryEvents++; }
    @Override public void onActionStatus(String t, boolean running) { actionStatus.add(t); actionRunning = running; }
    @Override public void onEnded(String r) { ended = r; }

    static boolean waitFor(java.util.function.BooleanSupplier cond, int ms) {
        long end = System.currentTimeMillis() + ms;
        while (System.currentTimeMillis() < end) { if (cond.getAsBoolean()) return true; try { Thread.sleep(15); } catch (InterruptedException e) { return false; } }
        return cond.getAsBoolean();
    }
    boolean chatHas(String s) { synchronized (chat) { for (String c : chat) if (c.contains(s)) return true; } return false; }
    boolean waitChat(String s, int ms) { return waitFor(() -> chatHas(s), ms); }
}
