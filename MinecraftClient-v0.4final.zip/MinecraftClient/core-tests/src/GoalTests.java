import com.mcclient.core.*;
import java.util.*;

/** Goals and ActionCosts ported from baritone-api 1.8.6 (values and formulas checked against the jar), menu layouts, shapes loader. */
public final class GoalTests {
    static boolean near(double a, double b) { return Math.abs(a - b) < 1e-6 * Math.max(1, Math.abs(b)); }

    static void run() {
        planning();
        T.suite("baritone: ActionCosts");
        T.check("WALK_ONE_BLOCK_COST = 20/4.317", near(ActionCosts.WALK_ONE_BLOCK_COST, 20 / 4.317));
        T.check("SPRINT_ONE_BLOCK_COST = 20/5.612 = costHeuristic default", near(ActionCosts.SPRINT_ONE_BLOCK_COST, 20 / 5.612) && near(Goals.costHeuristic, 3.563791874554526));
        T.check("WALK_ONE_IN_WATER_COST = 20/2.2, soul sand = 2x walk", near(ActionCosts.WALK_ONE_IN_WATER_COST, 20 / 2.2) && near(ActionCosts.WALK_ONE_OVER_SOUL_SAND_COST, ActionCosts.WALK_ONE_BLOCK_COST * 2));
        T.check("ladder up 20/2.35, down 20/3.0, sneak 20/1.3", near(ActionCosts.LADDER_UP_ONE_COST, 20 / 2.35) && near(ActionCosts.LADDER_DOWN_ONE_COST, 20 / 3.0) && near(ActionCosts.SNEAK_ONE_BLOCK_COST, 20 / 1.3));
        T.check("WALK_OFF_BLOCK_COST = walk*0.8, CENTER_AFTER_FALL = walk*0.2", near(ActionCosts.WALK_OFF_BLOCK_COST, ActionCosts.WALK_ONE_BLOCK_COST * 0.8) && near(ActionCosts.CENTER_AFTER_FALL_COST, ActionCosts.WALK_ONE_BLOCK_COST * 0.2));
        T.check("fall velocity: 0.0784 after one tick, -3.92 terminal", near(ActionCosts.velocity(1), 0.0784) && ActionCosts.velocity(500) > 3.919);
        T.check("falling 0 blocks costs nothing, the table is monotonic", ActionCosts.FALL_N_BLOCKS_COST[0] == 0 && ActionCosts.FALL_N_BLOCKS_COST[3] > ActionCosts.FALL_N_BLOCKS_COST[2] && ActionCosts.FALL_N_BLOCKS_COST[2] > ActionCosts.FALL_N_BLOCKS_COST[1]);
        T.check("JUMP_ONE_BLOCK_COST = fall(1.25) - fall(0.25)", near(ActionCosts.JUMP_ONE_BLOCK_COST, ActionCosts.distanceToTicks(1.25) - ActionCosts.distanceToTicks(0.25)) && ActionCosts.JUMP_ONE_BLOCK_COST > 1);
        T.check("a 1 block fall takes ~ 4.5 ticks (14 ticks = 4 blocks of the table agree with the 15 tick/7 block physics)", ActionCosts.FALL_N_BLOCKS_COST[7] > 14 && ActionCosts.FALL_N_BLOCKS_COST[7] < 15.1);

        T.suite("baritone: goals");
        double h = Goals.costHeuristic;
        Goals.GoalXZ xz = new Goals.GoalXZ(10, 10);
        T.check("GoalXZ is any height of the column", xz.isInGoal(10, 3, 10) && xz.isInGoal(10, 200, 10) && !xz.isInGoal(9, 3, 10));
        T.check("GoalXZ heuristic: straight line", near(xz.heuristic(0, 64, 10), 10 * h));
        T.check("GoalXZ heuristic: diagonal uses sqrt(2) (3,4 -> 3*sqrt2+1)", near(new Goals.GoalXZ(3, 4).heuristic(0, 0, 0), (3 * Math.sqrt(2) + 1) * h));
        T.check("GoalXZ heuristic is symmetric", near(new Goals.GoalXZ(-3, 4).heuristic(0, 0, 0), new Goals.GoalXZ(3, -4).heuristic(0, 0, 0)));
        Goals.GoalBlock gb = new Goals.GoalBlock(5, 70, 5);
        T.check("GoalBlock: exactly one cell", gb.isInGoal(5, 70, 5) && !gb.isInGoal(5, 71, 5) && !gb.isInGoal(4, 70, 5));
        T.check("GoalBlock heuristic is 0 at the goal", gb.heuristic(5, 70, 5) == 0);
        T.check("GoalBlock: needing to go up costs jump cost per block (+ xz part)", near(gb.heuristic(5, 68, 5), 2 * ActionCosts.JUMP_ONE_BLOCK_COST));
        T.check("GoalBlock: dropping down costs FALL_N[2]/2 per block", near(gb.heuristic(5, 73, 5), 3 * ActionCosts.FALL_N_BLOCKS_COST[2] / 2));
        T.check("GoalBlock = GoalYLevel part + GoalXZ part", near(gb.heuristic(8, 72, 9), 2 * ActionCosts.FALL_N_BLOCKS_COST[2] / 2 + new Goals.GoalXZ(5, 5).heuristic(8, 72, 9)));
        Goals.GoalNear gn = new Goals.GoalNear(0, 64, 0, 3);
        T.check("GoalNear: inside the sphere of radius 3 (9 = squared range)", gn.isInGoal(3, 64, 0) && gn.isInGoal(2, 66, 1) && !gn.isInGoal(3, 65, 0) && !gn.isInGoal(4, 64, 0));
        T.check("GoalNear heuristic equals the GoalBlock heuristic", near(gn.heuristic(7, 60, -2), new Goals.GoalBlock(0, 64, 0).heuristic(7, 60, -2)));
        Goals.GoalGetToBlock gg = new Goals.GoalGetToBlock(10, 64, 10);
        T.check("GoalGetToBlock: the four neighbours, above and the block's own cell", gg.isInGoal(11, 64, 10) && gg.isInGoal(9, 64, 10) && gg.isInGoal(10, 64, 11) && gg.isInGoal(10, 64, 9) && gg.isInGoal(10, 65, 10) && gg.isInGoal(10, 64, 10));
        T.check("GoalGetToBlock: one below counts (head next to it), two cells away does not", gg.isInGoal(10, 63, 10) && !gg.isInGoal(12, 64, 10) && !gg.isInGoal(10, 66, 10) && !gg.isInGoal(11, 65, 10));
        T.check("GoalGetToBlock: standing 2 below (block right above the head) counts, 4 below does not (abs() wraps the whole y term, checked in the jar)", gg.isInGoal(10, 62, 10) && !gg.isInGoal(10, 61, 10) && !gg.isInGoal(10, 60, 10));
        T.check("GoalGetToBlock heuristic: standing beside it costs 1 block", gg.heuristic(11, 64, 10) > 0 && gg.heuristic(10, 64, 10) == 0 || gg.heuristic(10, 64, 10) >= 0);
        Goals.GoalComposite gc = new Goals.GoalComposite(new Goals.GoalBlock(0, 64, 0), new Goals.GoalBlock(50, 64, 50));
        T.check("GoalComposite: any member", gc.isInGoal(0, 64, 0) && gc.isInGoal(50, 64, 50) && !gc.isInGoal(25, 64, 25));
        T.check("GoalComposite heuristic: the minimum over the goals", near(gc.heuristic(3, 64, 0), new Goals.GoalBlock(0, 64, 0).heuristic(3, 64, 0)) && near(gc.heuristic(48, 64, 50), new Goals.GoalBlock(50, 64, 50).heuristic(48, 64, 50)));
        T.check("GoalYLevel", new Goals.GoalYLevel(70).isInGoal(0, 70, 0) && !new Goals.GoalYLevel(70).isInGoal(0, 71, 0));

        T.suite("menus: types, sizes and layouts (protocol 765)");
        T.eq("25 menu types", MenuLayouts.TYPE_NAMES.length, 25);
        T.check("registry order: crafter_3x3 is 7, anvil 8, beacon 9, crafting 12, enchantment 13, hopper 16, shulker_box 20, stonecutter 24",
            MenuLayouts.TYPE_NAMES[7].equals("crafter_3x3") && MenuLayouts.TYPE_NAMES[8].equals("anvil") && MenuLayouts.TYPE_NAMES[9].equals("beacon") && MenuLayouts.TYPE_NAMES[12].equals("crafting")
            && MenuLayouts.TYPE_NAMES[13].equals("enchantment") && MenuLayouts.TYPE_NAMES[16].equals("hopper") && MenuLayouts.TYPE_NAMES[20].equals("shulker_box") && MenuLayouts.TYPE_NAMES[24].equals("stonecutter"));
        for (int t = 0; t < MenuLayouts.TYPE_NAMES.length; t++) {
            MenuLayouts.Layout l = MenuLayouts.of(t);
            T.check(MenuLayouts.typeName(t) + ": " + l.slots.length + " slots = " + MenuLayouts.containerSlots(t) + " + 36", l.slots.length == MenuLayouts.containerSlots(t) + 36);
            Set<String> seen = new HashSet<>(); boolean ok = true;
            for (int i = 0; i < l.slots.length; i++) { int[] p = l.slots[i]; if (p == null || p[0] + 16 > l.width && t != 17 || (p[1] + 16 > l.height && t != 17)) ok = false; if (t != 17 && !seen.add(p[0] + "," + p[1])) ok = false; }
            T.check(MenuLayouts.typeName(t) + ": every slot inside the texture area, no two slots on the same spot", ok);
        }
        MenuLayouts.Layout g54 = MenuLayouts.of(5);
        T.check("generic_54 (9x6): slots start at (8,18) with spacing 18", g54.slots[0][0] == 8 && g54.slots[0][1] == 18 && g54.slots[1][0] == 26 && g54.slots[9][1] == 36 && g54.slots[53][0] == 8 + 8 * 18 && g54.slots[53][1] == 18 + 5 * 18);
        T.check("generic_54 (9x6): the player inventory starts at y=139, the hotbar at 197, height 222", g54.slots[54][1] == 139 && g54.slots[54 + 27][1] == 197 && g54.height == 222);
        MenuLayouts.Layout g27 = MenuLayouts.of(2);
        T.check("generic_54 (9x3): player inventory y=85, hotbar y=143, height 168", g27.slots[27][1] == 85 && g27.slots[27 + 27][1] == 143 && g27.height == 168);
        T.check("furnace: ingredient (56,17), fuel (56,53), result (116,35)", MenuLayouts.of(14).slots[0][0] == 56 && MenuLayouts.of(14).slots[0][1] == 17 && MenuLayouts.of(14).slots[1][1] == 53 && MenuLayouts.of(14).slots[2][0] == 116);
        T.check("crafting table: result (124,35), grid from (30,17)", MenuLayouts.of(12).slots[0][0] == 124 && MenuLayouts.of(12).slots[1][0] == 30 && MenuLayouts.of(12).slots[1][1] == 17 && MenuLayouts.of(12).slots[9][0] == 30 + 36);
        T.check("enchanting: 3 buttons at x=60, y=14/33/52, 108x19", MenuLayouts.of(13).buttons.size() == 3 && MenuLayouts.of(13).buttons.get(2).y == 52 && MenuLayouts.of(13).buttons.get(0).w == 108);
        T.check("loom and stonecutter have numbered button grids", MenuLayouts.of(18).buttons.size() >= 12 && MenuLayouts.of(24).buttons.size() >= 8);
        T.check("hopper: 5 slots from (44,20)", MenuLayouts.of(16).slots[0][0] == 44 && MenuLayouts.of(16).slots[4][0] == 44 + 72);
        T.check("beacon is wider (230x219) and its inventory starts at x=36", MenuLayouts.of(9).width == 230 && MenuLayouts.of(9).slots[1][0] == 36);
        T.check("villager menu is 276 wide and its inventory starts at x=108", MenuLayouts.of(19).width == 276 && MenuLayouts.of(19).slots[3][0] == 108);
        MenuLayouts.Layout pl = MenuLayouts.playerInventory();
        T.check("inventory.png: 46 slots, armor at x=8, 2x2 grid at (98,18), result (154,28), offhand (77,62)", pl.slots.length == 46 && pl.slots[5][0] == 8 && pl.slots[5][1] == 8 && pl.slots[8][1] == 62 && pl.slots[1][0] == 98 && pl.slots[0][0] == 154 && pl.slots[45][0] == 77 && pl.slots[45][1] == 62);

        T.suite("shapes: blockCollisionShapes.json loader and sanity checks");
        Data.Blocks b = PhysicsTests.registry(false);
        T.check("without shapes every 'block' bounding box is a full cube", b.collisionBoxes(PhysicsTests.STONE) == Data.Blocks.FULL && b.collisionBoxes(PhysicsTests.AIR) == null && !b.hasShapes());
        T.eq("valid data is accepted", b.loadShapes(PhysicsTests.SHAPES), null);
        T.check("slab shapes by state: bottom 0.5 tall, top above 0.5 (last property varies fastest)", b.collisionBoxes(PhysicsTests.SLAB + 2)[0][4] == 0.5 && b.collisionBoxes(PhysicsTests.SLAB + 3)[0][4] == 0.5 && b.collisionBoxes(PhysicsTests.SLAB)[0][1] == 0.5 && b.collisionBoxes(PhysicsTests.SLAB + 4)[0][4] == 1);
        T.check("low steps: bottom slab yes, full block / top slab no", b.isLowStep(PhysicsTests.SLAB + 2) && !b.isLowStep(PhysicsTests.STONE) && !b.isLowStep(PhysicsTests.SLAB));
        Data.Blocks b2 = PhysicsTests.registry(false);
        T.check("a file where stone is not a full cube is rejected", b2.loadShapes(PhysicsTests.SHAPES.replace("\"stone\":1", "\"stone\":2")) != null && !b2.hasShapes());
        T.check("a file with garbage is rejected", b2.loadShapes("{\"blocks\":1}") != null && b2.loadShapes("nope") != null);
        T.check("a file from another game version (no block matches) is rejected", registryRows().loadShapes("{\"blocks\":{\"foo\":1},\"shapes\":{\"1\":[[0,0,0,1,1,1]]}}") != null);
        T.check("fences (1.5 tall boxes) are accepted: real data has them", PhysicsTests.registry(false).loadShapes(PhysicsTests.SHAPES.replace("\"9\":[[0,0,0,1,0.5,1]", "\"9\":[[0.375,0,0.375,0.625,1.5,0.625],[0,0,0,1,0.5,1]")) == null);
        T.check("friction: ice 0.98, blue ice 0.989, slime 0.8, default 0.6", b.friction(PhysicsTests.ICE) == 0.98f && b.friction(PhysicsTests.BLUE_ICE) == 0.989f && b.friction(PhysicsTests.SLIME) == 0.8f && b.friction(PhysicsTests.STONE) == 0.6f);
        T.check("water heights: source 8/9, level 3 flowing 5/9", Math.abs(b.waterOwnHeight(PhysicsTests.WATER) - 8 / 9.0) < 1e-9 && Math.abs(b.waterOwnHeight(PhysicsTests.WATER + 3) - 5 / 9.0) < 1e-9);
    }

    static boolean hasKind(Pathfinder.Result r, Pathfinder.Kind k) { for (Pathfinder.Step st : r.steps) if (st.kind == k) return true; return false; }

    static void planning() {
        T.suite("planning: goals drive A*, stairs/slabs need real shapes");
        World w = PhysicsTests.flat(4, true);
        for (int x = 0; x <= 28; x++) for (int y = 5; y <= 8; y++) { w.set(x, y, 3, PhysicsTests.STONE); w.set(x, y, 1, PhysicsTests.STONE); }
        w.set(14, 5, 2, PhysicsTests.SLAB + 3);   // bottom slab in a one-wide corridor (z = 2, walls at z = 1 and 3)
        NavConfig cfg = new NavConfig();
        Pathfinder.Result r = Pathfinder.find(w, 1, 5, 2, new Goals.GoalBlock(27, 5, 2), cfg);
        T.check("through a bottom slab: complete path of walking steps, no jump (" + r.steps.size() + " steps)", r.complete && !hasKind(r, Pathfinder.Kind.JUMP) && r.steps.size() == 26);
        World plain = PhysicsTests.flat(4, false);
        for (int x = 0; x <= 28; x++) for (int y = 5; y <= 8; y++) { plain.set(x, y, 3, PhysicsTests.STONE); plain.set(x, y, 1, PhysicsTests.STONE); }
        plain.set(14, 5, 2, PhysicsTests.SLAB + 3);
        Pathfinder.Result r2 = Pathfinder.find(plain, 1, 5, 2, new Goals.GoalBlock(27, 5, 2), cfg);
        T.check("without shapes a slab is an obstacle that cannot be stood on: the corridor stays blocked (incomplete path)", !r2.complete);
        T.check("feetY: standing on a slab is 0.5 lower than on a full block", Math.abs(w.feetY(14, 6, 2) - 5.5) < 1e-9 && Math.abs(w.feetY(14, 5, 2) - 5.5) < 1e-9 && Math.abs(w.feetY(1, 5, 2) - 5.0) < 1e-9);

        World open = PhysicsTests.flat(4, false);
        Pathfinder.Result g1 = Pathfinder.find(open, 0, 5, 0, new Goals.GoalXZ(10, 0), new NavConfig());
        T.check("GoalXZ: a straight 10 block walk", g1.complete && g1.steps.size() == 10);
        Pathfinder.Result g2 = Pathfinder.find(open, 0, 5, 0, new Goals.GoalNear(10, 5, 0, 3), new NavConfig());
        T.check("GoalNear: stops 3 blocks short (7 steps)", g2.complete && g2.steps.size() == 7);
        Pathfinder.Result g3 = Pathfinder.find(open, 0, 5, 0, new Goals.GoalGetToBlock(10, 5, 0), new NavConfig());
        T.check("GoalGetToBlock: ends right next to the block (9 steps)", g3.complete && g3.steps.size() == 9);
        Pathfinder.Result g4 = Pathfinder.find(open, 0, 5, 0, new Goals.GoalComposite(new Goals.GoalBlock(0, 5, 20), new Goals.GoalBlock(5, 5, 0)), new NavConfig());
        T.check("GoalComposite: takes the nearer goal (5 steps)", g4.complete && g4.steps.size() == 5);
        World wall = PhysicsTests.flat(4, false);
        for (int z = -30; z <= 30; z++) for (int y = 5; y <= 8; y++) wall.set(5, y, z & 31, PhysicsTests.STONE);
        Pathfinder.Result g5 = Pathfinder.find(wall, 0, 5, 0, new Goals.GoalBlock(9, 5, 0), new NavConfig());
        T.check("an unreachable goal still gives a path to the closest cell (incomplete)", !g5.complete && !g5.steps.isEmpty());
    }

    static Data.Blocks registryRows() { return PhysicsTests.registry(false); }
}
