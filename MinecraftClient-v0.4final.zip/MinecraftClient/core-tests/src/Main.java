public final class Main {
    public static void main(String[] args) throws Exception {
        if (args.length > 0 && args[0].startsWith("ob:")) {
            ObstacleTests.class.getDeclaredMethod(args[0].substring(3)).invoke(null);
        } else if (args.length > 0 && args[0].equals("integration")) {
            IntegrationTests.run();
        } else if (args.length > 0 && args[0].equals("obstacle")) {
            ObstacleTests.integration();
        } else if (args.length > 0 && args[0].equals("fidelity")) {
            FidelityTests.run();
        } else if (args.length > 0 && args[0].equals("move")) {
            MoveTests.run();
        } else if (args.length > 0 && args[0].startsWith("it:")) {
            IntegrationTests.class.getDeclaredMethod(args[0].substring(3)).invoke(null);
        } else {
            UnitTests.run();
            LayoutTests.run();
            ChatEventTests.run();
            PhysicsTests.run();
            GoalTests.run();
            ObstacleTests.unit();
            RenderTest.run(System.getProperty("render.out", "/tmp/render/chat-layout.png"));
            if (args.length > 0 && args[0].equals("all")) { IntegrationTests.run(); ObstacleTests.integration(); MoveTests.run(); FidelityTests.run(); }
        }
        T.done();
    }
}
