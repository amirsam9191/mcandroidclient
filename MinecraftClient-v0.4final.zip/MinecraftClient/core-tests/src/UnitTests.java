import com.mcclient.core.*;
import java.io.*;
import java.util.*;

/** Unit tests for the protocol primitives, chat parser, world model, path finder and physics. */
public final class UnitTests {
    static void run() throws Exception {
        buffers(); nbt(); json(); chat(); framing(); paletted(); data(); world(); pathfinding();
    }

    static void buffers() {
        T.suite("buffers");
        int[] ints = {0, 1, 127, 128, 255, 300, 25565, 2097151, Integer.MAX_VALUE, -1, Integer.MIN_VALUE};
        boolean ok = true;
        for (int v : ints) {
            Buf.Reader r = new Buf.Reader(new Buf.Writer().varInt(v).toBytes());
            if (r.varInt() != v) ok = false;
        }
        T.check("varInt round trip (incl. negatives)", ok);
        T.eq("varInt 300 bytes", Arrays.toString(new Buf.Writer().varInt(300).toBytes()), "[-84, 2]");
        long[] longs = {0L, 1L, Long.MAX_VALUE, Long.MIN_VALUE, -123456789012L};
        ok = true;
        for (long v : longs) { if (new Buf.Reader(new Buf.Writer().varLong(v).toBytes()).varLong() != v) ok = false; }
        T.check("varLong round trip", ok);
        Buf.Writer w = new Buf.Writer().str("سلام Steve").i32(-5).i64(-9L).f32(1.5f).f64(-2.25).s16(65535).bool(true).uuid(new UUID(1, 2));
        Buf.Reader r = new Buf.Reader(w.toBytes());
        T.eq("string utf8", r.str(), "سلام Steve");
        T.eq("int", r.i32(), -5);
        T.eq("long", r.i64(), -9L);
        T.eq("float", r.f32(), 1.5f);
        T.eq("double", r.f64(), -2.25);
        T.eq("u16", r.u16(), 65535);
        T.eq("bool", r.bool(), true);
        T.eq("uuid", r.uuid(), new UUID(1, 2));
        T.eq("fully consumed", r.remaining(), 0);
        boolean threw = false;
        try { new Buf.Reader(new byte[]{1}).i32(); } catch (Buf.ParseEx e) { threw = true; }
        T.check("short read throws ParseEx", threw);
    }

    @SuppressWarnings("unchecked")
    static void nbt() {
        T.suite("nbt");
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("text", "hi");
        m.put("b", (byte) 1);
        m.put("s", (short) -3);
        m.put("i", 70000);
        m.put("l", 1L << 40);
        m.put("f", 2.5f);
        m.put("d", 3.5);
        m.put("arr", new int[]{1, 2, 3});
        m.put("la", new long[]{9L});
        m.put("ba", new byte[]{1, 2});
        List<Object> list = new ArrayList<>();
        list.add("a"); list.add("b");
        m.put("extra", list);
        Map<String, Object> inner = new LinkedHashMap<>();
        inner.put("k", "v");
        m.put("inner", inner);
        byte[] bytes = new Buf.Writer().nbt(m).toBytes();
        Object back = new Buf.Reader(bytes).nbt();
        Map<String, Object> bm = (Map<String, Object>) back;
        T.eq("compound text", bm.get("text"), "hi");
        T.eq("byte", bm.get("b"), (byte) 1);
        T.eq("short", bm.get("s"), (short) -3);
        T.eq("int", bm.get("i"), 70000);
        T.eq("long", bm.get("l"), 1L << 40);
        T.eq("list", bm.get("extra"), list);
        T.eq("nested compound", ((Map<String, Object>) bm.get("inner")).get("k"), "v");
        T.check("int array", Arrays.equals((int[]) bm.get("arr"), new int[]{1, 2, 3}));
        T.eq("root TAG_End is null", new Buf.Reader(new byte[]{0}).nbt(), null);
        T.eq("root string tag", new Buf.Reader(new Buf.Writer().nbt("plain").toBytes()).nbt(), "plain");
        boolean threw = false;
        try { new Buf.Reader(new byte[]{99}).nbt(); } catch (Buf.ParseEx e) { threw = true; }
        T.check("bad tag throws", threw);
    }

    @SuppressWarnings("unchecked")
    static void json() {
        T.suite("json");
        Map<String, Object> m = (Map<String, Object>) Json.parse("{\"a\":[1,2.5,{\"b\":null}],\"c\":\"x\\ny\\u0041\",\"d\":true}");
        T.eq("string escapes", m.get("c"), "x\nyA");
        T.eq("bool", m.get("d"), Boolean.TRUE);
        List<Object> a = (List<Object>) m.get("a");
        T.eq("number", a.get(1), 2.5);
        T.check("null member", ((Map<String, Object>) a.get(2)).containsKey("b"));
        boolean threw = false;
        try { Json.parse("{\"a\":}"); } catch (RuntimeException e) { threw = true; }
        T.check("malformed JSON rejected", threw);
    }

    static String plain(List<Chat.Span> l) { StringBuilder sb = new StringBuilder(); for (Chat.Span s : l) sb.append(s.text); return sb.toString(); }

    @SuppressWarnings("unchecked")
    static void chat() {
        T.suite("chat");
        Map<String, Object> comp = new LinkedHashMap<>();
        comp.put("translate", "chat.type.text");
        Map<String, Object> sender = new LinkedHashMap<>();
        sender.put("text", "Ali"); sender.put("color", "green");
        comp.put("with", Arrays.asList(sender, "سلام hello"));
        List<Chat.Span> spans = Chat.fromAny(comp);
        T.eq("vanilla chat format", plain(spans), "<Ali> سلام hello");
        T.eq("sender colour kept", spans.get(1).color, Chat.LEGACY[10]);
        T.eq("message is white", spans.get(spans.size() - 1).color, Chat.WHITE);

        Map<String, Object> extra = new LinkedHashMap<>();
        extra.put("text", "Hello ");
        extra.put("bold", (byte) 1);
        extra.put("color", "#FF8800");
        extra.put("extra", Arrays.asList("world", new LinkedHashMap<String, Object>() {{ put("text", "!"); put("bold", false); }}));
        List<Chat.Span> s2 = Chat.fromAny(extra);
        T.eq("extra flattening", plain(s2), "Hello world!");
        T.check("bold inherited by child string", s2.get(1).bold);
        T.check("bold overridden by child", !s2.get(2).bold);
        T.eq("hex colour", s2.get(0).color, 0xFFFF8800);

        List<Chat.Span> leg = Chat.legacy("\u00A7aGreen\u00A7lBold\u00A7rPlain\u00A7cRed");
        T.eq("legacy codes plain text", plain(leg), "GreenBoldPlainRed");
        T.eq("legacy colour", leg.get(0).color, Chat.LEGACY[10]);
        T.check("legacy bold", leg.get(1).bold);
        T.check("legacy reset", !leg.get(2).bold && leg.get(2).color == Chat.WHITE);
        T.eq("legacy red", leg.get(3).color, Chat.LEGACY[12]);

        T.eq("positional args", plain(Chat.fromAny(new LinkedHashMap<String, Object>() {{
            put("translate", "death.attack.player"); put("with", Arrays.asList("A", "B")); }})), "A was slain by B");
        T.eq("unknown key shows key", plain(Chat.fromAny(new LinkedHashMap<String, Object>() {{
            put("translate", "mod.unknown.key"); put("with", Arrays.asList("x")); }})), "mod.unknown.key x");
        T.eq("json login disconnect", Chat.plainFromJsonText("{\"text\":\"Banned: \",\"extra\":[{\"text\":\"cheating\"}]}"), "Banned: cheating");
        T.eq("json quoted string", Chat.plainFromJsonText("\"hi\""), "hi");
        T.eq("garbage falls back to text", Chat.plainFromJsonText("not json"), "not json");
    }

    static void framing() throws Exception {
        T.suite("framing");
        for (int th : new int[]{-1, 0, 64, 256}) {
            ByteArrayOutputStream wire = new ByteArrayOutputStream();
            Framing.Conn sender = new Framing.Conn(new ByteArrayInputStream(new byte[0]), wire);
            sender.threshold = th;
            byte[] big = new byte[3000];
            for (int i = 0; i < big.length; i++) big[i] = (byte) (i % 7);
            byte[] small = {1, 2, 3};
            sender.send(0x25, big);
            sender.send(0x03, small);
            sender.send(0x00);
            Framing.Conn receiver = new Framing.Conn(new ByteArrayInputStream(wire.toByteArray()), new ByteArrayOutputStream());
            receiver.threshold = th;
            Framing.Incoming a = receiver.read(), b = receiver.read(), c = receiver.read();
            T.check("threshold " + th + ": large packet intact", a.id == 0x25 && Arrays.equals(a.r.bytes(a.r.remaining()), big));
            T.check("threshold " + th + ": small packet intact", b.id == 0x03 && Arrays.equals(b.r.bytes(b.r.remaining()), small));
            T.check("threshold " + th + ": empty packet", c.id == 0x00 && c.r.remaining() == 0);
            if (th >= 0 && th <= 256) T.check("threshold " + th + ": big packet is actually compressed", wire.size() < 1500);
        }
        boolean threw = false;
        try { new Framing.Conn(new ByteArrayInputStream(new byte[]{0x05, 1, 2}), new ByteArrayOutputStream()).read(); } catch (IOException e) { threw = true; }
        T.check("truncated stream -> IOException", threw);
        Object[] a = Framing.parseAddress("play.example.com");
        T.check("address default port", a[0].equals("play.example.com") && a[1].equals(25565));
        a = Framing.parseAddress(" play.example.com:25566 ");
        T.check("address explicit port", a[0].equals("play.example.com") && a[1].equals(25566));
        a = Framing.parseAddress("[::1]:1234");
        T.check("ipv6 with port", a[0].equals("::1") && a[1].equals(1234));
        a = Framing.parseAddress("host:99999");
        T.check("invalid port -> default", a[1].equals(25565));
    }

    /** Independent encoder of a paletted container, following the wiki description of the format. */
    static byte[] encodeContainer(int[] vals, int bits, int[] palette, boolean single) {
        Buf.Writer w = new Buf.Writer();
        if (single) { w.b(0).varInt(vals[0]).varInt(0); return w.toBytes(); }
        w.b(bits);
        if (palette != null) { w.varInt(palette.length); for (int p : palette) w.varInt(p); }
        int per = 64 / bits;
        long[] words = new long[(vals.length + per - 1) / per];
        for (int i = 0; i < vals.length; i++) {
            int v = vals[i];
            if (palette != null) { int idx = -1; for (int k = 0; k < palette.length; k++) if (palette[k] == v) idx = k; v = idx; }
            words[i / per] |= ((long) v) << ((i % per) * bits);
        }
        w.varInt(words.length);
        for (long l : words) w.i64(l);
        return w.toBytes();
    }

    static void paletted() {
        T.suite("chunk data (paletted containers)");
        World w = new World();
        w.minY = 0; w.height = 32;
        int[] a = new int[4096], b = new int[4096];
        for (int i = 0; i < 4096; i++) { a[i] = (i % 3 == 0) ? 9 : 0; b[i] = (i * 37) % 15000; }
        Buf.Writer data = new Buf.Writer();
        data.s16(100).bytes(encodeContainer(a, 4, new int[]{0, 9}, false)).bytes(encodeContainer(new int[64], 0, null, true));
        data.s16(4096).bytes(encodeContainer(b, 15, null, false)).bytes(encodeContainer(new int[64], 1, new int[]{0}, false));
        w.loadChunk(2, -3, data.toBytes());
        T.check("chunk marked loaded", w.isLoaded(2 * 16, -3 * 16) && w.isLoaded(2 * 16 + 15, -3 * 16 + 15));
        T.check("neighbour not loaded", !w.isLoaded(0, 0));
        boolean ok = true;
        for (int i = 0; i < 4096; i += 13) {
            int x = i & 15, z = (i >> 4) & 15, y = i >> 8;
            if (w.get(32 + x, y, -48 + z) != a[i]) ok = false;
            if (w.get(32 + x, 16 + y, -48 + z) != b[i]) ok = false;
        }
        T.check("indirect (4-bit) + direct (15-bit) sections decode exactly", ok);
        T.eq("unloaded chunk reads -1", w.get(0, 0, 0), -1);
        T.eq("above world reads air", w.get(32, 500, -48), 0);
        w.set(33, 3, -47, 77);
        T.eq("block update applied", w.get(33, 3, -47), 77);

        Buf.Writer single = new Buf.Writer();
        single.s16(4096).bytes(encodeContainer(new int[]{5}, 0, null, true)).bytes(encodeContainer(new int[64], 0, null, true));
        single.s16(0).bytes(encodeContainer(new int[]{0}, 0, null, true)).bytes(encodeContainer(new int[64], 0, null, true));
        w.loadChunk(0, 0, single.toBytes());
        T.eq("single-value section", w.get(7, 7, 7), 5);
        T.eq("empty second section", w.get(7, 20, 7), 0);

        boolean threw = false;
        try { w.loadChunk(9, 9, new byte[]{0, 5, 4, 1}); } catch (Buf.ParseEx e) { threw = true; }
        T.check("corrupt chunk data rejected, not stored", threw && !w.isLoaded(9 * 16, 9 * 16));

        long pos = ((long) (-123 & 0x3FFFFFF) << 38) | ((long) (4567 & 0x3FFFFFF) << 12) | (-60 & 0xFFF);
        T.check("packed block position decode", World.posX(pos) == -123 && World.posZ(pos) == 4567 && World.posY(pos) == -60);
    }

    static void data() {
        T.suite("registry data");
        String blocks = "[{\"id\":0,\"name\":\"air\",\"minStateId\":0,\"maxStateId\":0,\"boundingBox\":\"empty\"},"
            + "{\"id\":1,\"name\":\"stone\",\"minStateId\":1,\"maxStateId\":1,\"boundingBox\":\"block\"},"
            + "{\"id\":2,\"name\":\"water\",\"minStateId\":80,\"maxStateId\":95,\"boundingBox\":\"empty\"},"
            + "{\"id\":3,\"name\":\"oak_slab\",\"minStateId\":100,\"maxStateId\":105,\"boundingBox\":\"block\"},"
            + "{\"id\":4,\"name\":\"lava\",\"minStateId\":110,\"maxStateId\":125,\"boundingBox\":\"empty\"},"
            + "{\"id\":5,\"name\":\"short_grass\",\"minStateId\":130,\"maxStateId\":130,\"boundingBox\":\"empty\"}]";
        Data.Blocks b = Data.Blocks.parse(blocks);
        T.check("air passable, not standable", b.isPassable(0) && !b.isStandable(0));
        T.check("stone standable, obstacle", b.isStandable(1) && b.isObstacle(1) && !b.isPassable(1));
        T.check("water state range: not passable, liquid", !b.isPassable(88) && b.isLiquid(88));
        T.check("slab is an obstacle but not standable", b.isObstacle(103) && !b.isStandable(103));
        T.check("lava never passable", !b.isPassable(115));
        T.check("grass passable", b.isPassable(130));
        T.eq("name lookup inside range", b.nameOf(94), "water");
        T.check("unknown state treated as solid", !b.isPassable(500) && b.isStandable(500));
        T.check("unloaded (-1) never passable", !b.isPassable(-1));
        Data.Items it = Data.Items.parse("[{\"id\":1,\"name\":\"stone\"},{\"id\":796,\"name\":\"diamond_sword\"}]");
        T.eq("item name by id", it.name(796), "diamond_sword");
        T.eq("unknown item id", it.name(5), null);
    }

    static World flat(int cx0, int cz0, int cx1, int cz1, int floorY) {
        World w = new World();
        w.minY = 0; w.height = 64;
        for (int cx = cx0; cx <= cx1; cx++) for (int cz = cz0; cz <= cz1; cz++) w.ensureChunk(cx, cz);
        for (int x = cx0 * 16; x < cx1 * 16 + 16; x++)
            for (int z = cz0 * 16; z < cz1 * 16 + 16; z++)
                for (int y = 0; y <= floorY; y++) w.set(x, y, z, 1);
        return w;
    }

    static void world() {
        T.suite("world queries");
        World w = flat(0, 0, 0, 0, 4);
        T.check("can stand on flat floor", w.canStand(3, 5, 3));
        T.check("cannot stand inside floor", !w.canStand(3, 4, 3));
        w.set(3, 5, 3, 1);
        T.check("block in feet cell blocks standing", !w.canStand(3, 5, 3));
        T.check("unloaded column is not passable", !w.passable(100, 5, 100));
    }

    static NavConfig cfg() { return new NavConfig(); }

    static void pathfinding() {
        T.suite("path finder");
        World w = flat(0, 0, 1, 1, 4);
        Pathfinder.Result r = Pathfinder.find(w, 2, 5, 2, 20, 5, 9, false, 0, cfg());
        T.check("flat: reaches goal", r.complete && r.path.get(r.path.size() - 1)[0] == 20 && r.path.get(r.path.size() - 1)[2] == 9);
        T.check("flat: optimal length uses diagonals (<= 18 steps)", r.path.size() <= 18);
        boolean ok = true;
        int[] prev = {2, 5, 2};
        for (int[] p : r.path) { if (Math.abs(p[0] - prev[0]) > 1 || Math.abs(p[2] - prev[2]) > 1 || !w.canStand(p[0], p[1], p[2])) ok = false; prev = p; }
        T.check("flat: every step adjacent and standable", ok);

        // wall with a gap
        World w2 = flat(0, 0, 1, 0, 4);
        for (int y = 5; y <= 9; y++) for (int z = 0; z < 16; z++) if (z != 12) w2.set(10, y, z, 1);
        r = Pathfinder.find(w2, 2, 5, 2, 20, 5, 2, false, 0, cfg());
        boolean through = false;
        for (int[] p : r.path) if (p[0] == 10) through = (p[2] == 12);
        T.check("wall: routes through the only gap", r.complete && through);

        // staircase up by jumping
        World w3 = flat(0, 0, 0, 0, 4);
        for (int i = 0; i < 4; i++) for (int x = 6 + i * 2; x < 16; x++) for (int z = 0; z < 16; z++) w3.set(x, 5 + i, z, 1);
        r = Pathfinder.find(w3, 2, 5, 5, 14, 9, 5, false, 0, cfg());
        T.check("stairs: climbs by 1-block jumps", r.complete && r.path.get(r.path.size() - 1)[1] == 9);
        NavConfig noJump = cfg(); noJump.allowJump = false;
        r = Pathfinder.find(w3, 2, 5, 5, 14, 9, 5, false, 0, noJump);
        T.check("stairs: jumping disabled -> cannot reach (partial path only)", !r.complete);

        // drops
        World w4 = flat(0, 0, 0, 0, 4);
        for (int x = 0; x < 8; x++) for (int z = 0; z < 16; z++) for (int y = 5; y <= 7; y++) w4.set(x, y, z, 1);
        r = Pathfinder.find(w4, 3, 8, 5, 12, 5, 5, false, 0, cfg());
        T.check("drop of 3 blocks allowed", r.complete);
        NavConfig noFall = cfg(); noFall.maxFall = 1;
        r = Pathfinder.find(w4, 3, 8, 5, 12, 5, 5, false, 0, noFall);
        T.check("drop of 3 blocks refused when maxFall=1", !r.complete);

        // lava is avoided
        World w5 = flat(0, 0, 0, 0, 4);
        Data.Blocks b = Data.Blocks.parse("[{\"id\":0,\"name\":\"air\",\"minStateId\":0,\"maxStateId\":0,\"boundingBox\":\"empty\"},"
            + "{\"id\":1,\"name\":\"stone\",\"minStateId\":1,\"maxStateId\":1,\"boundingBox\":\"block\"},"
            + "{\"id\":2,\"name\":\"magma_block\",\"minStateId\":2,\"maxStateId\":2,\"boundingBox\":\"block\"}]");
        w5.blocks = b;
        for (int z = 0; z < 16; z++) w5.set(8, 4, z, 2); // a line of magma floor
        w5.set(8, 4, 3, 1);                              // with one safe stone
        r = Pathfinder.find(w5, 2, 5, 3, 14, 5, 3, false, 0, cfg());
        boolean crossedSafe = false, crossedMagma = false;
        for (int[] p : r.path) if (p[0] == 8) { if (p[2] == 3) crossedSafe = true; else crossedMagma = true; }
        T.check("dangerous floor avoided", r.complete && crossedSafe && !crossedMagma);

        // unreachable -> partial path toward the goal
        World w6 = flat(0, 0, 0, 0, 4);
        for (int y = 5; y <= 8; y++) for (int z = 0; z < 16; z++) w6.set(8, y, z, 1);
        r = Pathfinder.find(w6, 2, 5, 5, 14, 5, 5, false, 0, cfg());
        T.check("walled-off goal: partial path ends next to the wall", !r.complete && !r.path.isEmpty() && r.path.get(r.path.size() - 1)[0] == 7);
        r = Pathfinder.find(w, 2, 5, 2, 10, 5, 10, true, 2.0, cfg());
        T.check("goal radius honoured", r.complete && Math.hypot(r.path.get(r.path.size() - 1)[0] - 10, r.path.get(r.path.size() - 1)[2] - 10) <= 2.0);
        long t0 = System.nanoTime();
        World big = flat(0, 0, 7, 7, 4);
        r = Pathfinder.find(big, 1, 5, 1, 120, 5, 120, false, 0, cfg());
        long ms = (System.nanoTime() - t0) / 1_000_000;
        T.check("long path (120 diagonal blocks) found in < 1500 ms (took " + ms + " ms)", r.complete && ms < 1500);
    }
}
