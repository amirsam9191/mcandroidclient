import com.mcclient.core.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;

/** Movement packets, server-driven physics, the new actions and the manual pad — against the simulated server. */
public final class MoveTests {
    interface Body { void run(ClientSession cs, Rec rec, ObstacleTests.Stats st, MockServer ms) throws Exception; }

    static final int STONE = ObstacleTests.STONE, CHEST = ObstacleTests.CHEST;
    static final int[] NO_HOTBAR = new int[9];

    static void with(String user, ObstacleTests.SimWorld sw, int[] hotbar, double sx, double sy, double sz, Consumer<NavConfig> nav, Body body) throws Exception {
        ObstacleTests.Stats st = new ObstacleTests.Stats();
        try (MockServer ms = new MockServer(c -> ObstacleTests.simulate(c, sw, hotbar, st, sx, sy, sz))) {
            Rec rec = new Rec();
            ClientSession cs = ObstacleTests.session(rec, ms, user, nav);
            T.check("ready (" + user + ")", Rec.waitFor(() -> cs.world.chunkCount() == 25 && cs.hasPosition(), 8000));
            try { body.run(cs, rec, st, ms); } finally { cs.disconnect(); }
        }
    }

    static ObstacleTests.SimWorld flat() { return new ObstacleTests.SimWorld((x, y, z) -> y <= 4 ? STONE : 0); }

    static void hold(ClientSession cs, float f, float s, boolean jump, boolean sneak, boolean sprint, int ms) throws Exception {
        long end = System.currentTimeMillis() + ms;
        while (System.currentTimeMillis() < end) { cs.manualMove(f, s, jump, sneak, sprint); Thread.sleep(100); }
        cs.manualMove(0, 0, false, false, false);
    }

    static boolean cmd(ObstacleTests.Stats st, int action) { synchronized (st.commands) { for (int[] c : st.commands) if (c[0] == action) return true; } return false; }

    static void run() throws Exception {
        T.suite("session: movement packets like LocalPlayer.sendPosition");
        with("Packets", flat(), NO_HOTBAR, 0.5, 5, 0.5, n -> { }, (cs, rec, st, ms) -> {
            Thread.sleep(1500);
            MockServer.Tracker tr = st.tracker;
            int pos0 = tr.posPackets + tr.posRotPackets, rot0 = tr.rotPackets, gr0 = tr.groundPackets;
            Thread.sleep(3200);
            int reminders = tr.posPackets + tr.posRotPackets - pos0;
            T.check("standing still: only the 1 Hz position reminder (" + reminders + " packets in 3.2 s)", reminders >= 2 && reminders <= 5);
            T.check("standing still: no rotation / on-ground spam (" + (tr.rotPackets - rot0) + "/" + (tr.groundPackets - gr0) + ")", tr.rotPackets - rot0 == 0 && tr.groundPackets - gr0 == 0);
            T.check("standing on the ground (onGround flag) at y=5", tr.ground && Math.abs(st.y - 5) < 1e-6);
            int pr0 = tr.posRotPackets, p0 = tr.posPackets;
            hold(cs, 1, 0, false, false, true, 1500);
            T.check("pad forward + sprint moves the player (z=" + String.format("%.2f", st.z) + ")", st.z > 3);
            T.check("sprinting is announced with Player Command 3 and ended with 4", cmd(st, 3) && Rec.waitFor(() -> cmd(st, 4), 2000));
            T.check("moving without turning sends plain Pos packets (" + (tr.posPackets - p0) + ") and no PosRot spam (" + (tr.posRotPackets - pr0) + ")", tr.posPackets - p0 > 10 && tr.posRotPackets - pr0 <= 2);
            cs.manualTurn(90, 0);
            T.check("turning sends a Rot / PosRot packet", Rec.waitFor(() -> tr.rotPackets > 0 || Math.abs(tr.yaw) > 80, 2000));
            hold(cs, 0, 0, false, true, false, 600);
            T.check("sneaking sends Player Command 0, releasing it 1", cmd(st, 0) && Rec.waitFor(() -> cmd(st, 1), 2000));
            T.check("no violations while moving", st.violations.isEmpty());
        });

        T.suite("session: server-driven motion (velocity, explosion, attributes, effects, abilities)");
        with("Inbound", flat(), NO_HOTBAR, 0.5, 5, 0.5, n -> { }, (cs, rec, st, ms) -> {
            Thread.sleep(1200);
            double x0 = st.x;
            st.client.send(0x58, new Buf.Writer().varInt(7).s16(4000).s16(0).s16(0));
            T.check("Set Entity Velocity (÷8000) pushes the player along +X", Rec.waitFor(() -> st.x > x0 + 0.5, 3000));
            Thread.sleep(2500); // let the push die out
            double x1 = st.x;
            st.client.send(0x58, new Buf.Writer().varInt(99).s16(4000).s16(0).s16(0));
            Thread.sleep(800);
            T.check("velocity of another entity is ignored", Math.abs(st.x - x1) < 0.05);
            double y0 = st.y;
            st.client.send(0x1E, new Buf.Writer().f64(5).f64(5).f64(5).f32(4f).varInt(2).b(0).b(0).b(0).b(1).b(0).b(0).f32(0f).f32(0.8f).f32(0f));
            T.check("Explosion knockback lifts the player", Rec.waitFor(() -> st.y > y0 + 0.5, 3000));
            T.check("...and he lands again on y=5", Rec.waitFor(() -> Math.abs(st.y - 5) < 1e-6 && st.tracker.ground, 4000));
        });
        with("Attrib", flat(), NO_HOTBAR, 0.5, 5, 0.5, n -> { }, (cs, rec, st, ms) -> {
            Thread.sleep(1200);
            double a0 = st.z; hold(cs, 1, 0, false, false, false, 1000); double normal = st.z - a0;
            Thread.sleep(700);
            Buf.Writer w = new Buf.Writer().varInt(7).varInt(1).str("minecraft:generic.movement_speed").f64(0.2).varInt(1)
                .uuid(Physics.SPRINT_MODIFIER).f64(0.3).b(2);
            st.client.send(0x71, w);
            Thread.sleep(300);
            double b0 = st.z; hold(cs, 1, 0, false, false, false, 1000); double fast = st.z - b0;
            T.check("Update Attributes: movement_speed 0.2 (sprint modifier ignored) doubles the walk (" + String.format("%.2f -> %.2f", normal, fast) + ")", fast > normal * 1.6 && fast < normal * 2.4);
        });
        with("Effect", flat(), NO_HOTBAR, 0.5, 5, 0.5, n -> { }, (cs, rec, st, ms) -> {
            Thread.sleep(1200);
            double[] max = new double[1];
            Thread t = new Thread(() -> { while (!Thread.currentThread().isInterrupted()) { max[0] = Math.max(max[0], st.y); try { Thread.sleep(10); } catch (InterruptedException e) { return; } } });
            t.start();
            hold(cs, 0, 0, true, false, false, 150);
            Thread.sleep(1200);
            double plain = max[0] - 5; max[0] = 0;
            st.client.send(0x72, new Buf.Writer().varInt(7).varInt(8).b(1).varInt(600).b(0).bool(false));
            Thread.sleep(300);
            hold(cs, 0, 0, true, false, false, 150);
            Thread.sleep(1200);
            double boosted = max[0] - 5;
            T.check("Entity Effect jump boost II (id 8) raises the jump (" + String.format("%.2f -> %.2f", plain, boosted) + ")", plain > 1.1 && plain < 1.4 && boosted > plain + 0.4);
            max[0] = 0;
            st.client.send(0x41, new Buf.Writer().varInt(7).varInt(8));
            Thread.sleep(300);
            hold(cs, 0, 0, true, false, false, 150);
            Thread.sleep(1200);
            T.check("Remove Entity Effect restores the normal jump (" + String.format("%.2f", max[0] - 5) + ")", Math.abs(max[0] - 5 - plain) < 0.2);
            t.interrupt();
        });
        with("Fly", flat(), NO_HOTBAR, 0.5, 5, 0.5, n -> { }, (cs, rec, st, ms) -> {
            Thread.sleep(1200);
            cs.setFlying(true);
            Thread.sleep(500);
            T.check("flying without permission is refused (no abilities packet, still on the ground)", st.abilityFlags.isEmpty() && Math.abs(st.y - 5) < 1e-6);
            cs.startAction(new Actions.FlyTo(20.5, 12, 0.5));
            T.check("FlyTo without permission says so", Rec.waitFor(() -> rec.actionStatus.contains("این سرور اجازهٔ پرواز نمی‌دهد"), 3000));
            st.client.send(0x36, new Buf.Writer().b(0x0C).f32(0.05f).f32(0.1f));
            T.check("Player Abilities: mayfly", Rec.waitFor(cs::mayFly, 2000));
            cs.setFlying(true);
            T.check("starting flight sends Player Abilities with the flying flag (0x02)", Rec.waitFor(() -> st.abilityFlags.contains(2), 3000));
            hold(cs, 0, 0, true, false, false, 1200);
            Thread.sleep(600);
            double hover = st.y; Thread.sleep(800);
            T.check("flying: no gravity (hovers at y=" + String.format("%.2f", st.y) + ")", st.y > 7 && Math.abs(st.y - hover) < 0.05);
            double fz = st.z;
            hold(cs, 1, 0, false, false, false, 1000);
            T.check("flying forward is fast (" + String.format("%.1f", st.z - fz) + " blocks in 1 s, walking is 4.3)", st.z - fz > 5);
            hold(cs, 0, 0, false, true, false, 3000);
            T.check("sneaking descends and landing ends the flight (reported with 0x20 flags 0)", Rec.waitFor(() -> Math.abs(st.y - 5) < 1e-6 && st.abilityFlags.contains(0), 6000));
            T.check("never inside a block (flying is allowed to be faster than the walking speed limit): " + st.violations, st.violations.stream().noneMatch(v -> v.startsWith("inside")));
        });
        with("FlyTo", flat(), NO_HOTBAR, 0.5, 5, 0.5, n -> { }, (cs, rec, st, ms) -> {
            Thread.sleep(1200);
            st.client.send(0x36, new Buf.Writer().b(0x04).f32(0.05f).f32(0.1f));
            T.check("mayfly set", Rec.waitFor(cs::mayFly, 2000));
            cs.startAction(new Actions.FlyTo(24.5, 9, 0.5));
            T.check("FlyTo reaches the target (x=" + String.format("%.1f", st.x) + ", y=" + String.format("%.1f", st.y) + ")", Rec.waitFor(() -> rec.actionStatus.contains("به مقصد رسیدید"), 12000) && st.x > 22);
        });

        T.suite("actions: open a block with a screen, mine, explore, waypoints, auto-eat");
        ObstacleTests.SimWorld chestWorld = new ObstacleTests.SimWorld((x, y, z) -> y <= 4 ? STONE : (x == 8 && y == 5 && z == 0 ? CHEST : 0));
        with("Chest", chestWorld, NO_HOTBAR, 0.5, 5, 0.5, n -> { }, (cs, rec, st, ms) -> {
            cs.startAction(new Actions.OpenBlock("chest"));
            T.check("OpenBlock walks to the chest and right-clicks it until the screen opens", Rec.waitFor(() -> cs.inventory.open() != null, 20000) && st.chestUses >= 1);
            T.eq("the opened screen is the 9x3 container", cs.inventory.open().type, 2);
            T.check("the action reports success", Rec.waitFor(() -> rec.actionStatus.contains("باز شد"), 3000));
            T.check("stood next to the chest (x=" + String.format("%.2f", st.x) + ")", Math.abs(st.x - 8.5) <= 2.0);
            T.check("no violations", st.violations.isEmpty());
        });
        with("NoTable", chestWorld, NO_HOTBAR, 0.5, 5, 0.5, n -> { }, (cs, rec, st, ms) -> {
            cs.startAction(new Actions.OpenBlock("crafting_table"));
            T.check("a block that does not exist nearby is reported", Rec.waitFor(() -> { synchronized (rec.actionStatus) { for (String s : rec.actionStatus) if (s.contains("پیدا نشد")) return true; } return false; }, 5000));
            T.check("...and nothing was clicked", st.chestUses == 0);
        });
        ObstacleTests.SimWorld ore = new ObstacleTests.SimWorld((x, y, z) -> y <= 4 ? STONE : ((x == 4 || x == 6) && y == 5 && z == 0 ? ObstacleTests.DIRT : 0));
        with("Miner", ore, NO_HOTBAR, 0.5, 5, 0.5, n -> { }, (cs, rec, st, ms) -> {
            cs.startAction(new Actions.Mine("dirt", new String[]{"dirt"}, 2));
            T.check("Mine digs the requested number of blocks", Rec.waitFor(() -> st.digs.size() >= 2, 30000));
            T.check("...exactly the two dirt blocks", st.digs.contains("4,5,0") && st.digs.contains("6,5,0") && st.digs.size() == 2);
            T.check("...and finishes", Rec.waitFor(() -> { synchronized (rec.actionStatus) { for (String s : rec.actionStatus) if (s.contains("بلاک کنده شد")) return true; } return false; }, 8000));
            T.check("no violations", st.violations.isEmpty());
        });
        with("Explorer", flat(), NO_HOTBAR, 0.5, 5, 0.5, n -> { }, (cs, rec, st, ms) -> {
            cs.startAction(new Actions.Explore());
            T.check("Explore leaves the start area (x=" + String.format("%.1f", st.x) + ", z=" + String.format("%.1f", st.z) + ")", Rec.waitFor(() -> Math.hypot(st.x - 0.5, st.z - 0.5) > 8, 25000));
            T.check("...without violations", st.violations.isEmpty());
            cs.stopAction();
        });
        with("Points", flat(), NO_HOTBAR, 0.5, 5, 0.5, n -> { }, (cs, rec, st, ms) -> {
            cs.saveWaypoint("home");
            T.check("a waypoint stores the current cell", Arrays.equals(cs.waypoints().get("home"), new int[]{0, 5, 0}));
            cs.setWaypoint("far", 9, 5, 4);
            cs.startAction(Actions.goToWaypoint("far", cs.waypoints().get("far")));
            T.check("going to a waypoint", Rec.waitFor(() -> ObstacleTests.arrived(rec), 20000) && Math.abs(st.x - 9.5) < 2 && Math.abs(st.z - 4.5) < 2);
            cs.deleteWaypoint("far");
            T.check("waypoints can be deleted", cs.waypoints().size() == 1);
        });
        int[] apple = new int[9]; apple[3] = 5;
        with("Eater", flat(), apple, 0.5, 5, 0.5, n -> n.autoEat = true, (cs, rec, st, ms) -> {
            Thread.sleep(500);
            st.client.send(0x5B, new Buf.Writer().f32(20f).varInt(8).f32(0f));
            T.check("hungry (food 8): the best food is selected from the hotbar", Rec.waitFor(() -> st.held.contains(3), 4000));
            T.check("...and eaten with Use Item", Rec.waitFor(() -> !st.useItems.isEmpty() && st.useItems.get(0) == 3, 4000));
        });
        with("NoEat", flat(), apple, 0.5, 5, 0.5, n -> { }, (cs, rec, st, ms) -> {
            Thread.sleep(500);
            st.client.send(0x5B, new Buf.Writer().f32(20f).varInt(8).f32(0f));
            Thread.sleep(2500);
            T.check("auto-eat is off by default: a hungry idle client does nothing on its own", st.useItems.isEmpty() && !st.held.contains(3));
        });
        with("Full", flat(), apple, 0.5, 5, 0.5, n -> { }, (cs, rec, st, ms) -> {
            Thread.sleep(500);
            st.client.send(0x5B, new Buf.Writer().f32(20f).varInt(20).f32(5f));
            Thread.sleep(2500);
            T.check("no eating while full", st.useItems.isEmpty());
        });
    }
}
