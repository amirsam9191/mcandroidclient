import com.mcclient.core.*;
import java.util.*;

/** Server-side helpers: runs the login/configuration phases and builds play packets by hand. */
final class Flow {
    static final int WORLD_MIN_Y = 0, WORLD_H = 64;

    static Map<String, Object> chatTypeEntry(String name, int id, String key, String... params) {
        Map<String, Object> chat = new LinkedHashMap<>();
        chat.put("translation_key", key);
        chat.put("parameters", new ArrayList<Object>(Arrays.asList((Object[]) params)));
        Map<String, Object> element = new LinkedHashMap<>();
        element.put("chat", chat);
        Map<String, Object> e = new LinkedHashMap<>();
        e.put("name", name); e.put("id", id); e.put("element", element);
        return e;
    }

    static byte[] registry() {
        Map<String, Object> chatTypes = new LinkedHashMap<>();
        chatTypes.put("type", "minecraft:chat_type");
        chatTypes.put("value", new ArrayList<Object>(Arrays.asList(
            chatTypeEntry("minecraft:chat", 0, "chat.type.text", "sender", "content"),
            chatTypeEntry("minecraft:msg_command_incoming", 1, "commands.message.display.incoming", "sender", "content"),
            chatTypeEntry("minecraft:emote_command", 2, "chat.type.emote", "sender", "content"))));
        Map<String, Object> dimEl = new LinkedHashMap<>();
        dimEl.put("min_y", WORLD_MIN_Y); dimEl.put("height", WORLD_H); dimEl.put("logical_height", WORLD_H);
        Map<String, Object> dim = new LinkedHashMap<>();
        dim.put("name", "minecraft:overworld"); dim.put("id", 0); dim.put("element", dimEl);
        Map<String, Object> dims = new LinkedHashMap<>();
        dims.put("type", "minecraft:dimension_type");
        dims.put("value", new ArrayList<Object>(Arrays.asList(dim)));
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("minecraft:chat_type", chatTypes);
        root.put("minecraft:dimension_type", dims);
        return new Buf.Writer().nbt(root).toBytes();
    }

    /** Handshake -> login -> configuration -> play Login. Asserts every packet the client sends. */
    static String joinAs(MockServer.Client c, int compression) throws Exception {
        MockServer.Pkt hs = c.expect(0x00, 3000);
        T.eq("handshake protocol version", hs.r.varInt(), 765);
        hs.r.str(); hs.r.u16();
        T.eq("handshake next state = login", hs.r.varInt(), 2);
        MockServer.Pkt ls = c.expect(0x00, 3000);
        String name = ls.r.str();
        UUID uuid = ls.r.uuid();
        T.eq("login start carries the offline UUID", uuid, MockServer.offlineUuid(name));
        if (compression >= 0) { c.send(0x03, new Buf.Writer().varInt(compression)); c.threshold = compression; }
        c.send(0x02, new Buf.Writer().uuid(uuid).str(name).varInt(0));
        c.expect(0x03, 3000); // Login Acknowledged
        // the real client sends the brand first (ClientHandshakePacketListenerImpl), then its client information
        MockServer.Pkt brand = c.expect(0x01, 3000);
        T.eq("brand channel (first, like the real client)", brand.r.str(), "minecraft:brand");
        T.eq("brand value", brand.r.str(), "vanilla");
        MockServer.Pkt info = c.expect(0x00, 3000);
        T.eq("client information: locale", info.r.str(), "en_us");
        T.eq("client information: view distance (the default render distance)", info.r.i8(), 12);
        c.send(0x05, registry());
        c.send(0x02); // Finish Configuration
        c.expect(0x02, 3000); // acknowledged
        // Login (play)
        Buf.Writer lw = new Buf.Writer().i32(7).bool(false).varInt(1).str("minecraft:overworld").varInt(20).varInt(10).varInt(10)
            .bool(false).bool(true).bool(false).str("minecraft:overworld").str("minecraft:overworld").i64(0).b(0).b(-1).bool(false).bool(false).bool(false).varInt(0);
        c.send(0x29, lw);
        return name;
    }

    static void syncPosition(MockServer.Client c, double x, double y, double z, int teleportId) throws Exception {
        c.send(0x3E, new Buf.Writer().f64(x).f64(y).f64(z).f32(0f).f32(0f).b(0).varInt(teleportId));
        MockServer.Pkt tp = c.expect(0x00, 3000);
        T.eq("teleport confirmed with the same id", tp.r.varInt(), teleportId);
        MockServer.Pkt pos = c.await(0x18, 3000);
        T.eq("position echo x", pos.r.f64(), x);
        T.eq("position echo y", pos.r.f64(), y);
    }

    // ---- packet builders

    static byte[] nbtText(String s) { return new Buf.Writer().nbt(s).toBytes(); }

    static void systemChat(MockServer.Client c, Object component, boolean overlay) throws Exception {
        c.send(0x69, new Buf.Writer().nbt(component).bool(overlay));
    }

    static Map<String, Object> comp(String text, String color) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("text", text);
        if (color != null) m.put("color", color);
        return m;
    }

    /** Chunk Data and Update Light for a chunk whose sections are given as state arrays (null = empty). */
    static void chunk(MockServer.Client c, int cx, int cz, int[][] sections) throws Exception {
        Buf.Writer data = new Buf.Writer();
        for (int[] st : sections) {
            if (st == null) { data.s16(0).bytes(UnitTests.encodeContainer(new int[]{0}, 0, null, true)); }
            else {
                int nonAir = 0; Set<Integer> pal = new TreeSet<>();
                for (int v : st) { if (v != 0) nonAir++; pal.add(v); }
                int[] palette = new int[pal.size()]; int i = 0; for (int v : pal) palette[i++] = v;
                int bits = 4; while ((1 << bits) < palette.length) bits++;
                data.s16(nonAir).bytes(UnitTests.encodeContainer(st, bits, palette, false));
            }
            data.bytes(UnitTests.encodeContainer(new int[64], 0, null, true)); // biomes
        }
        byte[] d = data.toBytes();
        Buf.Writer w = new Buf.Writer().i32(cx).i32(cz).nbt(new LinkedHashMap<String, Object>()).varInt(d.length).bytes(d)
            .varInt(0)                                   // block entities
            .varInt(0).varInt(0).varInt(0).varInt(0)     // light masks
            .varInt(0).varInt(0);                        // light arrays
        c.send(0x25, w);
    }

    /** A flat world: stone (state 1) up to and including y=floorY, in a (2r+1)^2 chunk square. */
    static int[][] flatSections(int floorY) {
        int[][] secs = new int[WORLD_H / 16][];
        for (int s = 0; s < secs.length; s++) {
            int[] st = new int[4096];
            boolean any = false;
            for (int y = 0; y < 16; y++) {
                if (s * 16 + y <= floorY) { for (int i = 0; i < 256; i++) st[(y << 8) | i] = 1; any = true; }
            }
            secs[s] = any ? st : null;
        }
        return secs;
    }

    static void sendFlatWorld(MockServer.Client c, int radius, int floorY, int... extraPillars) throws Exception {
        for (int cx = -radius; cx <= radius; cx++)
            for (int cz = -radius; cz <= radius; cz++) {
                int[][] secs = flatSections(floorY);
                chunk(c, cx, cz, secs);
            }
    }

    static void playerInfoAdd(MockServer.Client c, UUID u, String name) throws Exception {
        c.send(0x3C, new Buf.Writer().b(0x01).varInt(1).uuid(u).str(name).varInt(0));
    }
}
