package com.mcclient.core;

import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.net.ConnectException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Minecraft Java 1.20.4 (protocol 765) offline-mode client: handshake/login/configuration/play state machine,
 * chat, health, world (chunks), inventory, resource packs, auto-rejoin, startup commands and automated actions.
 * Packet ids come from the protocol 765 tables (see README).
 */
public final class ClientSession {
    public static final int PROTOCOL = 765;
    public static final int PACK_ASK = 0, PACK_ACCEPT = 1, PACK_DECLINE = 2;

    // Serverbound (play)
    static final int SB_CONFIRM_TELEPORT = 0x00, SB_ACK_MESSAGE = 0x03, SB_CHAT_COMMAND = 0x04, SB_CHAT_MESSAGE = 0x05,
        SB_CHUNK_BATCH_RECEIVED = 0x07, SB_CLIENT_STATUS = 0x08, SB_SUGGESTIONS_REQUEST = 0x0A, SB_ACK_CONFIGURATION = 0x0B,
        SB_CLICK_BUTTON = 0x0C, SB_CLICK_CONTAINER = 0x0D, SB_CLOSE_CONTAINER = 0x0E, SB_KEEP_ALIVE = 0x15, SB_POS = 0x17, SB_POS_ROT = 0x18,
        SB_ROT = 0x19, SB_ON_GROUND = 0x1A, SB_ABILITIES = 0x20, SB_PLAYER_ACTION = 0x21, SB_PLAYER_COMMAND = 0x22,
        SB_PONG = 0x24, SB_PACK_RESPONSE = 0x28, SB_SET_HELD = 0x2C, SB_SWING = 0x33, SB_USE_ON = 0x35, SB_USE_ITEM = 0x36;
    // Clientbound (play)
    static final int CB_SPAWN_ENTITY = 0x01, CB_BLOCK_UPDATE = 0x09, CB_CHUNK_BATCH_FINISHED = 0x0C, CB_SUGGESTIONS = 0x10,
        CB_CLOSE_CONTAINER = 0x12, CB_SET_CONTENT = 0x13, CB_CONTAINER_PROPERTY = 0x14, CB_SET_SLOT = 0x15, CB_DISCONNECT = 0x1B, CB_DISGUISED_CHAT = 0x1C,
        CB_EXPLOSION = 0x1E, CB_UNLOAD_CHUNK = 0x1F, CB_KEEP_ALIVE = 0x24, CB_CHUNK_DATA = 0x25, CB_LOGIN = 0x29, CB_ENTITY_POS = 0x2C,
        CB_ENTITY_POS_ROT = 0x2D, CB_OPEN_SCREEN = 0x31, CB_PING = 0x33, CB_PLAYER_CHAT = 0x37, CB_COMBAT_DEATH = 0x3A,
        CB_ABILITIES = 0x36, CB_PLAYER_INFO_REMOVE = 0x3B, CB_PLAYER_INFO_UPDATE = 0x3C, CB_SYNC_POSITION = 0x3E, CB_REMOVE_ENTITIES = 0x40, CB_REMOVE_EFFECT = 0x41,
        CB_ADD_PACK = 0x44, CB_RESPAWN = 0x45, CB_SECTION_BLOCKS = 0x47, CB_ACTION_BAR = 0x4A, CB_SET_HELD = 0x51, CB_ENTITY_VELOCITY = 0x58,
        CB_SET_HEALTH = 0x5B, CB_START_CONFIG = 0x67, CB_SYSTEM_CHAT = 0x69, CB_TELEPORT_ENTITY = 0x6D, CB_ATTRIBUTES = 0x71, CB_ENTITY_EFFECT = 0x72;

    public enum Status { IDLE, CONNECTING, ONLINE, WAITING_RECONNECT }
    enum Proto { LOGIN, CONFIG, PLAY }

    public static final class KickException extends RuntimeException {
        private static final long serialVersionUID = 1L;
        public KickException(String reason) { super(reason); }
    }

    public static final class Cmd {
        public final String command;
        public final int delaySec;
        public Cmd(String command, int delaySec) { this.command = command; this.delaySec = delaySec; }
    }

    public static final class Profile {
        public String name = "", address = "", username = "Player", password = "";
        public boolean autoLogin, autoRejoin;
        public int packMode = PACK_ASK;
        public List<Cmd> commands = new ArrayList<>();
    }

    public static final class PackOffer {
        public final UUID id; public final String url, hash, prompt; public final boolean forced, inConfig;
        PackOffer(UUID id, String url, String hash, boolean forced, String prompt, boolean inConfig) {
            this.id = id; this.url = url; this.hash = hash; this.forced = forced; this.prompt = prompt; this.inConfig = inConfig;
        }
    }

    public static final class Suggestions {
        public final int start, length; public final List<String> items;
        Suggestions(int s, int l, List<String> i) { start = s; length = l; items = i; }
    }

    public static final class Config {
        public volatile boolean autoRespawn = true;
        public volatile boolean physics = true;
        public volatile int rejoinDelaySec = 5;
        public volatile int readTimeoutMs = 45_000;
        public volatile File packDir = new File(System.getProperty("java.io.tmpdir"), "mc-packs");
        public final NavConfig nav = new NavConfig();
    }

    /** Events are delivered from the network/tick threads. All methods have empty defaults. */
    public interface Listener {
        default void onStatus(Status status, String info) {}
        default void onReconnectIn(int seconds) {}
        default void onChat(List<Chat.Span> spans) {}
        default void onActionBar(List<Chat.Span> spans) {}
        default void onHealth(float health, int food) {}
        default void onPlayers(List<String> names) {}
        default void onPackOffer(PackOffer offer) {}
        default void onPackResult(boolean ok, boolean cached, String error) {}
        default void onSuggestions(Suggestions s) {}
        default void onInventory() {}
        default void onActionStatus(String text, boolean running) {}
        default void onEnded(String reason) {}
    }

    public final Config config = new Config();
    public final World world = new World();
    public final Inventory inventory = new Inventory();
    final Physics phys = new Physics(world);
    private final Listener L;

    private volatile Status status = Status.IDLE;
    private volatile boolean stopRequested;
    private volatile Thread thread;
    private volatile Framing.Conn conn;
    private volatile Socket socket;
    private volatile Proto proto = Proto.LOGIN;
    private volatile ScheduledExecutorService ticker;
    private final ExecutorService io = Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r, "mc-io"); t.setDaemon(true); return t; });

    private Profile profile;
    private Map<Integer, Object[]> chatTypes = new HashMap<>();
    private final Map<String, int[]> dimensions = new HashMap<>();
    private final Map<UUID, String> players = new LinkedHashMap<>();
    private final Map<Integer, double[]> entities = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> entityByUuid = new ConcurrentHashMap<>();
    private int ownEntityId = -1;

    private final Object posLock = new Object();
    private volatile boolean hasPos;
    private float yaw, pitch;
    /** What was last sent to the server (LocalPlayer.xLast etc.). */
    private double lastSentX, lastSentY, lastSentZ;
    private float lastSentYaw, lastSentPitch;
    private int positionReminder;
    private boolean lastSentOnGround, wasSprinting, wasSneaking;
    /** Keyboard-like input of the current tick; actions and the manual pad fill it, Physics consumes it. */
    private final Physics.Input input = new Physics.Input();
    private volatile float manualForward, manualStrafe;
    private volatile boolean manualJump, manualSneak, manualSprint;
    private volatile long manualUntil;
    private final Actions.Eater eater = new Actions.Eater();
    /** Mob effect ids of protocol 765 (classic 1-based numbering); replaced from effects.json when that data is available. */
    private volatile int effJump = 8, effLevitation = 25, effSlowFalling = 28, effDolphin = 30;
    private final Map<Integer, Integer> effects = new java.util.HashMap<>();
    private final Map<String, int[]> waypoints = java.util.Collections.synchronizedMap(new java.util.LinkedHashMap<String, int[]>());
    private long tickCount;
    private volatile Actions.Action action;
    private volatile boolean tickerStarted;
    private volatile boolean respawnPending;
    private int pendingAck;
    private volatile int suggestId;
    private final java.util.concurrent.atomic.AtomicInteger seq = new java.util.concurrent.atomic.AtomicInteger();
    public volatile float health = 20f;
    public volatile int food = 20;
    private volatile String lastActionStatus = "";

    public ClientSession(Listener listener) { this.L = listener; }

    // ================================================================== public API

    public Status status() { return status; }
    public double x() { return phys.x; }
    public double y() { return phys.y; }
    public double z() { return phys.z; }
    public float yaw() { return yaw; }
    public float pitch() { return pitch; }
    public boolean hasPosition() { return hasPos; }
    public NavConfig nav() { return config.nav; }
    public Actions.Action currentAction() { return action; }

    public synchronized void connect(Profile p) {
        Thread old = thread;
        if (old != null && old.isAlive()) {
            if (!stopRequested) return;
            try { old.join(2000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
        stopRequested = false;
        profile = p;
        setStatus(Status.CONNECTING, "در حال اتصال…");
        Thread t = new Thread(() -> supervise(p), "mc-session");
        t.setDaemon(true);
        thread = t;
        t.start();
    }

    public void disconnect() {
        stopRequested = true;
        Thread t = thread;
        if (t != null) t.interrupt();
        io.execute(() -> { try { Socket s = socket; if (s != null) s.close(); } catch (IOException e) { /* ignore */ } });
    }

    /** Sends a chat message, or a command when the text starts with "/". Returns false when not in the game. */
    public boolean sendUserText(String text) {
        final String t = text.trim();
        if (t.isEmpty() || conn == null || proto != Proto.PLAY) return false;
        io.execute(() -> { try { sendTextNow(t); } catch (RuntimeException e) { /* ignore */ } });
        return true;
    }

    public void respawn() {
        io.execute(() -> send(SB_CLIENT_STATUS, new Buf.Writer().varInt(0).toBytes()));
    }

    public void requestSuggestions(final String text) { io.execute(() -> requestSuggestionsNow(text)); }
    public void clearSuggestions() { L.onSuggestions(null); }

    public void answerPack(PackOffer offer, boolean accept) {
        if (offer == null) return;
        if (accept) startPackDownload(offer); else io.execute(() -> respondPack(offer, 1));
    }

    // ---- inventory / items

    public void clickSlot(final int slot, final int button, final int mode) {
        io.execute(() -> {
            byte[] body = inventory.click(slot, button, mode);
            send(SB_CLICK_CONTAINER, body);
            L.onInventory();
        });
    }

    public void closeWindow() {
        io.execute(() -> {
            Inventory.Window w = inventory.open();
            if (w != null) send(SB_CLOSE_CONTAINER, new Buf.Writer().b(w.id).toBytes());
            inventory.closeLocal();
            L.onInventory();
        });
    }

    public void selectHotbar(final int slot) {
        io.execute(() -> { inventory.setHeld(slot); send(SB_SET_HELD, new Buf.Writer().s16(slot).toBytes()); L.onInventory(); });
    }

    /** Right click with the item in hand. */
    public void useItem() {
        io.execute(() -> send(SB_USE_ITEM, new Buf.Writer().varInt(0).varInt(seq.incrementAndGet()).toBytes()));
    }

    /** Left click (arm swing). */
    public void swing() { io.execute(this::swingNow); }

    public void dropHeld(final boolean wholeStack) {
        io.execute(() -> send(SB_PLAYER_ACTION, new Buf.Writer().varInt(wholeStack ? 3 : 4).i64(0).b(0).varInt(seq.incrementAndGet()).toBytes()));
    }

    // ---- actions

    public void startAction(Actions.Action a) {
        action = a;
        a.start(this);
        L.onActionStatus(a.name(), true);
    }

    public void stopAction() {
        Actions.Action a = action;
        action = null;
        synchronized (posLock) { input.clear(); }
        eater.reset();
        if (a != null) L.onActionStatus("متوقف شد: " + a.name(), false);
    }

    // ================================================================== supervisor (auto-rejoin)

    private void setStatus(Status s, String info) { status = s; L.onStatus(s, info); }

    private void supervise(Profile p) {
        String endReason = "";
        try {
            outer:
            while (!stopRequested) {
                setStatus(Status.CONNECTING, "در حال اتصال به " + p.address + "…");
                try {
                    runConnection(p);
                    endReason = "ارتباط با سرور بسته شد";
                } catch (KickException e) {
                    endReason = "از سرور بیرون انداخته شدید: " + e.getMessage();
                } catch (Exception e) {
                    endReason = stopRequested ? "" : describe(e);
                }
                if (stopRequested) break;
                L.onChat(java.util.Collections.singletonList(new Chat.Span(endReason, Chat.RED)));
                if (!p.autoRejoin) break;
                for (int s = config.rejoinDelaySec; s >= 1; s--) {
                    L.onReconnectIn(s);
                    setStatus(Status.WAITING_RECONNECT, endReason);
                    try { Thread.sleep(1000); } catch (InterruptedException e) { break outer; }
                    if (stopRequested) break outer;
                }
            }
        } finally {
            try { Socket s = socket; if (s != null) s.close(); } catch (IOException e) { /* ignore */ }
            thread = null;
            status = Status.IDLE;
            L.onStatus(Status.IDLE, "");
            L.onEnded(stopRequested ? "" : endReason);
        }
    }

    private static String describe(Exception e) {
        if (e instanceof UnknownHostException) return "آدرس سرور پیدا نشد";
        if (e instanceof ConnectException) return "اتصال به سرور برقرار نشد (سرور خاموش است یا پورت اشتباه است)";
        if (e instanceof SocketTimeoutException) return "زمان اتصال به سرور تمام شد";
        if (e instanceof EOFException || e instanceof SocketException) return "ارتباط با سرور قطع شد";
        return "خطا: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());
    }

    // ================================================================== one connection

    private void resetConnectionData() {
        chatTypes = new HashMap<>();
        synchronized (players) { players.clear(); }
        entities.clear(); entityByUuid.clear();
        world.clear();
        inventory.reset();
        hasPos = false; tickerStarted = false; respawnPending = false; pendingAck = 0; suggestId = 0; ownEntityId = -1;
        action = null;
        health = 20f; food = 20;
        phys.resetState(); effects.clear();
        lastSentX = lastSentY = lastSentZ = 0; lastSentYaw = lastSentPitch = 0; positionReminder = 0; lastSentOnGround = false; wasSprinting = false; wasSneaking = false;
    }

    private void runConnection(Profile p) throws IOException {
        resetConnectionData();
        Object[] hp = Framing.parseAddress(p.address);
        String host = (String) hp[0];
        int port = (Integer) hp[1];
        Socket sock = new Socket();
        sock.setTcpNoDelay(true);
        sock.setKeepAlive(true);
        sock.connect(new InetSocketAddress(host, port), 10_000);
        sock.setSoTimeout(config.readTimeoutMs);
        socket = sock;
        Framing.Conn c = new Framing.Conn(sock.getInputStream(), sock.getOutputStream());
        conn = c;
        proto = Proto.LOGIN;
        try {
            c.send(0x00, new Buf.Writer().varInt(PROTOCOL).str(host).s16(port).varInt(2).toBytes());
            UUID offline = UUID.nameUUIDFromBytes(("OfflinePlayer:" + p.username).getBytes(java.nio.charset.StandardCharsets.UTF_8));
            c.send(0x00, new Buf.Writer().str(p.username).uuid(offline).toBytes());
            while (!stopRequested) {
                Framing.Incoming in = c.read();
                try {
                    switch (proto) {
                        case LOGIN: onLogin(c, in); break;
                        case CONFIG: onConfig(c, in, p); break;
                        default: onPlay(c, in, p); break;
                    }
                } catch (Buf.ParseEx e) {
                    // an unparseable packet is skipped; the connection stays alive
                }
            }
        } finally {
            ScheduledExecutorService t = ticker;
            if (t != null) t.shutdownNow();
            ticker = null;
            try { sock.close(); } catch (IOException e) { /* ignore */ }
            conn = null;
            socket = null;
        }
    }

    private void onLogin(Framing.Conn c, Framing.Incoming in) throws IOException {
        Buf.Reader r = in.r;
        switch (in.id) {
            case 0x00: throw new KickException(Chat.plainFromJsonText(r.str()));
            case 0x01: throw new KickException("این سرور آنلاین‌مود است و به حساب اصلی نیاز دارد. این نسخه فقط سرورهای آفلاین‌مود را پشتیبانی می‌کند.");
            case 0x02:
                c.send(0x03); // Login Acknowledged
                proto = Proto.CONFIG;
                c.send(0x00, new Buf.Writer().str("en_us").b(8).varInt(0).bool(true).b(0x7F).varInt(1).bool(false).bool(true).toBytes());
                c.send(0x01, new Buf.Writer().str("minecraft:brand").str("vanilla").toBytes());
                break;
            case 0x03: c.threshold = r.varInt(); break;
            case 0x04: { int id = r.varInt(); c.send(0x02, new Buf.Writer().varInt(id).bool(false).toBytes()); break; }
            default: break;
        }
    }

    private void onConfig(Framing.Conn c, Framing.Incoming in, Profile p) throws IOException {
        Buf.Reader r = in.r;
        switch (in.id) {
            case 0x01: throw new KickException(Chat.plain(r.nbt()));
            case 0x02: c.send(0x02); proto = Proto.PLAY; break;
            case 0x03: c.send(0x03, new Buf.Writer().i64(r.i64()).toBytes()); break;
            case 0x04: c.send(0x04, new Buf.Writer().i32(r.i32()).toBytes()); break;
            case 0x05: parseRegistry(r); break;
            case 0x07: onPackOffer(r, true, p); break;
            default: break;
        }
    }

    @SuppressWarnings("unchecked")
    private void parseRegistry(Buf.Reader r) {
        Object rootObj = r.nbt();
        if (!(rootObj instanceof Map)) return;
        Map<String, Object> root = (Map<String, Object>) rootObj;
        Object ct = root.get("minecraft:chat_type");
        if (ct instanceof Map && ((Map<String, Object>) ct).get("value") instanceof List) {
            Map<Integer, Object[]> map = new HashMap<>();
            int index = 0;
            for (Object e : (List<Object>) ((Map<String, Object>) ct).get("value")) {
                if (e instanceof Map) {
                    Map<String, Object> m = (Map<String, Object>) e;
                    int id = m.get("id") instanceof Number ? ((Number) m.get("id")).intValue() : index;
                    Object el = m.get("element");
                    Object chat = el instanceof Map ? ((Map<String, Object>) el).get("chat") : null;
                    if (chat instanceof Map && ((Map<String, Object>) chat).get("translation_key") instanceof String) {
                        Map<String, Object> cm = (Map<String, Object>) chat;
                        List<String> params = new ArrayList<>();
                        if (cm.get("parameters") instanceof List) for (Object o : (List<Object>) cm.get("parameters")) params.add(String.valueOf(o));
                        else { params.add("sender"); params.add("content"); }
                        map.put(id, new Object[]{cm.get("translation_key"), params});
                    }
                }
                index++;
            }
            chatTypes = map;
        }
        Object dt = root.get("minecraft:dimension_type");
        if (dt instanceof Map && ((Map<String, Object>) dt).get("value") instanceof List) {
            for (Object e : (List<Object>) ((Map<String, Object>) dt).get("value")) {
                if (!(e instanceof Map)) continue;
                Map<String, Object> m = (Map<String, Object>) e;
                Object el = m.get("element");
                if (m.get("name") instanceof String && el instanceof Map) {
                    Map<String, Object> em = (Map<String, Object>) el;
                    if (em.get("min_y") instanceof Number && em.get("height") instanceof Number) {
                        dimensions.put((String) m.get("name"), new int[]{((Number) em.get("min_y")).intValue(), ((Number) em.get("height")).intValue()});
                    }
                }
            }
        }
    }

    private void applyDimension(String type) {
        int[] d = dimensions.get(type);
        if (d != null) { world.minY = d[0]; world.height = d[1]; }
        world.clear();
        entities.clear();
        entityByUuid.clear();
    }

    private void onPlay(Framing.Conn c, Framing.Incoming in, Profile p) throws IOException {
        Buf.Reader r = in.r;
        switch (in.id) {
            case CB_CHUNK_BATCH_FINISHED: c.send(SB_CHUNK_BATCH_RECEIVED, new Buf.Writer().f32(10f).toBytes()); break;
            case CB_KEEP_ALIVE: c.send(SB_KEEP_ALIVE, new Buf.Writer().i64(r.i64()).toBytes()); break;
            case CB_PING: c.send(SB_PONG, new Buf.Writer().i32(r.i32()).toBytes()); break;
            case CB_DISCONNECT: throw new KickException(Chat.plain(r.nbt()));
            case CB_LOGIN: {
                ownEntityId = r.i32();
                r.bool();
                int dimCount = r.varInt();
                for (int i = 0; i < dimCount; i++) r.str();
                r.varInt(); r.varInt(); r.varInt(); r.bool(); r.bool(); r.bool();
                String dimType = r.str();
                ScheduledExecutorService t = ticker;
                if (t != null) t.shutdownNow();
                ticker = null; tickerStarted = false; hasPos = false; respawnPending = false;
                applyDimension(dimType);
                L.onHealth(20f, 20);
                setStatus(Status.ONLINE, "متصل شد");
                L.onChat(java.util.Collections.singletonList(new Chat.Span("به سرور وارد شدید", Chat.GREEN)));
                break;
            }
            case CB_RESPAWN: {
                String dimType = r.str();
                applyDimension(dimType);
                respawnPending = false;
                synchronized (posLock) { phys.resetState(); effects.clear(); applyEffects(); }
                break;
            }
            case CB_SYNC_POSITION: {
                double x = r.f64(), y = r.f64(), z = r.f64();
                float yw = r.f32(), pt = r.f32();
                int flags = r.i8();
                int tid = r.varInt();
                synchronized (posLock) {
                    boolean rx = (flags & 0x01) != 0, ry = (flags & 0x02) != 0, rz = (flags & 0x04) != 0;
                    phys.x = rx ? phys.x + x : x;
                    phys.y = ry ? phys.y + y : y;
                    phys.z = rz ? phys.z + z : z;
                    yaw = (flags & 0x08) != 0 ? yaw + yw : yw;
                    pitch = (flags & 0x10) != 0 ? pitch + pt : pt;
                    phys.teleported(rx, ry, rz); // absolute axes lose their velocity
                    hasPos = true;
                    // exactly like ClientPacketListener.handleMovePlayer: confirm, then PosRot with onGround=false
                    c.send(SB_CONFIRM_TELEPORT, new Buf.Writer().varInt(tid).toBytes());
                    c.send(SB_POS_ROT, new Buf.Writer().f64(phys.x).f64(phys.y).f64(phys.z).f32(yaw).f32(pitch).bool(false).toBytes());
                }
                Actions.Action a = action;
                if (a != null) a.onTeleport();
                if (!tickerStarted) { tickerStarted = true; startTicker(p); }
                break;
            }
            case CB_ENTITY_VELOCITY: {
                int id = r.varInt();
                double vx = r.s16() / 8000.0, vy = r.s16() / 8000.0, vz = r.s16() / 8000.0;
                if (id == ownEntityId) synchronized (posLock) { phys.vx = vx; phys.vy = vy; phys.vz = vz; }
                break;
            }
            case CB_EXPLOSION: {
                r.f64(); r.f64(); r.f64(); r.f32();
                int n = r.varInt();
                if (n < 0 || n > 100000) throw new Buf.ParseEx("bad explosion record count");
                for (int i = 0; i < n * 3; i++) r.i8();
                float kx = r.f32(), ky = r.f32(), kz = r.f32();
                synchronized (posLock) { phys.vx += kx; phys.vy += ky; phys.vz += kz; }
                break;
            }
            case CB_ABILITIES: {
                int fl = r.u8();
                float flySpeed = r.f32();
                r.f32();
                synchronized (posLock) {
                    phys.mayFly = (fl & 0x04) != 0;
                    phys.flySpeed = flySpeed;
                    phys.flying = (fl & 0x02) != 0 && phys.mayFly;
                }
                break;
            }
            case CB_ENTITY_EFFECT: {
                int id = r.varInt(), eff = r.varInt(), amp = r.i8();
                if (id == ownEntityId) synchronized (posLock) { effects.put(eff, (amp & 0xFF) + 1); applyEffects(); }
                break;
            }
            case CB_REMOVE_EFFECT: {
                int id = r.varInt(), eff = r.varInt();
                if (id == ownEntityId) synchronized (posLock) { effects.remove(eff); applyEffects(); }
                break;
            }
            case CB_ATTRIBUTES: {
                int id = r.varInt();
                int n = r.varInt();
                for (int i = 0; i < n; i++) {
                    String key = r.str();
                    double base = r.f64();
                    int mods = r.varInt();
                    double add = 0, mulBase = 0, mulTotal = 1;
                    for (int m = 0; m < mods; m++) {
                        UUID mu = r.uuid();
                        double amount = r.f64();
                        int op = r.i8();
                        if (mu.equals(Physics.SPRINT_MODIFIER)) continue; // the sprint boost is applied by Physics itself
                        if (op == 0) add += amount; else if (op == 1) mulBase += amount; else if (op == 2) mulTotal *= 1 + amount;
                    }
                    if (id == ownEntityId && key.equals("minecraft:generic.movement_speed")) {
                        double v = (base + add);
                        v += (base + add) * mulBase;
                        v *= mulTotal;
                        synchronized (posLock) { phys.speedBase = v; }
                    }
                }
                break;
            }
            case CB_CONTAINER_PROPERTY: inventory.onProperty(r); L.onInventory(); break;
            case CB_SET_HEALTH: {
                float hp = r.f32();
                int fd = r.varInt();
                health = hp; food = fd;
                phys.enoughFood = fd > 6;
                L.onHealth(hp, fd);
                if (hp <= 0f) autoRespawn(); else respawnPending = false;
                break;
            }
            case CB_COMBAT_DEATH: autoRespawn(); break;
            case CB_SYSTEM_CHAT: {
                Object content = r.nbt();
                boolean overlay = r.bool();
                if (overlay) L.onActionBar(Chat.fromAny(content)); else L.onChat(Chat.fromAny(content));
                break;
            }
            case CB_ACTION_BAR: L.onActionBar(Chat.fromAny(r.nbt())); break;
            case CB_DISGUISED_CHAT: {
                Object message = r.nbt();
                int ct = r.varInt();
                Object sender = r.nbt();
                Object target = r.bool() ? r.nbt() : null;
                L.onChat(formatChat(ct, sender, message, target));
                break;
            }
            case CB_PLAYER_CHAT: {
                r.uuid(); r.varInt();
                boolean hasSig = r.bool();
                if (hasSig) r.skip(256);
                String msg = r.str();
                r.i64(); r.i64();
                int prev = r.varInt();
                for (int i = 0; i < prev; i++) { int id = r.varInt(); if (id == 0) r.skip(256); }
                Object unsigned = r.bool() ? r.nbt() : null;
                int filter = r.varInt();
                if (filter == 2) { int n = r.varInt(); r.skip(n * 8); }
                int ct = r.varInt();
                Object sender = r.nbt();
                Object target = r.bool() ? r.nbt() : null;
                if (hasSig && ++pendingAck >= 20) {
                    c.send(SB_ACK_MESSAGE, new Buf.Writer().varInt(pendingAck).toBytes());
                    pendingAck = 0;
                }
                L.onChat(formatChat(ct, sender, unsigned != null ? unsigned : msg, target));
                break;
            }
            case CB_PLAYER_INFO_UPDATE: {
                int actions = r.u8();
                int count = r.varInt();
                for (int i = 0; i < count; i++) {
                    UUID uuid = r.uuid();
                    String name = null;
                    if ((actions & 0x01) != 0) {
                        name = r.str();
                        int props = r.varInt();
                        for (int k = 0; k < props; k++) { r.str(); r.str(); if (r.bool()) r.str(); }
                    }
                    if ((actions & 0x02) != 0 && r.bool()) { r.uuid(); r.i64(); r.skip(r.varInt()); r.skip(r.varInt()); }
                    if ((actions & 0x04) != 0) r.varInt();
                    if ((actions & 0x08) != 0) r.bool();
                    if ((actions & 0x10) != 0) r.varInt();
                    if ((actions & 0x20) != 0 && r.bool()) r.nbt();
                    if (name != null) synchronized (players) { players.put(uuid, name); }
                }
                publishPlayers();
                break;
            }
            case CB_PLAYER_INFO_REMOVE: {
                int n = r.varInt();
                for (int i = 0; i < n; i++) { UUID u = r.uuid(); synchronized (players) { players.remove(u); } }
                publishPlayers();
                break;
            }
            case CB_SUGGESTIONS: {
                int tid = r.varInt(), start = r.varInt(), len = r.varInt(), n = r.varInt();
                List<String> items = new ArrayList<>();
                for (int i = 0; i < n; i++) { items.add(r.str()); if (r.bool()) r.nbt(); }
                if (tid == suggestId) L.onSuggestions(items.isEmpty() ? null : new Suggestions(start, len, items));
                break;
            }
            case CB_ADD_PACK: onPackOffer(r, false, p); break;
            case CB_START_CONFIG:
                c.send(SB_ACK_CONFIGURATION);
                proto = Proto.CONFIG;
                hasPos = false;
                break;
            // ---- world
            case CB_CHUNK_DATA: {
                int cx = r.i32(), cz = r.i32();
                r.nbt();
                int size = r.varInt();
                world.loadChunk(cx, cz, r.bytes(size));
                break;
            }
            case CB_UNLOAD_CHUNK: { int cz = r.i32(); int cx = r.i32(); world.unload(cx, cz); break; }
            case CB_BLOCK_UPDATE: { long pos = r.i64(); int st = r.varInt(); world.set(World.posX(pos), World.posY(pos), World.posZ(pos), st); break; }
            case CB_SECTION_BLOCKS: {
                long sp = r.i64();
                int sx = (int) (sp >> 42), sy = (int) (sp << 44 >> 44), sz = (int) (sp << 22 >> 42);
                int n = r.varInt();
                for (int i = 0; i < n; i++) {
                    long v = r.varLong();
                    world.set(sx * 16 + (int) ((v >> 8) & 15), sy * 16 + (int) (v & 15), sz * 16 + (int) ((v >> 4) & 15), (int) (v >>> 12));
                }
                break;
            }
            // ---- entities
            case CB_SPAWN_ENTITY: {
                int id = r.varInt();
                UUID u = r.uuid();
                r.varInt();
                entities.put(id, new double[]{r.f64(), r.f64(), r.f64()});
                entityByUuid.put(u, id);
                break;
            }
            case CB_ENTITY_POS:
            case CB_ENTITY_POS_ROT: {
                int id = r.varInt();
                double[] e = entities.get(id);
                double dx = r.s16() / 4096.0, dy = r.s16() / 4096.0, dz = r.s16() / 4096.0;
                if (e != null) { e[0] += dx; e[1] += dy; e[2] += dz; }
                break;
            }
            case CB_TELEPORT_ENTITY: {
                int id = r.varInt();
                entities.put(id, new double[]{r.f64(), r.f64(), r.f64()});
                break;
            }
            case CB_REMOVE_ENTITIES: {
                int n = r.varInt();
                for (int i = 0; i < n; i++) entities.remove(r.varInt());
                break;
            }
            // ---- containers
            case CB_SET_CONTENT: inventory.onContent(r); L.onInventory(); break;
            case CB_SET_SLOT: inventory.onSlot(r); L.onInventory(); break;
            case CB_OPEN_SCREEN: inventory.onOpen(r); L.onInventory(); break;
            case CB_CLOSE_CONTAINER: inventory.onClose(r.u8()); L.onInventory(); break;
            case CB_SET_HELD: inventory.setHeld(r.i8()); L.onInventory(); break;
            default: break;
        }
    }

    // ================================================================== helpers

    private void send(int id, byte[] body) {
        Framing.Conn c = conn;
        if (c == null) return;
        try { c.send(id, body); } catch (IOException e) { Socket s = socket; if (s != null) try { s.close(); } catch (IOException ex) { /* ignore */ } }
    }

    @SuppressWarnings("unchecked")
    private List<Chat.Span> formatChat(int ct, Object sender, Object content, Object target) {
        Object[] info = chatTypes.get(ct);
        String key = info == null ? "chat.type.text" : (String) info[0];
        List<String> params = info == null ? java.util.Arrays.asList("sender", "content") : (List<String>) info[1];
        List<Object> args = new ArrayList<>();
        for (String s : params) {
            if (s.equals("sender")) args.add(sender);
            else if (s.equals("content")) args.add(content);
            else if (s.equals("target")) args.add(target == null ? "" : target);
            else args.add("");
        }
        Map<String, Object> node = new LinkedHashMap<>();
        node.put("translate", key);
        node.put("with", args);
        return Chat.fromAny(node);
    }

    private void publishPlayers() {
        List<String> names;
        synchronized (players) { names = new ArrayList<>(players.values()); }
        java.util.Collections.sort(names, String.CASE_INSENSITIVE_ORDER);
        L.onPlayers(names);
    }

    private void autoRespawn() {
        if (respawnPending) return;
        if (config.autoRespawn) {
            respawnPending = true;
            L.onChat(java.util.Collections.singletonList(new Chat.Span("مُردید؛ ریسپاون خودکار…", Chat.YELLOW)));
            respawn();
        } else {
            L.onChat(java.util.Collections.singletonList(new Chat.Span("مُردید؛ برای ادامه دکمهٔ ریسپاون را بزنید", Chat.YELLOW)));
        }
    }

    void sendTextNow(String text) {
        String t = text.trim();
        if (t.startsWith("/")) sendCommandNow(t.substring(1)); else sendMessageNow(t);
    }

    private void sendMessageNow(String text) {
        String t = text.length() > 256 ? text.substring(0, 256) : text;
        send(SB_CHAT_MESSAGE, new Buf.Writer().str(t).i64(System.currentTimeMillis()).i64(0L).bool(false).varInt(0).bytes(new byte[3]).toBytes());
    }

    private void sendCommandNow(String cmd) {
        String t = cmd.length() > 256 ? cmd.substring(0, 256) : cmd;
        send(SB_CHAT_COMMAND, new Buf.Writer().str(t).i64(System.currentTimeMillis()).i64(0L).varInt(0).varInt(0).bytes(new byte[3]).toBytes());
    }

    static long packPos(int x, int y, int z) { return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (y & 0xFFF); }

    /** Player Action: 0 = start digging, 1 = cancel, 2 = finish. */
    void sendDig(int status, int x, int y, int z, int face) {
        send(SB_PLAYER_ACTION, new Buf.Writer().varInt(status).i64(packPos(x, y, z)).b(face).varInt(seq.incrementAndGet()).toBytes());
    }

    /** Use Item On (right click a block face): used for placing blocks and opening doors. */
    void sendUseOn(int x, int y, int z, int face, float cx, float cy, float cz) {
        send(SB_USE_ON, new Buf.Writer().varInt(0).i64(packPos(x, y, z)).varInt(face).f32(cx).f32(cy).f32(cz).bool(false).varInt(seq.incrementAndGet()).toBytes());
    }

    void selectSlotNow(int slot) {
        inventory.setHeld(slot);
        send(SB_SET_HELD, new Buf.Writer().s16(slot).toBytes());
    }

    void swingNow() { send(SB_SWING, new Buf.Writer().varInt(0).toBytes()); }

    private void requestSuggestionsNow(String text) {
        Framing.Conn c = conn;
        if (c == null || proto != Proto.PLAY || status != Status.ONLINE || text.isEmpty()) { L.onSuggestions(null); return; }
        if (text.startsWith("/")) {
            int tid = ++suggestId;
            send(SB_SUGGESTIONS_REQUEST, new Buf.Writer().varInt(tid).str(text).toBytes());
        } else {
            int start = text.lastIndexOf(' ') + 1;
            String word = text.substring(start);
            if (word.isEmpty()) { L.onSuggestions(null); return; }
            List<String> names = new ArrayList<>();
            synchronized (players) { for (String n : players.values()) if (n.regionMatches(true, 0, word, 0, word.length()) && !n.equalsIgnoreCase(word)) names.add(n); }
            java.util.Collections.sort(names, String.CASE_INSENSITIVE_ORDER);
            L.onSuggestions(names.isEmpty() ? null : new Suggestions(start, word.length(), names));
        }
    }

    // ---- movement hooks for actions

    void setLook(float yw, float pt) { yaw = yw; pitch = pt; }
    void requestJump(boolean j) { if (j) input.jump = true; }
    Physics.Input input() { return input; }

    private void applyEffects() {
        Integer j = effects.get(effJump), l = effects.get(effLevitation);
        phys.jumpBoost = j == null ? 0 : j;
        phys.levitation = l == null ? 0 : l;
        phys.slowFalling = effects.containsKey(effSlowFalling);
        phys.dolphinsGrace = effects.containsKey(effDolphin);
    }

    /** Overrides the default mob effect ids with the ones from effects.json of the running game version. */
    public void setEffectIds(int jumpBoost, int levitation, int slowFalling, int dolphinsGrace) {
        effJump = jumpBoost; effLevitation = levitation; effSlowFalling = slowFalling; effDolphin = dolphinsGrace;
    }

    // ---- manual control (the on-screen pad)

    /** Holds the given input for the next ~250 ms (call again every 100 ms while a button is held). */
    public void manualMove(float forward, float strafe, boolean jump, boolean sneak, boolean sprint) {
        manualForward = forward; manualStrafe = strafe; manualJump = jump; manualSneak = sneak; manualSprint = sprint;
        manualUntil = System.currentTimeMillis() + (forward != 0 || strafe != 0 || jump || sneak ? 250 : 0);
    }

    public void manualTurn(float dYaw, float dPitch) {
        synchronized (posLock) { yaw += dYaw; pitch = Math.max(-90f, Math.min(90f, pitch + dPitch)); }
    }

    /** Left click in the game world: Swing Arm. */
    public void leftClick() { io.execute(this::swingNow); }

    /** Right click in the game world: Use Item (main hand). */
    public void rightClick() { io.execute(this::useItemNow); }

    void useItemNow() { send(SB_USE_ITEM, new Buf.Writer().varInt(0).varInt(seq.incrementAndGet()).toBytes()); }

    /** Swap the items of both hands (Player Action status 6). */
    public void swapHands() { io.execute(() -> sendDig(6, 0, 0, 0, 0)); }


    /** Click Container Button (0x0C): enchanting options, loom patterns, stonecutter recipes, beacon... */
    public void clickButton(final int buttonId) {
        io.execute(() -> {
            Inventory.Window w = inventory.open();
            if (w != null) send(SB_CLICK_BUTTON, new Buf.Writer().b(w.id).b(buttonId).toBytes());
        });
    }

    public boolean mayFly() { return phys.mayFly; }
    public boolean isFlying() { return phys.flying; }

    /** Start/stop creative flight where the server allows it (Player Abilities flags 0x02). */
    public void setFlying(boolean on) { io.execute(() -> setFlyingNow(on)); }

    void setFlyingNow(boolean on) {
        synchronized (posLock) {
            if (on && !phys.mayFly) return;
            if (phys.flying == on) return;
            phys.flying = on;
            if (on && phys.onGround) { phys.vy = 0.1; phys.onGround = false; }
        }
        send(SB_ABILITIES, new Buf.Writer().b(on ? 0x02 : 0x00).toBytes());
    }

    // ---- waypoints

    public void saveWaypoint(String name) {
        synchronized (posLock) { waypoints.put(name, new int[]{(int) Math.floor(phys.x), (int) Math.floor(phys.y + 1e-6), (int) Math.floor(phys.z)}); }
    }
    public void setWaypoint(String name, int x, int y, int z) { waypoints.put(name, new int[]{x, y, z}); }
    public void deleteWaypoint(String name) { waypoints.remove(name); }
    public Map<String, int[]> waypoints() { synchronized (waypoints) { return new java.util.LinkedHashMap<>(waypoints); } }

    public double[] entityPos(String playerName) {
        UUID found = null;
        synchronized (players) { for (Map.Entry<UUID, String> e : players.entrySet()) if (e.getValue().equalsIgnoreCase(playerName)) found = e.getKey(); }
        if (found == null) return null;
        Integer id = entityByUuid.get(found);
        double[] pos = id == null ? null : entities.get(id);
        return pos == null ? null : pos.clone();
    }

    /** LocalPlayer.sendPosition: sprint/sneak commands, then Pos / PosRot / Rot / OnGround depending on what changed. */
    private void sendMovement(Framing.Conn c) throws IOException {
        boolean sp = phys.sprinting;
        if (sp != wasSprinting) { c.send(SB_PLAYER_COMMAND, new Buf.Writer().varInt(ownEntityId).varInt(sp ? 3 : 4).varInt(0).toBytes()); wasSprinting = sp; }
        boolean sh = phys.sneaking;
        if (sh != wasSneaking) { c.send(SB_PLAYER_COMMAND, new Buf.Writer().varInt(ownEntityId).varInt(sh ? 0 : 1).varInt(0).toBytes()); wasSneaking = sh; }
        double dx = phys.x - lastSentX, dy = phys.y - lastSentY, dz = phys.z - lastSentZ;
        double dyaw = yaw - lastSentYaw, dpitch = pitch - lastSentPitch;
        positionReminder++;
        boolean pos = dx * dx + dy * dy + dz * dz > 4.0E-8 || positionReminder >= 20;
        boolean rot = dyaw != 0.0 || dpitch != 0.0;
        if (pos && rot) c.send(SB_POS_ROT, new Buf.Writer().f64(phys.x).f64(phys.y).f64(phys.z).f32(yaw).f32(pitch).bool(phys.onGround).toBytes());
        else if (pos) c.send(SB_POS, new Buf.Writer().f64(phys.x).f64(phys.y).f64(phys.z).bool(phys.onGround).toBytes());
        else if (rot) c.send(SB_ROT, new Buf.Writer().f32(yaw).f32(pitch).bool(phys.onGround).toBytes());
        else if (lastSentOnGround != phys.onGround) c.send(SB_ON_GROUND, new Buf.Writer().bool(phys.onGround).toBytes());
        if (pos) { lastSentX = phys.x; lastSentY = phys.y; lastSentZ = phys.z; positionReminder = 0; }
        if (rot) { lastSentYaw = yaw; lastSentPitch = pitch; }
        lastSentOnGround = phys.onGround;
    }

    // ================================================================== 20 Hz tick, auto-login, startup commands

    private void startTicker(Profile p) {
        ScheduledExecutorService ex = Executors.newSingleThreadScheduledExecutor(r -> { Thread t = new Thread(r, "mc-tick"); t.setDaemon(true); return t; });
        ticker = ex;
        ex.scheduleAtFixedRate(() -> {
            try { tick(); } catch (Throwable t) { /* a failing tick must never kill the scheduler */ }
        }, 50, 50, TimeUnit.MILLISECONDS);
        long base = 0;
        if (p.autoLogin && !p.password.isEmpty()) {
            ex.schedule(() -> { try { sendCommandNow("login " + p.password); } catch (RuntimeException e) { /* ignore */ } }, 1500, TimeUnit.MILLISECONDS);
            base = 2500;
        }
        for (Cmd cmd : p.commands) {
            if (cmd.command.trim().isEmpty()) continue;
            final String text = cmd.command;
            ex.schedule(() -> { try { sendTextNow(text); } catch (RuntimeException e) { /* ignore */ } },
                base + Math.max(0, cmd.delaySec) * 1000L, TimeUnit.MILLISECONDS);
        }
    }

    private void tick() throws IOException {
        Framing.Conn c = conn;
        if (c == null || proto != Proto.PLAY || !hasPos) return;
        synchronized (posLock) {
            tickCount++;
            input.clear();
            Actions.Action a = action;
            if (a != null) {
                boolean done;
                try { done = a.tick(this); } catch (RuntimeException e) { done = true; a.status = "خطا: " + e.getMessage(); }
                String st = a.status();
                if (done) {
                    action = null;
                    L.onActionStatus(st.isEmpty() ? "پایان: " + a.name() : st, false);
                } else if (tickCount % 10 == 0 && !st.equals(lastActionStatus)) {
                    lastActionStatus = st;
                    L.onActionStatus(st, true);
                }
            }
            // eat when hungry (the player stands still while eating)
            if (config.nav.autoEat && eater.tick(this)) { input.clear(); }
            // the on-screen pad overrides everything else
            if (System.currentTimeMillis() < manualUntil) {
                input.forward = manualForward; input.strafe = manualStrafe;
                input.jump = manualJump; input.sneak = manualSneak; input.sprint = manualSprint;
            }
            // LocalPlayer.tick does nothing at all while the chunk under the player is not loaded
            if (!world.isLoaded((int) Math.floor(phys.x), (int) Math.floor(phys.z))) return;
            if (config.physics) {
                phys.enoughFood = food > 6;
                phys.tick(input, yaw);
                if (phys.flightCancelled) c.send(SB_ABILITIES, new Buf.Writer().b(0).toBytes());
            } else { phys.vx = phys.vy = phys.vz = 0; phys.onGround = true; }
            sendMovement(c);
        }
    }

    // ================================================================== resource packs

    private void onPackOffer(Buf.Reader r, boolean inConfig, Profile p) {
        UUID id = r.uuid();
        String url = r.str(), hash = r.str();
        boolean forced = r.bool();
        String prompt = r.bool() ? Chat.plain(r.nbt()) : "";
        PackOffer offer = new PackOffer(id, url, hash, forced, prompt, inConfig);
        if (p.packMode == PACK_ACCEPT) startPackDownload(offer);
        else if (p.packMode == PACK_DECLINE) respondPack(offer, 1);
        else L.onPackOffer(offer);
    }

    private void respondPack(PackOffer offer, int result) {
        send(offer.inConfig ? 0x05 : SB_PACK_RESPONSE, new Buf.Writer().uuid(offer.id).varInt(result).toBytes());
    }

    private void startPackDownload(PackOffer offer) {
        Thread t = new Thread(() -> {
            respondPack(offer, 3); // accepted
            Packs.Result res = Packs.fetch(config.packDir, offer.url, offer.hash);
            if (res.ok) {
                respondPack(offer, 4); // downloaded
                respondPack(offer, 0); // successfully loaded
                L.onPackResult(true, res.cached, "");
                L.onChat(java.util.Collections.singletonList(new Chat.Span(res.cached ? "ریسورس‌پک از حافظه بارگذاری شد" : "ریسورس‌پک دانلود شد", Chat.GREEN)));
            } else {
                respondPack(offer, 2); // failed download
                L.onPackResult(false, false, res.error);
                L.onChat(java.util.Collections.singletonList(new Chat.Span("دانلود ریسورس‌پک ناموفق بود: " + res.error, Chat.RED)));
            }
        }, "mc-pack");
        t.setDaemon(true);
        t.start();
    }
}
