package com.mcclient.core;

/** User-tunable movement behaviour (exposed in the Actions screen). Blocks are never broken or placed. */
public final class NavConfig {
    public int maxFall = 3;             // largest drop (blocks) the path may take
    public boolean allowJump = true;    // step up one block
    public boolean allowDiagonal = true;
    public boolean sprint = false;
    public boolean allowBreak = false;  // dig through blocks that are in the way (needs registry data)
    public boolean allowPlace = false;  // bridge gaps and pillar up with throwaway blocks from the hotbar
    public boolean allowSwim = true;    // swim through water
    public boolean allowClimb = true;   // climb ladders and vines
    public boolean openDoors = true;    // open doors/gates that block the way
    public double breakPenalty = 2.0;   // Baritone blockBreakAdditionalPenalty (ticks per broken block)
    public double blockPlacementPenalty = 20.0; // Baritone blockPlacementPenalty (ticks per placed block)
    public double jumpPenalty = 2.0;    // Baritone jumpPenalty (ticks per jump)
    public boolean autoEat = true;      // eat when hungry while an action is running
    public boolean allowFly = false;    // fly in straight lines where the server allows it (creative / mayfly)
    public volatile boolean hasThrowaway = true; // set by the session: a placeable block is in the hotbar
    public double arriveDistance = 1.0; // goal radius in blocks
    public int maxNodes = 30000;        // search budget
    public int stuckSeconds = 6;        // replan when no progress for this long
    public int maxReplans = 4;

    public NavConfig copy() {
        NavConfig c = new NavConfig();
        c.maxFall = maxFall; c.allowJump = allowJump; c.allowDiagonal = allowDiagonal; c.sprint = sprint;
        c.allowBreak = allowBreak; c.allowPlace = allowPlace; c.allowSwim = allowSwim; c.allowClimb = allowClimb; c.openDoors = openDoors; c.breakPenalty = breakPenalty; c.blockPlacementPenalty = blockPlacementPenalty; c.jumpPenalty = jumpPenalty; c.autoEat = autoEat; c.allowFly = allowFly; c.hasThrowaway = hasThrowaway;
        c.arriveDistance = arriveDistance; c.maxNodes = maxNodes; c.stuckSeconds = stuckSeconds; c.maxReplans = maxReplans;
        return c;
    }
}
