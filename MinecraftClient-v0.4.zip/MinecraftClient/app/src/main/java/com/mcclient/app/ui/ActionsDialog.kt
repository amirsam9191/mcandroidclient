package com.mcclient.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.mcclient.app.Core
import com.mcclient.app.game.Status
import kotlinx.coroutines.delay
import java.util.Locale

private val TABS = listOf("رفتن به مختصات", "بازیکن", "گشت‌زنی", "ضد AFK", "ارسال تکراری", "باز کردن بلاک", "کندن (Mine)", "کاوش و پرواز", "نقاط ذخیره", "تنظیمات حرکت")

/** Block groups of the "open" tab: key of Actions.GUI_BLOCKS -> label. */
private val OPEN_LABELS = listOf(
    "ender_chest" to "اندر چست", "crafting_table" to "کرفتینگ تیبل", "chest" to "صندوق / بشکه", "furnace" to "کوره", "anvil" to "سندان",
    "enchanting_table" to "میز انچنت", "brewing_stand" to "برو استند", "loom" to "لوم", "stonecutter" to "استون‌کاتر", "grindstone" to "گریند‌استون",
    "smithing_table" to "میز آهنگری", "cartography_table" to "میز نقشه", "hopper" to "هاپر", "dispenser" to "دیسپنسر / دراپر",
    "beacon" to "بیکن", "lectern" to "تریبون", "shulker_box" to "شولکر باکس"
)

private val MINE_PRESETS = listOf(
    "زغال" to "coal_ore,deepslate_coal_ore", "آهن" to "iron_ore,deepslate_iron_ore", "طلا" to "gold_ore,deepslate_gold_ore",
    "الماس" to "diamond_ore,deepslate_diamond_ore", "چوب بلوط" to "oak_log", "سنگ" to "stone,cobblestone", "شن" to "sand,gravel"
)

@Composable
private fun ltr() = LocalTextStyle.current.copy(textDirection = TextDirection.Ltr)

@Composable
private fun SwitchLine(label: String, hint: String?, v: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label)
            if (hint != null) Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = v, onCheckedChange = onChange, enabled = enabled)
    }
}

/**
 * Automated behaviours (walk to coordinates, follow a player, patrol, anti-AFK, repeated message).
 * Movement never breaks or places blocks; its behaviour is tuned in the last tab.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActionsDialog(onDismiss: () -> Unit) {
    val session = Core.session
    val st by session.state.collectAsState()
    val prefs = Core.prefs
    var tab by remember { mutableStateOf(0) }
    var pos by remember { mutableStateOf(doubleArrayOf(0.0, 0.0, 0.0)) }
    LaunchedEffect(Unit) {
        while (true) {
            pos = doubleArrayOf(session.core.x(), session.core.y(), session.core.z())
            delay(400)
        }
    }

    var gx by remember { mutableStateOf("") }
    var gy by remember { mutableStateOf("") }
    var gz by remember { mutableStateOf("") }
    var ignoreY by remember { mutableStateOf(true) }
    var followName by remember { mutableStateOf("") }
    var followDist by remember { mutableStateOf(2.5f) }
    var patrolText by remember { mutableStateOf("") }
    var patrolLoop by remember { mutableStateOf(true) }
    var afkSec by remember { mutableStateOf("30") }
    var repText by remember { mutableStateOf("") }
    var repSec by remember { mutableStateOf("60") }
    var openGroup by remember { mutableStateOf("crafting_table") }
    var openCustom by remember { mutableStateOf("") }
    var mineBlocks by remember { mutableStateOf("") }
    var mineCount by remember { mutableStateOf("10") }
    var fx by remember { mutableStateOf("") }
    var fy by remember { mutableStateOf("") }
    var fz by remember { mutableStateOf("") }
    var wpName by remember { mutableStateOf("") }
    var wps by remember { mutableStateOf(session.waypoints()) }
    var error by remember { mutableStateOf("") }

    val online = st.status == Status.ONLINE

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth(0.96f).fillMaxHeight(0.92f), shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("اکشن‌ها", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    TextButton(onClick = onDismiss) { Text("بستن") }
                }
                Text(
                    "موقعیت شما: ${String.format(Locale.US, "%.1f  %.1f  %.1f", pos[0], pos[1], pos[2])}",
                    style = ltr().copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
                if (st.actionText.isNotEmpty()) {
                    Text((if (st.actionRunning) "▶ " else "■ ") + st.actionText, color = if (st.actionRunning) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (st.actionRunning) {
                    Button(
                        onClick = { session.stopAction() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error, contentColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("توقف اکشن") }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TABS.forEachIndexed { i, t -> FilterChip(selected = tab == i, onClick = { tab = i; error = "" }, label = { Text(t) }) }
                }
                HorizontalDivider()
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    when (tab) {
                        0 -> {
                            Text("بازیکن با کوتاه‌ترین مسیر به مختصات می‌رود: راه رفتن، پرش، افتادن مجاز، شنا، نردبان و در. کندن و گذاشتن بلاک فقط اگر در «تنظیمات حرکت» روشن باشد.", style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(gx, { gx = it }, Modifier.weight(1f), singleLine = true, label = { Text("X") }, textStyle = ltr())
                                OutlinedTextField(gy, { gy = it }, Modifier.weight(1f), singleLine = true, label = { Text("Y") }, textStyle = ltr(), enabled = !ignoreY)
                                OutlinedTextField(gz, { gz = it }, Modifier.weight(1f), singleLine = true, label = { Text("Z") }, textStyle = ltr())
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = ignoreY, onCheckedChange = { ignoreY = it })
                                Text("ارتفاع (Y) مهم نیست")
                            }
                            OutlinedButton(onClick = {
                                gx = Math.floor(pos[0]).toInt().toString(); gy = Math.floor(pos[1]).toInt().toString(); gz = Math.floor(pos[2]).toInt().toString()
                            }) { Text("پر کردن با موقعیت فعلی") }
                            Button(enabled = online, onClick = {
                                val x = gx.trim().toIntOrNull(); val z = gz.trim().toIntOrNull()
                                val y = if (ignoreY) 0 else gy.trim().toIntOrNull()
                                if (x == null || z == null || y == null) error = "مختصات را درست وارد کنید (عدد صحیح)"
                                else { error = ""; session.startGoTo(x, y, z, ignoreY) }
                            }, modifier = Modifier.fillMaxWidth()) { Text("شروع") }
                        }
                        1 -> {
                            OutlinedTextField(followName, { followName = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("نام بازیکن") }, textStyle = ltr())
                            if (st.players.isNotEmpty()) {
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    for (p in st.players) AssistChip(onClick = { followName = p }, label = { Text(p) })
                                }
                            }
                            Text("فاصله از بازیکن: ${String.format(Locale.US, "%.1f", followDist)} بلوک", style = MaterialTheme.typography.bodySmall)
                            Slider(followDist, { followDist = it }, valueRange = 1f..10f)
                            Text("فقط بازیکنی دنبال می‌شود که در محدودهٔ دید سرور باشد.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Button(enabled = online, onClick = {
                                if (followName.isBlank()) error = "نام بازیکن را وارد کنید" else { error = ""; session.startFollow(followName.trim(), followDist.toDouble()) }
                            }, modifier = Modifier.fillMaxWidth()) { Text("دنبال کردن") }
                            OutlinedButton(enabled = online, onClick = {
                                if (followName.isBlank()) error = "نام بازیکن را وارد کنید" else { error = ""; session.startGoToPlayer(followName.trim()) }
                            }, modifier = Modifier.fillMaxWidth()) { Text("فقط رفتن کنار بازیکن") }
                        }
                        2 -> {
                            Text("هر خط یک نقطه: x y z . بازیکن به ترتیب به نقطه‌ها می‌رود.", style = MaterialTheme.typography.bodySmall)
                            OutlinedTextField(patrolText, { patrolText = it }, Modifier.fillMaxWidth(), minLines = 3, label = { Text("نقطه‌ها") }, textStyle = ltr(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = patrolLoop, onCheckedChange = { patrolLoop = it })
                                Text("تکرار بی‌پایان")
                            }
                            Button(enabled = online, onClick = {
                                val pts = ArrayList<IntArray>()
                                var bad = false
                                for (line in patrolText.lines()) {
                                    if (line.isBlank()) continue
                                    val p = line.trim().split(Regex("[\\s,]+")).mapNotNull { it.toIntOrNull() }
                                    if (p.size == 3) pts.add(intArrayOf(p[0], p[1], p[2])) else bad = true
                                }
                                if (bad || pts.isEmpty()) error = "هر خط باید سه عدد x y z داشته باشد"
                                else { error = ""; session.startPatrol(pts, patrolLoop) }
                            }, modifier = Modifier.fillMaxWidth()) { Text("شروع") }
                        }
                        3 -> {
                            Text("هر چند ثانیه یک حرکت کوچک (چرخش، پرش، تکان دادن دست) انجام می‌شود تا سرور شما را AFK نکند.", style = MaterialTheme.typography.bodySmall)
                            OutlinedTextField(afkSec, { afkSec = it.filter { c -> c.isDigit() }.take(4) }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("فاصله (ثانیه)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                            Button(enabled = online, onClick = { session.startAntiAfk((afkSec.toIntOrNull() ?: 30).coerceAtLeast(1)) }, modifier = Modifier.fillMaxWidth()) { Text("شروع") }
                        }
                        4 -> {
                            Text("یک پیام یا دستور (با /) را در فاصلهٔ ثابت می‌فرستد.", style = MaterialTheme.typography.bodySmall)
                            OutlinedTextField(repText, { repText = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("پیام یا دستور") }, textStyle = ltr())
                            OutlinedTextField(repSec, { repSec = it.filter { c -> c.isDigit() }.take(5) }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("فاصله (ثانیه)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                            Button(enabled = online, onClick = {
                                if (repText.isBlank()) error = "متن را وارد کنید" else { error = ""; session.startRepeat(repText, (repSec.toIntOrNull() ?: 60).coerceAtLeast(1)) }
                            }, modifier = Modifier.fillMaxWidth()) { Text("شروع") }
                        }
                        5 -> {
                            Text("نزدیک‌ترین بلاک از نوع انتخابی را در چانک‌های بارگذاری‌شده پیدا می‌کند، کنارش می‌رود و راست‌کلیک می‌کند تا صفحه باز شود. بعد می‌توانید از اینونتوری با آن کار کنید (مثلاً کرفتینگ تیبل).", style = MaterialTheme.typography.bodySmall)
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                for ((k, label) in OPEN_LABELS) FilterChip(selected = openGroup == k && openCustom.isBlank(), onClick = { openGroup = k; openCustom = "" }, label = { Text(label) })
                            }
                            OutlinedTextField(openCustom, { openCustom = it.trim() }, Modifier.fillMaxWidth(), singleLine = true,
                                label = { Text("یا نام هر بلاک دیگر (مثلاً jukebox)") }, textStyle = ltr())
                            Button(enabled = online, onClick = {
                                error = ""
                                session.startOpenBlock(if (openCustom.isNotBlank()) openCustom else openGroup)
                            }, modifier = Modifier.fillMaxWidth()) { Text("پیدا کن و باز کن") }
                        }
                        6 -> {
                            Text("بلاک‌های انتخابی را می‌کند: کنارشان می‌رود، با ابزار مناسب هات‌بار می‌کند و داخل جا می‌رود تا آیتم را بردارد. (کندن بلاک هدف مستقل از تنظیم «کندن بلاک‌های سر راه» است.)", style = MaterialTheme.typography.bodySmall)
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                for ((label, v) in MINE_PRESETS) AssistChip(onClick = { mineBlocks = v }, label = { Text(label) })
                            }
                            OutlinedTextField(mineBlocks, { mineBlocks = it.trim() }, Modifier.fillMaxWidth(), singleLine = true,
                                label = { Text("نام بلاک‌ها، با کاما جدا (مثلاً diamond_ore)") }, textStyle = ltr())
                            OutlinedTextField(mineCount, { mineCount = it.filter { c -> c.isDigit() }.take(4) }, Modifier.fillMaxWidth(), singleLine = true,
                                label = { Text("تعداد (۰ = تا آخر)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                            Button(enabled = online, onClick = {
                                val names = mineBlocks.split(",").map { it.trim().removePrefix("minecraft:") }.filter { it.isNotEmpty() }
                                if (names.isEmpty()) error = "نام بلاک را وارد کنید"
                                else { error = ""; session.startMine(names.joinToString(" / "), names.toTypedArray(), mineCount.toIntOrNull() ?: 0) }
                            }, modifier = Modifier.fillMaxWidth()) { Text("شروع") }
                        }
                        7 -> {
                            Text("کاوش: در یک جهت می‌رود و به سمت نقشهٔ ناشناخته مسیر می‌زند؛ هر وقت راه بسته باشد می‌چرخد.", style = MaterialTheme.typography.bodySmall)
                            Button(enabled = online, onClick = { error = ""; session.startExplore() }, modifier = Modifier.fillMaxWidth()) { Text("شروع کاوش") }
                            HorizontalDivider()
                            Text("پرواز فقط در سرورهایی کار می‌کند که اجازه می‌دهند (مثلاً کریتیو یا دسترسی fly).", style = MaterialTheme.typography.bodySmall)
                            Text(if (session.mayFly) "سرور اجازهٔ پرواز داده است." else "سرور تاکنون اجازهٔ پرواز نداده است.",
                                color = if (session.mayFly) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(fx, { fx = it }, Modifier.weight(1f), singleLine = true, label = { Text("X") }, textStyle = ltr())
                                OutlinedTextField(fy, { fy = it }, Modifier.weight(1f), singleLine = true, label = { Text("Y") }, textStyle = ltr())
                                OutlinedTextField(fz, { fz = it }, Modifier.weight(1f), singleLine = true, label = { Text("Z") }, textStyle = ltr())
                            }
                            Button(enabled = online, onClick = {
                                val x = fx.trim().toDoubleOrNull(); val y = fy.trim().toDoubleOrNull(); val z = fz.trim().toDoubleOrNull()
                                if (x == null || y == null || z == null) error = "مختصات را درست وارد کنید"
                                else { error = ""; session.startFlyTo(x + 0.5, y, z + 0.5) }
                            }, modifier = Modifier.fillMaxWidth()) { Text("پرواز به مختصات") }
                            OutlinedButton(enabled = online && session.mayFly, onClick = { session.setFlying(!session.isFlying) }, modifier = Modifier.fillMaxWidth()) { Text("روشن/خاموش کردن پرواز") }
                        }
                        8 -> {
                            Text("موقعیت‌ها را برای هر سرور ذخیره کنید و بعداً به آن‌ها بروید.", style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(wpName, { wpName = it }, Modifier.weight(1f), singleLine = true, label = { Text("نام نقطه") })
                                Button(enabled = online && wpName.isNotBlank(), onClick = { session.saveWaypoint(wpName.trim()); wps = session.waypoints(); wpName = "" }) { Text("ذخیره اینجا") }
                            }
                            if (wps.isEmpty()) Text("نقطه‌ای ذخیره نشده است.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            for ((name, p) in wps) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Column(Modifier.weight(1f)) {
                                        Text(name, fontWeight = FontWeight.Bold)
                                        Text("${p[0]}  ${p[1]}  ${p[2]}", style = ltr().copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                                    }
                                    Button(enabled = online, onClick = { error = ""; session.goToWaypoint(name) }) { Text("برو") }
                                    TextButton(onClick = { session.deleteWaypoint(name); wps = session.waypoints() }) { Text("حذف") }
                                }
                            }
                        }
                        else -> {
                            SwitchLine("فیزیک بازیکن", "جاذبه و برخورد با بلوک‌ها؛ برای جلوگیری از کیک «Flying» روشن بماند.", prefs.physics) { prefs.setPhysics(it); session.applyConfig() }
                            SwitchLine("خوردن خودکار", "وقتی گرسنگی کم شد بهترین غذای هات‌بار خورده می‌شود (به‌جز غذاهای مضر).", prefs.autoEat) { prefs.setAutoEat(it); session.applyConfig() }
                            SwitchLine("اجازهٔ پرش", "بالا رفتن از پله‌ها و بلوک‌های یک‌واحدی.", prefs.navJump) { prefs.setNavJump(it); session.applyConfig() }
                            SwitchLine("حرکت مورب", null, prefs.navDiagonal) { prefs.setNavDiagonal(it); session.applyConfig() }
                            SwitchLine("دویدن (Sprint)", "سریع‌تر ولی ممکن است ضدچیت سرور را فعال کند.", prefs.navSprint) { prefs.setNavSprint(it); session.applyConfig() }
                            HorizontalDivider()
                            Text("مثل Baritone: کمترین مانع", fontWeight = FontWeight.Bold)
                            SwitchLine("شنا در آب", "آب مانع نیست؛ بازیکن روی آب شناور می‌شود و از آن بیرون می‌آید.", prefs.navSwim) { prefs.setNavSwim(it); session.applyConfig() }
                            SwitchLine("بالا رفتن از نردبان و تاک", null, prefs.navClimb) { prefs.setNavClimb(it); session.applyConfig() }
                            SwitchLine("باز کردن در و دروازه", "درهای بستهٔ چوبی با کلیک راست باز می‌شوند.", prefs.navDoors) { prefs.setNavDoors(it); session.applyConfig() }
                            SwitchLine(
                                "کندن بلاک‌های سر راه",
                                "ابزار مناسب از هات‌بار انتخاب می‌شود. صندوق، اسپاونر، بدراک و بلاک‌های کنار گدازه هرگز کنده نمی‌شوند. نیاز به داده‌های بلاک.",
                                prefs.navBreak
                            ) { prefs.setNavBreak(it); session.applyConfig() }
                            if (prefs.navBreak) {
                                Text("تمایل به کندن: هزینهٔ هر بلاک +${String.format(Locale.US, "%.0f", prefs.navBreakPenalty)} (بیشتر = بیشتر دور می‌زند)", style = MaterialTheme.typography.bodySmall)
                                Slider(prefs.navBreakPenalty, { prefs.setNavBreakPenalty(Math.round(it).toFloat()); session.applyConfig() }, valueRange = 0f..30f)
                            }
                            SwitchLine(
                                "گذاشتن بلاک (پل‌زدن و پله‌سازی)",
                                "برای عبور از شکاف و بالا رفتن؛ یک بلوک ارزان (کوبل‌استون، خاک، نترک و…) باید در هات‌بار باشد.",
                                prefs.navPlace
                            ) { prefs.setNavPlace(it); session.applyConfig() }
                            HorizontalDivider()
                            Text("حداکثر ارتفاع افتادن: ${prefs.navMaxFall} بلوک", style = MaterialTheme.typography.bodySmall)
                            Slider(prefs.navMaxFall.toFloat(), { prefs.setNavMaxFall(Math.round(it)); session.applyConfig() }, valueRange = 0f..10f, steps = 9)
                            Text("فاصلهٔ رسیدن به مقصد: ${String.format(Locale.US, "%.1f", prefs.navArrive)} بلوک", style = MaterialTheme.typography.bodySmall)
                            Slider(prefs.navArrive, { prefs.setNavArrive(Math.round(it * 2) / 2f); session.applyConfig() }, valueRange = 0.5f..5f)
                            Text("جستجوی مسیر دوباره اگر ${prefs.navStuck} ثانیه گیر کرد", style = MaterialTheme.typography.bodySmall)
                            Slider(prefs.navStuck.toFloat(), { prefs.setNavStuck(Math.round(it)); session.applyConfig() }, valueRange = 2f..20f)
                            Text(
                                "برای مسیریابی، اطلاعات بلاک‌های نسخهٔ ۱٫۲۰٫۴ لازم است (تنظیمات ← دانلود داده‌ها). بدون آن هر بلوک غیرهوا «جامد» فرض می‌شود.",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
                    if (!online && tab < 9) Text("برای شروع اکشن باید به سرور متصل باشید.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
