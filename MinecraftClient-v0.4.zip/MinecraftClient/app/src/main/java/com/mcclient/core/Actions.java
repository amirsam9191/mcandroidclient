package com.mcclient.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/** Automated behaviours, ticked at 20 Hz by the session. They drive the player only through keyboard-like input (forward/strafe/jump/sneak/sprint). */
public final class Actions {
    private Actions() {}

    public abstract static class Action {
        protected String status = "";
        public abstract String name();
        void start(ClientSession s) {}
        /** The server moved the player (join, rubber-band, /tp): drop any cached path. */
        void onTeleport() {}
        /** @return true when finished */
        abstract boolean tick(ClientSession s);
        public String status() { return status; }
        public boolean failed() { return false; }
    }

    // ------------------------------------------------------------------ work done before a move (dig / open / place)

    static final int RUNNING = 0, DONE = 1, FAILED = 2;

    abstract static class Task {
        abstract int tick(ClientSession s);
    }

    private static int faceToward(double px, double py, double pz, int bx, int by, int bz) {
        double dx = px - (bx + 0.5), dy = py - (by + 0.5), dz = pz - (bz + 0.5);
        double ax = Math.abs(dx), ay = Math.abs(dy), az = Math.abs(dz);
        if (ay >= ax && ay >= az) return dy > 0 ? 1 : 0;
        if (ax >= az) return dx > 0 ? 5 : 4;
        return dz > 0 ? 3 : 2;
    }

    private static void lookAtBlock(ClientSession s, int bx, int by, int bz) {
        Physics p = s.phys;
        double dx = bx + 0.5 - p.x, dz = bz + 0.5 - p.z, dy = by + 0.5 - (p.y + 1.62);
        s.setLook((float) Math.toDegrees(Math.atan2(-dx, dz)), (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz))));
    }

    /** Digs one block: picks the best hotbar tool, starts, waits ~75% of the vanilla time, finishes, and checks the world. */
    static final class DigTask extends Task {
        final int[] c;
        int stage, ticks, need, wait, tries;
        DigTask(int[] c) { this.c = c; }

        @Override int tick(ClientSession s) {
            World w = s.world;
            if (!w.obstacle(c[0], c[1], c[2])) return DONE;
            lookAtBlock(s, c[0], c[1], c[2]);
            Physics p = s.phys;
            if (Math.sqrt(Math.pow(c[0] + 0.5 - p.x, 2) + Math.pow(c[1] + 0.5 - (p.y + 1.62), 2) + Math.pow(c[2] + 0.5 - p.z, 2)) > 5.5) return FAILED;
            switch (stage) {
                case 0: {
                    int slot = Tools.bestSlot(s.inventory, w.blockName(c[0], c[1], c[2]));
                    if (slot >= 0 && slot != s.inventory.heldSlot()) { s.selectSlotNow(slot); wait = 2; }
                    stage = 1;
                    break;
                }
                case 1: {
                    if (wait > 0) { wait--; break; }
                    int face = faceToward(p.x, p.y + 1.62, p.z, c[0], c[1], c[2]);
                    s.sendDig(0, c[0], c[1], c[2], face);
                    need = Tools.breakTicks(w.hardness(c[0], c[1], c[2]), w.blockName(c[0], c[1], c[2]), s.inventory.hotbarItemName(s.inventory.heldSlot()));
                    ticks = 0;
                    stage = 2;
                    break;
                }
                case 2: {
                    ticks++;
                    if (ticks % 5 == 1) s.swingNow();
                    if (ticks >= (int) Math.ceil(need * 0.75) + 1) {
                        int face = faceToward(p.x, p.y + 1.62, p.z, c[0], c[1], c[2]);
                        s.sendDig(2, c[0], c[1], c[2], face);
                        stage = 3;
                        ticks = 0;
                    }
                    break;
                }
                default: {
                    if (++ticks > 25) {
                        if (++tries > 3) return FAILED;
                        stage = 1;
                        wait = 1;
                    }
                }
            }
            return RUNNING;
        }
    }

    /** Right-clicks a closed door / gate until it opens. */
    static final class OpenTask extends Task {
        final int[] c;
        int ticks, tries;
        OpenTask(int[] c) { this.c = c; }

        @Override int tick(ClientSession s) {
            if (!s.world.closedDoor(c[0], c[1], c[2])) return DONE;
            Physics p = s.phys;
            lookAtBlock(s, c[0], c[1], c[2]);
            if (ticks == 0) {
                int face = faceToward(p.x, p.y + 1.0, p.z, c[0], c[1], c[2]);
                s.sendUseOn(c[0], c[1], c[2], face, 0.5f, 0.5f, 0.5f);
            }
            if (++ticks > 20) { ticks = 0; if (++tries > 2) return FAILED; }
            return RUNNING;
        }
    }

    private static float[] cursorFor(int face) {
        switch (face) {
            case 0: return new float[]{0.5f, 0f, 0.5f};
            case 1: return new float[]{0.5f, 1f, 0.5f};
            case 2: return new float[]{0.5f, 0.5f, 0f};
            case 3: return new float[]{0.5f, 0.5f, 1f};
            case 4: return new float[]{0f, 0.5f, 0.5f};
            default: return new float[]{1f, 0.5f, 0.5f};
        }
    }

    /** Places a throwaway block (bridging); with {@code pillar} the player jumps first and places underneath. */
    static final class PlaceTask extends Task {
        final int[] pl;
        final boolean pillar;
        final int landY;
        int stage, ticks, wait, tries;
        PlaceTask(int[] pl, boolean pillar, int landY) { this.pl = pl; this.pillar = pillar; this.landY = landY; }

        @Override int tick(ClientSession s) {
            World w = s.world;
            Physics p = s.phys;
            if (w.obstacle(pl[0], pl[1], pl[2])) {
                if (!pillar) return DONE;
                return (p.onGround && Math.abs(p.y - landY) < 0.05) ? DONE : RUNNING;
            }
            switch (stage) {
                case 0: {
                    int slot = Tools.throwawaySlot(s.inventory);
                    if (slot < 0) return FAILED;
                    if (slot != s.inventory.heldSlot()) { s.selectSlotNow(slot); wait = 2; }
                    stage = 1;
                    break;
                }
                case 1: {
                    if (wait > 0) { wait--; break; }
                    if (pillar) {
                        s.setLook(s.yaw(), 90f);
                        if (p.onGround) s.requestJump(true);
                        else if (p.y >= pl[1] + 1.02) { place(s); stage = 2; ticks = 0; }
                    } else {
                        lookAtBlock(s, pl[0], pl[1], pl[2]);
                        place(s);
                        stage = 2;
                        ticks = 0;
                    }
                    break;
                }
                default: {
                    if (pillar && !p.onGround) break;
                    if (++ticks > 20) { if (++tries > 3) return FAILED; stage = 1; wait = 1; }
                }
            }
            return RUNNING;
        }

        private void place(ClientSession s) {
            float[] c = cursorFor(pl[6]);
            s.sendUseOn(pl[3], pl[4], pl[5], pl[6], c[0], c[1], c[2]);
        }
    }

    private static float yawTo(double dx, double dz) { return (float) Math.toDegrees(Math.atan2(-dx, dz)); }

    /** Follows a computed path with the real physics (walk, jump, fall, swim, climb) and the work (dig/open/place) attached to each step. */
    static final class Walker {
        List<Pathfinder.Step> steps = new ArrayList<>();
        int idx;
        boolean complete;
        private double lastProgressDist = Double.MAX_VALUE;
        private int stuckTicks;
        private Task task;

        void reset() { steps = new ArrayList<>(); idx = 0; task = null; stuckTicks = 0; lastProgressDist = Double.MAX_VALUE; complete = false; }

        boolean plan(ClientSession s, int gx, int gy, int gz, boolean ignoreY, double radius) {
            Goals.Goal g;
            if (ignoreY) g = radius <= 0 ? new Goals.GoalXZ(gx, gz) : new Goals.GoalXZNear(gx, gz, radius);
            else g = radius < 1 ? new Goals.GoalBlock(gx, gy, gz) : new Goals.GoalNear(gx, gy, gz, (int) Math.floor(radius));
            return plan(s, g);
        }

        boolean plan(ClientSession s, Goals.Goal goal) {
            Physics p = s.phys;
            s.nav().hasThrowaway = Tools.throwawaySlot(s.inventory) >= 0;
            Pathfinder.Result r = Pathfinder.find(s.world, (int) Math.floor(p.x), (int) Math.floor(p.y + 1e-6), (int) Math.floor(p.z), goal, s.nav());
            reset();
            steps = r.steps; complete = r.complete;
            return !steps.isEmpty();
        }

        boolean finished() { return idx >= steps.size(); }

        private static boolean valid(World w, Pathfinder.Step st) {
            switch (st.kind) {
                case DIG_DOWN: case PILLAR: return true;
                case SWIM: return w.water(st.x, st.y, st.z) || w.passable(st.x, st.y, st.z);
                case CLIMB: return w.climbable(st.x, st.y, st.z) || w.passable(st.x, st.y, st.z);
                default:
                    if (!w.isLoaded(st.x, st.z)) return true;
                    if (st.place != null) return true;
                    return w.standable(st.x, st.y - 1, st.z) || w.water(st.x, st.y, st.z) || w.passable(st.x, st.y, st.z) && w.isLowStepAt(st.x, st.y, st.z);
            }
        }

        private Task nextTask(ClientSession s, Pathfinder.Step st) {
            World w = s.world;
            for (int[] b : st.breaks) if (w.obstacle(b[0], b[1], b[2])) return new DigTask(b);
            for (int[] o : st.opens) if (w.closedDoor(o[0], o[1], o[2])) return new OpenTask(o);
            if (st.place != null && !w.obstacle(st.place[0], st.place[1], st.place[2])) return new PlaceTask(st.place, st.kind == Pathfinder.Kind.PILLAR, st.y);
            if (st.kind == Pathfinder.Kind.PILLAR && st.place != null && !(s.phys.onGround && Math.abs(s.phys.y - st.y) < 0.05)) return new PlaceTask(st.place, true, st.y);
            return null;
        }

        /** Did the player get to this step? Intermediate nodes use a tolerance (tight before a turn); the last one needs standing still. */
        private boolean reached(ClientSession s, int i) {
            Pathfinder.Step n = steps.get(i);
            Physics p = s.phys;
            double tx = n.x + 0.5, tz = n.z + 0.5;
            double hd = Math.hypot(p.x - tx, p.z - tz);
            boolean last = i == steps.size() - 1;
            double fy = s.world.feetY(n.x, n.y, n.z);
            switch (n.kind) {
                case SWIM: return hd < 0.45 && p.y >= n.y - 0.3 && p.y <= n.y + 1.0;
                case CLIMB: return hd < 0.45 && Math.abs(p.y - n.y) < 0.35;
                case DIG_DOWN: case PILLAR: return p.onGround && Math.abs(p.y - fy) < 0.1;
                case FALL:
                    if (p.inWater() && s.world.water(n.x, n.y, n.z)) return hd < 1.0 && p.y >= n.y - 0.5 && p.y <= n.y + 1.0; // dropped into water
                    return p.onGround && Math.abs(p.y - fy) < 0.15 && hd < 1.0;
                case JUMP: return p.onGround && Math.abs(p.y - fy) < 0.15 && hd < (last ? 0.3 : 0.5);
                default: {
                    boolean turn = false;
                    if (!last) {
                        Pathfinder.Step nx = steps.get(i + 1);
                        int px = i > 0 ? steps.get(i - 1).x : (int) Math.floor(p.x), pz = i > 0 ? steps.get(i - 1).z : (int) Math.floor(p.z);
                        turn = nx.x - n.x != n.x - px || nx.z - n.z != n.z - pz || nx.needsWork() || (nx.kind != Pathfinder.Kind.WALK);
                    }
                    double tol = last ? 0.3 : (turn ? 0.25 : 0.5);
                    boolean level = Math.abs(p.y - fy) < 0.6 || p.inWater();
                    return level && hd < tol && (!last || p.onGround || p.inWater());
                }
            }
        }

        /** Advances one tick. Returns true when the whole path has been walked. */
        boolean step(ClientSession s) {
            if (finished()) return true;
            Physics p = s.phys;
            NavConfig nav = s.nav();
            Physics.Input in = s.input();
            Pathfinder.Step st = steps.get(idx);
            if (!valid(s.world, st)) { stuckTicks = 1_000_000; return false; }
            if (task == null) task = nextTask(s, st);
            if (task != null) {
                int r = task.tick(s);
                if (r == DONE) task = null; else if (r == FAILED) { task = null; stuckTicks = 1_000_000; }
                return false;
            }
            int guard = 0;
            while (!finished() && guard++ < 4 && reached(s, idx)) idx++;
            if (finished()) return true;
            Pathfinder.Step n = steps.get(idx);
            if (nextTask(s, n) != null) return false; // work is pending on the new step: stand still, the task starts next tick
            drive(s, n, in, nav, p);
            double d = Math.hypot(p.x - (n.x + 0.5), p.z - (n.z + 0.5)) + Math.abs(p.y - n.y);
            if (d < lastProgressDist - 0.02) { lastProgressDist = d; stuckTicks = 0; } else stuckTicks++;
            return false;
        }

        private void drive(ClientSession s, Pathfinder.Step n, Physics.Input in, NavConfig nav, Physics p) {
            double tx = n.x + 0.5, tz = n.z + 0.5;
            double dx = tx - p.x, dz = tz - p.z, hd = Math.hypot(dx, dz);
            double fy = s.world.feetY(n.x, n.y, n.z);
            if (hd > 0.05) s.setLook(yawTo(dx, dz), 0f);
            boolean last = idx == steps.size() - 1;
            in.forward = 1;
            switch (n.kind) {
                case SWIM:
                    // players stay afloat by holding jump; only a deliberate dive (target 1+ block lower) lets go and sneaks down
                    boolean dive = p.y - n.y > 0.9;
                    in.jump = !dive;
                    in.sneak = dive;
                    if (hd < 0.3) in.forward = 0;
                    break;
                case CLIMB:
                    in.jump = n.y > p.y + 0.05;
                    in.sneak = false;
                    if (hd < 0.3) in.forward = 0;
                    break;
                case FALL:
                    if (p.inWater()) in.jump = true; // splashed down: stay afloat
                    break;
                case JUMP:
                    in.jump = p.onGround && (hd < 1.35 || p.horizontalCollision);
                    if (p.inWater()) in.jump = true;
                    in.sprint = nav.sprint && !p.inWater();
                    break;
                default:
                    if (p.inWater()) in.jump = true; // swim out of the water onto the bank
                    else if (fy - p.y > 0.6 && p.onGround) in.jump = true;
                    in.sprint = nav.sprint && !p.inWater();
                    // brake in front of the final cell instead of overshooting
                    if (last && p.onGround && hd < (in.sprint ? 0.34 : 0.26)) { in.forward = 0; in.sprint = false; }
            }
        }

        boolean stuck(NavConfig nav) { return stuckTicks > nav.stuckSeconds * 20; }
    }

    // ------------------------------------------------------------------ GoTo

    /** Walks to a coordinate (legacy constructor) or to any cell accepted by a {@link Goals.Goal}. */
    public static final class GoTo extends Action {
        private final int gx, gy, gz;
        private final boolean ignoreY;
        private final Goals.Goal goal;
        private final String label;
        private final Walker w = new Walker();
        private int replans;
        private boolean failed;
        private boolean needPlan = true;

        public GoTo(int x, int y, int z, boolean ignoreY) { gx = x; gy = y; gz = z; this.ignoreY = ignoreY; goal = null; label = null; }
        public GoTo(Goals.Goal goal, String label) { this.goal = goal; this.label = label; gx = gy = gz = 0; ignoreY = false; }
        @Override public String name() { return goal != null ? label : "رفتن به " + gx + " " + (ignoreY ? "~" : String.valueOf(gy)) + " " + gz; }
        @Override public boolean failed() { return failed; }
        @Override void onTeleport() { needPlan = true; }

        private boolean arrived(ClientSession s) {
            Physics p = s.phys;
            // standing still counts (on the ground or floating in water), not a jump or a ladder in mid-climb
            if (!(p.onGround || p.inWater())) return false;
            if (goal != null) return goal.isInGoal((int) Math.floor(p.x), (int) Math.floor(p.y + 1e-6), (int) Math.floor(p.z));
            double dy = ignoreY ? 0 : p.y - gy;
            double r = Math.max(s.nav().arriveDistance, 0.5) + 0.75;
            double dx = p.x - (gx + 0.5), dz = p.z - (gz + 0.5);
            return dx * dx + dz * dz <= r * r && Math.abs(dy) <= Math.max(s.nav().arriveDistance, 0.5) + 0.3;
        }

        @Override boolean tick(ClientSession s) {
            if (arrived(s)) { status = "رسیدید"; return true; }
            if (needPlan || w.stuck(s.nav())) {
                if (replans > s.nav().maxReplans) { status = "گیر کرد؛ مسیر دیگری پیدا نشد"; failed = true; return true; }
                boolean ok = goal != null ? w.plan(s, goal) : w.plan(s, gx, gy, gz, ignoreY, s.nav().arriveDistance);
                if (!ok) { status = "مسیری پیدا نشد (یا قسمتی از نقشه هنوز بارگذاری نشده)"; failed = true; return true; }
                replans++;
                needPlan = false;
                status = (w.complete ? "مسیر پیدا شد: " : "مسیر ناقص: ") + w.steps.size() + " قدم";
            }
            if (w.step(s)) {
                if (arrived(s)) { status = "رسیدید"; return true; }
                if (replans > s.nav().maxReplans) { status = "مقصد در دسترس نیست"; failed = true; return true; }
                needPlan = true;
            }
            return false;
        }
    }

    // ------------------------------------------------------------------ open any block that has a screen (ender chest, crafting table, furnace...)

    /** Block groups for the "open" action. */
    public static final Map<String, String[]> GUI_BLOCKS = new LinkedHashMap<>();
    static {
        GUI_BLOCKS.put("ender_chest", new String[]{"ender_chest"});
        GUI_BLOCKS.put("crafting_table", new String[]{"crafting_table"});
        GUI_BLOCKS.put("chest", new String[]{"chest", "trapped_chest", "barrel"});
        GUI_BLOCKS.put("furnace", new String[]{"furnace", "blast_furnace", "smoker"});
        GUI_BLOCKS.put("anvil", new String[]{"anvil", "chipped_anvil", "damaged_anvil"});
        GUI_BLOCKS.put("enchanting_table", new String[]{"enchanting_table"});
        GUI_BLOCKS.put("brewing_stand", new String[]{"brewing_stand"});
        GUI_BLOCKS.put("loom", new String[]{"loom"});
        GUI_BLOCKS.put("stonecutter", new String[]{"stonecutter"});
        GUI_BLOCKS.put("grindstone", new String[]{"grindstone"});
        GUI_BLOCKS.put("smithing_table", new String[]{"smithing_table"});
        GUI_BLOCKS.put("cartography_table", new String[]{"cartography_table"});
        GUI_BLOCKS.put("hopper", new String[]{"hopper"});
        GUI_BLOCKS.put("dispenser", new String[]{"dispenser", "dropper"});
        GUI_BLOCKS.put("beacon", new String[]{"beacon"});
        GUI_BLOCKS.put("lectern", new String[]{"lectern"});
        GUI_BLOCKS.put("shulker_box", new String[]{"shulker_box", "white_shulker_box", "orange_shulker_box", "magenta_shulker_box", "light_blue_shulker_box",
            "yellow_shulker_box", "lime_shulker_box", "pink_shulker_box", "gray_shulker_box", "light_gray_shulker_box", "cyan_shulker_box",
            "purple_shulker_box", "blue_shulker_box", "brown_shulker_box", "green_shulker_box", "red_shulker_box", "black_shulker_box"});
    }

    /** Finds the nearest block of the given kind, walks next to it (GoalGetToBlock) and right-clicks it until a screen opens. */
    public static final class OpenBlock extends Action {
        private final Set<String> names;
        private final String label;
        private final int radius;
        private final Walker w = new Walker();
        private List<int[]> targets = new ArrayList<>();
        private Goals.Goal goal;
        private int phase, ticks, tries, replans;
        private boolean failed;
        private int[] used;

        public OpenBlock(String label, String[] blockNames, int radius) { this.label = label; this.names = new HashSet<>(Arrays.asList(blockNames)); this.radius = radius; }
        public OpenBlock(String groupKey) { this(groupKey, GUI_BLOCKS.containsKey(groupKey) ? GUI_BLOCKS.get(groupKey) : new String[]{groupKey}, 64); }
        @Override public String name() { return "باز کردن " + label; }
        @Override public boolean failed() { return failed; }
        @Override void onTeleport() { if (phase == 1) { phase = 0; w.reset(); } }

        private int[] inReach(ClientSession s) {
            Physics p = s.phys;
            int cx = (int) Math.floor(p.x), cy = (int) Math.floor(p.y + 1e-6), cz = (int) Math.floor(p.z);
            for (int[] t : targets) if (new Goals.GoalGetToBlock(t[0], t[1], t[2]).isInGoal(cx, cy, cz)) return t;
            return null;
        }

        @Override boolean tick(ClientSession s) {
            if (s.inventory.open() != null && phase >= 2) { status = "باز شد"; return true; }
            switch (phase) {
                case 0: {
                    targets = s.world.findBlocks(names, s.phys.x, s.phys.y, s.phys.z, radius, 12);
                    if (targets.isEmpty()) { status = "«" + label + "» در اطراف (چانک‌های بارگذاری‌شده) پیدا نشد"; failed = true; return true; }
                    List<Goals.Goal> gs = new ArrayList<>();
                    for (int[] t : targets) gs.add(new Goals.GoalGetToBlock(t[0], t[1], t[2]));
                    goal = new Goals.GoalComposite(gs);
                    if (inReach(s) != null && (s.phys.onGround || s.phys.inWater())) { phase = 2; ticks = 0; break; }
                    if (!w.plan(s, goal)) { status = "مسیری به «" + label + "» پیدا نشد"; failed = true; return true; }
                    status = "در راه " + label + " (" + targets.size() + " مورد، " + w.steps.size() + " قدم)";
                    phase = 1;
                    break;
                }
                case 1: {
                    if ((s.phys.onGround || s.phys.inWater()) && inReach(s) != null) { phase = 2; ticks = 0; break; }
                    if (w.stuck(s.nav()) || w.finished()) {
                        if (++replans > s.nav().maxReplans) { status = "به «" + label + "» نرسید"; failed = true; return true; }
                        phase = 0;
                        break;
                    }
                    w.step(s);
                    break;
                }
                case 2: {
                    used = inReach(s);
                    if (used == null) { phase = 0; break; }
                    lookAtBlock(s, used[0], used[1], used[2]);
                    int face = faceToward(s.phys.x, s.phys.y + 1.0, s.phys.z, used[0], used[1], used[2]);
                    s.input().sneak = false;
                    if (ticks++ >= 1) {
                        float[] c = cursorFor(face);
                        s.sendUseOn(used[0], used[1], used[2], face, c[0], c[1], c[2]);
                        s.swingNow();
                        phase = 3; ticks = 0;
                    }
                    break;
                }
                default: {
                    if (++ticks > 30) { if (++tries > 3) { status = "صفحهٔ «" + label + "» باز نشد (دسترسی؟)"; failed = true; return true; } phase = 2; ticks = 0; }
                }
            }
            return false;
        }
    }

    // ------------------------------------------------------------------ Mine

    /** Mines blocks of the given kinds: walks next to the nearest one, digs it, steps in to pick the drop up, repeats. */
    public static final class Mine extends Action {
        private final Set<String> names;
        private final String label;
        private final int count;
        private final Walker w = new Walker();
        private final Set<Long> bad = new HashSet<>();
        private int[] target;
        private Task dig;
        private int phase, mined, replans, ticks;
        private boolean failed;

        public Mine(String label, String[] blockNames, int count) { this.label = label; names = new HashSet<>(Arrays.asList(blockNames)); this.count = count; }
        @Override public String name() { return "کندن " + label + (count > 0 ? " ×" + count : ""); }
        @Override public boolean failed() { return failed; }
        @Override void onTeleport() { if (phase == 1) { phase = 0; w.reset(); } }

        private static long k(int[] t) { return ((long) t[0] & 0x3FFFFFF) << 38 | ((long) t[2] & 0x3FFFFFF) << 12 | (t[1] + 2048 & 0xFFF); }

        @Override boolean tick(ClientSession s) {
            if (count > 0 && mined >= count) { status = mined + " بلاک کنده شد"; return true; }
            Physics p = s.phys;
            switch (phase) {
                case 0: {
                    target = null;
                    for (int[] t : s.world.findBlocks(names, p.x, p.y, p.z, 48, 24)) if (!bad.contains(k(t))) { target = t; break; }
                    if (target == null) { status = mined > 0 ? mined + " بلاک کنده شد؛ بلاک دیگری پیدا نشد" : "«" + label + "» پیدا نشد"; failed = mined == 0; return true; }
                    int cx = (int) Math.floor(p.x), cy = (int) Math.floor(p.y + 1e-6), cz = (int) Math.floor(p.z);
                    Goals.Goal g = new Goals.GoalGetToBlock(target[0], target[1], target[2]);
                    if (g.isInGoal(cx, cy, cz)) { phase = 2; dig = new DigTask(target); break; }
                    if (!w.plan(s, g)) { bad.add(k(target)); break; }
                    status = "در راه " + label + " (" + mined + " کنده شد)";
                    phase = 1; replans = 0;
                    break;
                }
                case 1: {
                    int cx = (int) Math.floor(p.x), cy = (int) Math.floor(p.y + 1e-6), cz = (int) Math.floor(p.z);
                    if ((p.onGround || p.inWater()) && new Goals.GoalGetToBlock(target[0], target[1], target[2]).isInGoal(cx, cy, cz)) { phase = 2; dig = new DigTask(target); break; }
                    if (w.stuck(s.nav()) || w.finished()) {
                        if (++replans > s.nav().maxReplans) { bad.add(k(target)); phase = 0; break; }
                        if (!w.plan(s, new Goals.GoalGetToBlock(target[0], target[1], target[2]))) { bad.add(k(target)); phase = 0; }
                        break;
                    }
                    w.step(s);
                    break;
                }
                case 2: {
                    int r = dig.tick(s);
                    status = "در حال کندن " + label;
                    if (r == DONE) { mined++; phase = 3; ticks = 0; }
                    else if (r == FAILED) { bad.add(k(target)); phase = 0; }
                    break;
                }
                default: {
                    // step into the hole so the dropped item is picked up
                    if (++ticks == 1) {
                        if (!w.plan(s, new Goals.GoalBlock(target[0], target[1], target[2])) ) { phase = 0; break; }
                    }
                    if (ticks > 60 || w.finished() || w.stuck(s.nav())) { phase = 0; break; }
                    w.step(s);
                }
            }
            return false;
        }
    }

    // ------------------------------------------------------------------ Follow / go to a player

    public static final class Follow extends Action {
        private final String target;
        private final double keep;
        private final boolean once;
        private final Walker w = new Walker();
        private double[] planned;
        private int tick, missingTicks;

        public Follow(String player, double keepDistance) { this(player, keepDistance, false); }
        /** {@code once}: finish as soon as the player is within {@code keepDistance}. */
        public Follow(String player, double keepDistance, boolean once) { target = player; keep = keepDistance; this.once = once; }
        @Override public String name() { return (once ? "رفتن به " : "دنبال کردن ") + target; }
        @Override void onTeleport() { planned = null; w.reset(); }

        @Override boolean tick(ClientSession s) {
            tick++;
            double[] t = s.entityPos(target);
            if (t == null) {
                status = "بازیکن «" + target + "» نزدیک نیست";
                return ++missingTicks > 20 * (once ? 10 : 60);
            }
            missingTicks = 0;
            Physics p = s.phys;
            double dist = Math.hypot(t[0] - p.x, t[2] - p.z);
            if (dist <= keep) {
                status = "کنار " + target;
                if (once) return true;
                s.setLook(yawTo(t[0] - p.x, t[2] - p.z), 0f);
                return false;
            }
            boolean moved = planned == null || Math.hypot(t[0] - planned[0], t[2] - planned[2]) > 2.0;
            if (tick % 10 == 1 && (moved || w.finished() || w.stuck(s.nav()))) {
                if (w.plan(s, (int) Math.floor(t[0]), (int) Math.floor(t[1] + 1e-6), (int) Math.floor(t[2]), false, keep)) planned = t.clone();
                else status = "مسیری به " + target + " پیدا نشد";
            }
            if (!w.finished()) { w.step(s); status = (once ? "در راه " : "در حال دنبال کردن ") + target; }
            return false;
        }
    }

    // ------------------------------------------------------------------ Explore

    /** Heads in one direction, planning toward unknown terrain (the planner leads to the closest loaded cell), turning when blocked. */
    public static final class Explore extends Action {
        private final Walker w = new Walker();
        private final Random rnd = new Random();
        private double heading;
        private int legs, blocked, ticks;
        private int startChunks = -1;

        public Explore() { heading = rnd.nextDouble() * 360; }
        @Override public String name() { return "کاوش (explore)"; }
        @Override void onTeleport() { w.reset(); }

        @Override boolean tick(ClientSession s) {
            Physics p = s.phys;
            if (startChunks < 0) startChunks = s.world.chunkCount();
            ticks++;
            if (w.finished() || w.stuck(s.nav())) {
                double a = Math.toRadians(heading);
                int tx = (int) Math.floor(p.x - Math.sin(a) * 64), tz = (int) Math.floor(p.z + Math.cos(a) * 64);
                boolean ok = w.plan(s, new Goals.GoalXZ(tx, tz)) && w.steps.size() >= 2;
                if (!ok) { blocked++; heading += 90 + rnd.nextInt(90); }
                else { blocked = 0; legs++; heading += (rnd.nextDouble() - 0.5) * 40; }
                if (blocked > 8) { status = "راه بازی برای کاوش پیدا نشد"; return true; }
            }
            if (!w.finished()) w.step(s);
            if (ticks % 20 == 0) status = "کاوش: " + (s.world.chunkCount() - startChunks) + " چانک جدید، " + legs + " مسیر";
            return false;
        }
    }

    // ------------------------------------------------------------------ Fly

    /** Straight-line creative flight (only where the server allows it): up to a safe height, across, then down. */
    public static final class FlyTo extends Action {
        private final double x, y, z;
        private final double cruise;
        private int ticks;
        private boolean failed;

        public FlyTo(double x, double y, double z) { this.x = x; this.y = y; this.z = z; cruise = Math.max(y, 0); }
        @Override public String name() { return "پرواز به " + (int) x + " " + (int) y + " " + (int) z; }
        @Override public boolean failed() { return failed; }

        @Override boolean tick(ClientSession s) {
            Physics p = s.phys;
            if (!p.mayFly) { status = "این سرور اجازهٔ پرواز نمی‌دهد"; failed = true; return true; }
            if (!p.flying) { if (ticks++ % 10 == 0) s.setFlyingNow(true); }
            Physics.Input in = s.input();
            double dx = x - p.x, dz = z - p.z, hd = Math.hypot(dx, dz);
            double want = hd > 3 ? Math.max(y, p.y < y + 1 ? y + 1 : p.y) : y;
            if (hd > 0.5) s.setLook(yawTo(dx, dz), 0f);
            in.jump = p.y < want - 0.3;
            in.sneak = p.y > want + 0.6 && hd < 3;
            in.forward = hd > 0.6 ? 1 : 0;
            in.sprint = hd > 8;
            // a wall in front: climb over it
            if (p.horizontalCollision) in.jump = true;
            status = "در حال پرواز؛ فاصله " + (int) hd;
            if (hd < 1.2 && Math.abs(p.y - y) < 1.5) { status = "به مقصد رسیدید"; return true; }
            return false;
        }
    }

    // ------------------------------------------------------------------ Waypoint helpers

    public static GoTo goToWaypoint(String name, int[] pos) { return new GoTo(pos[0], pos[1], pos[2], false); }

    // ------------------------------------------------------------------ Anti-AFK

    public static final class AntiAfk extends Action {
        private final int interval;
        private int ticks;
        private final Random rnd = new Random();

        public AntiAfk(int intervalSec) { interval = Math.max(1, intervalSec) * 20; }
        @Override public String name() { return "ضد AFK"; }

        @Override boolean tick(ClientSession s) {
            if (++ticks % interval == 0) {
                s.setLook(s.yaw() + (rnd.nextFloat() - 0.5f) * 60f, Math.max(-60f, Math.min(60f, s.pitch() + (rnd.nextFloat() - 0.5f) * 20f)));
                s.requestJump(true);
                s.swingNow();
                status = "حرکت کوچک انجام شد";
            } else if (ticks == 1) status = "فعال (هر " + (interval / 20) + " ثانیه)";
            return false;
        }
    }

    // ------------------------------------------------------------------ Repeat message/command

    public static final class RepeatText extends Action {
        private final String text;
        private final int interval;
        private int ticks;
        private int sent;

        public RepeatText(String text, int intervalSec) { this.text = text; interval = Math.max(1, intervalSec) * 20; }
        @Override public String name() { return "ارسال تکراری: " + text; }

        @Override boolean tick(ClientSession s) {
            if (ticks++ % interval == 0) { s.sendTextNow(text); sent++; }
            status = sent + " بار ارسال شد";
            return false;
        }
    }

    // ------------------------------------------------------------------ Patrol

    public static final class Patrol extends Action {
        private final List<int[]> points;
        private final boolean loop;
        private int i;
        private GoTo current;

        public Patrol(List<int[]> points, boolean loop) { this.points = points; this.loop = loop; }
        @Override public String name() { return "گشت‌زنی (" + points.size() + " نقطه)"; }
        @Override void onTeleport() { if (current != null) current.onTeleport(); }

        @Override boolean tick(ClientSession s) {
            if (points.isEmpty()) return true;
            if (current == null) current = new GoTo(points.get(i)[0], points.get(i)[1], points.get(i)[2], false);
            boolean done = current.tick(s);
            status = "نقطهٔ " + (i + 1) + " از " + points.size() + ": " + current.status();
            if (done) {
                current = null;
                i++;
                if (i >= points.size()) { if (!loop) return true; i = 0; }
            }
            return false;
        }
    }

    // ------------------------------------------------------------------ Look

    public static final class LookAt extends Action {
        private final double x, y, z;
        public LookAt(double x, double y, double z) { this.x = x; this.y = y; this.z = z; }
        @Override public String name() { return "نگاه کردن"; }
        @Override boolean tick(ClientSession s) {
            Physics p = s.phys;
            double dx = x - p.x, dz = z - p.z, dy = y - (p.y + 1.62);
            s.setLook((float) Math.toDegrees(Math.atan2(-dx, dz)), (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz))));
            return true;
        }
    }

    // ------------------------------------------------------------------ auto eat

    /** Eats the best food in the inventory when hungry. Called by the session every tick; returns true while busy (the player stands still). */
    public static final class Eater {
        private int phase, ticks;
        private int cooldown;

        public boolean tick(ClientSession s) {
            if (cooldown > 0) cooldown--;
            if (phase == 0) {
                if (cooldown > 0 || s.food > 14 || s.food <= 0 || s.health <= 0 || s.inventory.open() != null) return false;
                int slot = Tools.foodSlot(s.inventory);
                if (slot < 0) { cooldown = 200; return false; }
                if (slot != s.inventory.heldSlot()) s.selectSlotNow(slot);
                phase = 1; ticks = 0;
                return true;
            }
            ticks++;
            if (ticks == 2) s.useItemNow();
            if (ticks > 40) { phase = 0; cooldown = 20; return false; }
            return true;
        }
        public void reset() { phase = 0; ticks = 0; }
    }
}
