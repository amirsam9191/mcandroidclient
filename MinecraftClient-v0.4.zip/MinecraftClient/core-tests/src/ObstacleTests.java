import com.mcclient.core.*;
import java.util.*;
import java.util.concurrent.*;

/** Baritone-style obstacle handling: dig, bridge, pillar, swim, climb, doors — planner unit tests and server-simulated runs. */
public final class ObstacleTests {
    // state ids used by the test registry
    static final int AIR = 0, STONE = 1, DIRT = 2, BEDROCK = 3, COBBLE = 5, WATER = 10, LAVA = 11, LADDER = 12, CHEST = 100;
    static int doorState(boolean upper, boolean open) { return 20 + (upper ? 0 : 8) + (open ? 0 : 2) + 1; }  // facing north, hinge left, unpowered

    static final String BLOCKS = "[" +
        "{\"id\":0,\"name\":\"air\",\"minStateId\":0,\"maxStateId\":0,\"boundingBox\":\"empty\",\"hardness\":0}," +
        "{\"id\":1,\"name\":\"stone\",\"minStateId\":1,\"maxStateId\":1,\"boundingBox\":\"block\",\"hardness\":1.5}," +
        "{\"id\":2,\"name\":\"dirt\",\"minStateId\":2,\"maxStateId\":2,\"boundingBox\":\"block\",\"hardness\":0.5}," +
        "{\"id\":3,\"name\":\"bedrock\",\"minStateId\":3,\"maxStateId\":3,\"boundingBox\":\"block\",\"hardness\":null}," +
        "{\"id\":6,\"name\":\"cobblestone\",\"minStateId\":5,\"maxStateId\":5,\"boundingBox\":\"block\",\"hardness\":2}," +
        "{\"id\":4,\"name\":\"water\",\"minStateId\":10,\"maxStateId\":10,\"boundingBox\":\"empty\",\"hardness\":100}," +
        "{\"id\":5,\"name\":\"lava\",\"minStateId\":11,\"maxStateId\":11,\"boundingBox\":\"empty\",\"hardness\":100}," +
        "{\"id\":7,\"name\":\"ladder\",\"minStateId\":12,\"maxStateId\":15,\"boundingBox\":\"block\",\"hardness\":0.4,\"states\":[" +
            "{\"name\":\"facing\",\"type\":\"enum\",\"num_values\":4,\"values\":[\"north\",\"south\",\"west\",\"east\"]}]}," +
        "{\"id\":8,\"name\":\"oak_door\",\"minStateId\":20,\"maxStateId\":83,\"boundingBox\":\"block\",\"hardness\":3,\"states\":[" +
            "{\"name\":\"facing\",\"type\":\"enum\",\"num_values\":4,\"values\":[\"north\",\"south\",\"west\",\"east\"]}," +
            "{\"name\":\"half\",\"type\":\"enum\",\"num_values\":2,\"values\":[\"upper\",\"lower\"]}," +
            "{\"name\":\"hinge\",\"type\":\"enum\",\"num_values\":2,\"values\":[\"left\",\"right\"]}," +
            "{\"name\":\"open\",\"type\":\"bool\",\"num_values\":2}," +
            "{\"name\":\"powered\",\"type\":\"bool\",\"num_values\":2}]}," +
        "{\"id\":9,\"name\":\"chest\",\"minStateId\":100,\"maxStateId\":100,\"boundingBox\":\"block\",\"hardness\":2.5}]";

    static final String ITEMS = "[{\"id\":1,\"name\":\"stone\"},{\"id\":2,\"name\":\"wooden_pickaxe\"},{\"id\":3,\"name\":\"cobblestone\"},{\"id\":4,\"name\":\"iron_pickaxe\"},{\"id\":5,\"name\":\"apple\"}]";

    static void unit() {
        T.suite("path finder: Baritone-style obstacles (planner)");
        Data.Blocks b = Data.Blocks.parse(BLOCKS);
        T.eq("door property decode: closed lower", b.prop(doorState(false, false), "open"), "false");
        T.eq("door property decode: open upper", b.prop(doorState(true, true), "open"), "true");
        T.eq("door property decode: half", b.prop(doorState(true, false), "half") + "/" + b.prop(doorState(false, false), "half"), "upper/lower");
        T.check("open door is passable, closed is an obstacle", b.isPassable(doorState(false, true)) && !b.isObstacle(doorState(false, true)) && b.isObstacle(doorState(false, false)));
        T.check("closed door can be opened by hand", b.isClosedDoor(doorState(false, false)) && !b.isClosedDoor(doorState(false, true)));
        T.check("ladder: passable, climbable, not an obstacle, not standable", b.isPassable(LADDER) && b.isClimbable(LADDER) && !b.isObstacle(LADDER) && !b.isStandable(LADDER));
        T.check("water is swimmable and not passable on foot", b.isWater(WATER) && !b.isPassable(WATER));
        T.check("hardness read, bedrock unbreakable", b.hardness(STONE) == 1.5 && b.hardness(BEDROCK) < 0 && !b.isBreakable(BEDROCK));
        T.check("chests are protected from digging", !b.isBreakable(CHEST) && b.isBreakable(STONE));
        T.eq("tool formula: stone with wooden pickaxe (23 ticks)", Tools.breakTicks(1.5, "stone", "wooden_pickaxe"), 23);
        T.eq("tool formula: dirt by hand (15 ticks)", Tools.breakTicks(0.5, "dirt", null), 15);
        T.eq("tool formula: stone by hand is 100/30 slower (150 ticks)", Tools.breakTicks(1.5, "stone", null), 150);
        T.eq("tool formula: instant blocks", Tools.breakTicks(0, "grass", null), 1);

        NavConfig off = new NavConfig();
        NavConfig dig = new NavConfig(); dig.allowBreak = true;

        // thick wall without a gap
        World w = UnitTests.flat(0, 0, 1, 1, 4); w.blocks = b;
        for (int x = 8; x <= 10; x++) for (int y = 5; y <= 8; y++) for (int z = 0; z < 32; z++) w.set(x, y, z, STONE);
        Pathfinder.Result r = Pathfinder.find(w, 2, 5, 5, 20, 5, 5, false, 0, off);
        T.check("closed wall, digging off: goal unreachable", !r.complete);
        r = Pathfinder.find(w, 2, 5, 5, 20, 5, 5, false, 0, dig);
        int digs = 0; for (Pathfinder.Step s : r.steps) digs += s.breaks.size();
        T.check("closed wall, digging on: reaches the goal by digging (" + digs + " blocks)", r.complete && digs >= 6 && digs <= 8);

        // detour vs dig
        World w2 = UnitTests.flat(0, 0, 3, 1, 4); w2.blocks = b;
        for (int y = 5; y <= 8; y++) for (int z = 0; z < 32; z++) if (z != 31) w2.set(8, y, z, STONE);
        r = Pathfinder.find(w2, 2, 5, 3, 20, 5, 3, false, 0, dig);
        digs = 0; for (Pathfinder.Step s : r.steps) digs += s.breaks.size();
        T.check("thin wall with a far gap: digging through (2 blocks: feet + head) beats a 56-block detour", r.complete && digs == 2);
        NavConfig stubborn = dig.copy(); stubborn.breakPenalty = 200;
        r = Pathfinder.find(w2, 2, 5, 3, 20, 5, 3, false, 0, stubborn);
        digs = 0; for (Pathfinder.Step s : r.steps) digs += s.breaks.size();
        T.check("a high break penalty makes the planner walk around instead", r.complete && digs == 0);

        // protected / unbreakable / lava
        World w3 = UnitTests.flat(0, 0, 1, 1, 4); w3.blocks = b;
        for (int y = 0; y <= 8; y++) for (int z = 0; z < 32; z++) { w3.set(8, y, z, CHEST); }
        r = Pathfinder.find(w3, 2, 5, 5, 20, 5, 5, false, 0, dig);
        T.check("a wall of chests is never dug", !r.complete);
        World w4 = UnitTests.flat(0, 0, 1, 1, 4); w4.blocks = b;
        for (int y = 0; y <= 8; y++) for (int z = 0; z < 32; z++) w4.set(8, y, z, BEDROCK);
        T.check("bedrock is never dug", !Pathfinder.find(w4, 2, 5, 5, 20, 5, 5, false, 0, dig).complete);
        World w5 = UnitTests.flat(0, 0, 1, 1, 4); w5.blocks = b;
        for (int y = 0; y <= 8; y++) for (int z = 0; z < 32; z++) w5.set(8, y, z, STONE);
        for (int y = 0; y <= 8; y++) for (int z = 0; z < 32; z++) w5.set(9, y, z, LAVA);
        T.check("stone next to lava is not dug (would flood)", !Pathfinder.find(w5, 2, 5, 5, 20, 5, 5, false, 0, dig).complete);

        // dig down
        World w6 = UnitTests.flat(0, 0, 1, 1, 4); w6.blocks = b;
        for (int y = 0; y <= 4; y++) for (int x = 0; x < 32; x++) for (int z = 0; z < 32; z++) w6.set(x, y, z, STONE);
        r = Pathfinder.find(w6, 5, 5, 5, 5, 2, 5, false, 0, dig);
        boolean downs = true; for (Pathfinder.Step s : r.steps) if (s.kind != Pathfinder.Kind.DIG_DOWN) downs = false;
        T.check("goal 3 blocks underground: three dig-down steps", r.complete && r.steps.size() == 3 && downs);
        T.check("without digging the underground goal is unreachable", !Pathfinder.find(w6, 5, 5, 5, 5, 2, 5, false, 0, off).complete);

        // swimming
        World w7 = UnitTests.flat(0, 0, 1, 1, 4); w7.blocks = b;
        for (int x = 8; x <= 14; x++) for (int z = 0; z < 32; z++) { w7.set(x, 4, z, WATER); w7.set(x, 3, z, WATER); }
        r = Pathfinder.find(w7, 2, 5, 5, 20, 5, 5, false, 0, off);
        boolean swims = false; for (Pathfinder.Step s : r.steps) if (s.kind == Pathfinder.Kind.SWIM) swims = true;
        T.check("a pond across the way: swims through it", r.complete && swims);
        NavConfig noSwim = new NavConfig(); noSwim.allowSwim = false;
        T.check("swimming disabled: cannot cross the pond", !Pathfinder.find(w7, 2, 5, 5, 20, 5, 5, false, 0, noSwim).complete);

        // ladder
        World w8 = UnitTests.flat(0, 0, 1, 1, 4); w8.blocks = b;
        for (int y = 5; y <= 9; y++) { w8.set(11, y, 5, STONE); w8.set(10, y, 5, LADDER); }
        r = Pathfinder.find(w8, 2, 5, 5, 11, 10, 5, false, 0, off);
        boolean climbs = false; for (Pathfinder.Step s : r.steps) if (s.kind == Pathfinder.Kind.CLIMB) climbs = true;
        T.check("a ladder to a high platform: climbs it", r.complete && climbs);
        NavConfig noClimb = new NavConfig(); noClimb.allowClimb = false;
        T.check("climbing disabled: platform unreachable", !Pathfinder.find(w8, 2, 5, 5, 11, 10, 5, false, 0, noClimb).complete);

        // doors
        World w9 = UnitTests.flat(0, 0, 1, 1, 4); w9.blocks = b;
        for (int y = 5; y <= 8; y++) for (int z = 0; z < 32; z++) w9.set(8, y, z, STONE);
        w9.set(8, 5, 5, doorState(false, false)); w9.set(8, 6, 5, doorState(true, false));
        r = Pathfinder.find(w9, 2, 5, 5, 20, 5, 5, false, 0, off);
        int opens = 0; for (Pathfinder.Step s : r.steps) opens += s.opens.size();
        T.check("closed door in a wall: path goes through it and opens it", r.complete && opens >= 1);
        NavConfig noDoor = new NavConfig(); noDoor.openDoors = false;
        T.check("doors disabled: wall is solid", !Pathfinder.find(w9, 2, 5, 5, 20, 5, 5, false, 0, noDoor).complete);
        w9.set(8, 5, 5, doorState(false, true)); w9.set(8, 6, 5, doorState(true, true));
        r = Pathfinder.find(w9, 2, 5, 5, 20, 5, 5, false, 0, noDoor);
        T.check("an already open door needs no hands", r.complete);

        // bridging and pillars
        World w10 = UnitTests.flat(0, 0, 1, 1, 4); w10.blocks = b;
        for (int x = 8; x <= 10; x++) for (int z = 0; z < 32; z++) for (int y = 0; y <= 4; y++) w10.set(x, y, z, AIR);
        NavConfig place = new NavConfig(); place.allowPlace = true;
        r = Pathfinder.find(w10, 2, 5, 5, 20, 5, 5, false, 0, place);
        int places = 0; for (Pathfinder.Step s : r.steps) if (s.place != null) places++;
        T.check("3-block gap: bridges it with 3 placed blocks", r.complete && places == 3);
        T.check("no placing allowed: gap too wide to cross", !Pathfinder.find(w10, 2, 5, 5, 20, 5, 5, false, 0, off).complete);
        NavConfig noBlocks = place.copy(); noBlocks.hasThrowaway = false;
        T.check("no throwaway block in the hotbar: cannot bridge", !Pathfinder.find(w10, 2, 5, 5, 20, 5, 5, false, 0, noBlocks).complete);
        World w11 = UnitTests.flat(0, 0, 1, 1, 4); w11.blocks = b;
        r = Pathfinder.find(w11, 5, 5, 5, 5, 8, 5, false, 0, place);
        int pill = 0; for (Pathfinder.Step s : r.steps) if (s.kind == Pathfinder.Kind.PILLAR) pill++;
        T.check("goal 3 blocks up in the open: pillars up three times", r.complete && pill == 3);
        T.check("without placing the same goal is unreachable", !Pathfinder.find(w11, 5, 5, 5, 5, 8, 5, false, 0, off).complete);
        // old behaviour untouched when everything is off
        World w12 = UnitTests.flat(0, 0, 1, 1, 4); w12.blocks = b;
        r = Pathfinder.find(w12, 2, 5, 2, 20, 5, 9, false, 0, off);
        boolean plain = true; for (Pathfinder.Step s : r.steps) if (s.needsWork()) plain = false;
        T.check("plain walking on open ground needs no work", r.complete && plain);
    }

    // ======================================================================================= server-simulated runs

    interface Base { int at(int x, int y, int z); }

    static final class SimWorld {
        final Map<Long, Integer> over = new HashMap<>();
        final Base base;
        SimWorld(Base b) { base = b; }
        static long k(int x, int y, int z) { return (((long) x & 0x3FFFFFF) << 38) | (((long) z & 0x3FFFFFF) << 12) | ((y + 2048) & 0xFFF); }
        synchronized int get(int x, int y, int z) { Integer v = over.get(k(x, y, z)); return v != null ? v : base.at(x, y, z); }
        synchronized void set(int x, int y, int z, int s) { over.put(k(x, y, z), s); }
        boolean solid(int x, int y, int z) { return solidState(get(x, y, z)); }
    }

    static boolean solidState(int s) {
        return s == STONE || s == DIRT || s == BEDROCK || s == COBBLE || s == CHEST || (s >= 20 && s <= 83 && !doorOpen(s));
    }
    static boolean doorOpen(int s) { return (((s - 20) >> 1) & 1) == 0; }
    static final String[] ITEM_NAME = {null, "stone", "wooden_pickaxe", "cobblestone", "iron_pickaxe", "apple"};

    /** Independent re-implementation of the server's dig-progress rule for the test blocks. */
    static double damage(String block, double hardness, String item) {
        boolean needsPick = block.equals("stone") || block.equals("cobblestone");
        boolean correct = needsPick && item != null && item.endsWith("_pickaxe");
        double speed = correct ? (item.startsWith("wooden") ? 2 : item.startsWith("iron") ? 6 : 1) : 1;
        return speed / hardness / ((!needsPick || correct) ? 30.0 : 100.0);
    }
    static String blockName(int s) { return s == STONE ? "stone" : s == DIRT ? "dirt" : s == COBBLE ? "cobblestone" : s == CHEST ? "chest" : "other"; }
    static double hardnessOf(int s) { return s == STONE ? 1.5 : s == DIRT ? 0.5 : s == COBBLE ? 2 : s == CHEST ? 2.5 : -1; }

    static final class Stats {
        final List<String> digs = Collections.synchronizedList(new ArrayList<String>());
        final List<Integer> digTicks = Collections.synchronizedList(new ArrayList<Integer>());
        final List<String> places = Collections.synchronizedList(new ArrayList<String>());
        final List<String> violations = Collections.synchronizedList(new ArrayList<String>());
        final List<Integer> held = Collections.synchronizedList(new ArrayList<Integer>());
        volatile int early, rejectedPlaces, doorUses, packets, chestUses;
        volatile MockServer.Client client;
        volatile MockServer.Tracker tracker;
        final List<int[]> commands = Collections.synchronizedList(new ArrayList<int[]>()); // Player Command {action}
        final List<Integer> abilityFlags = Collections.synchronizedList(new ArrayList<Integer>());
        final List<Integer> useItems = Collections.synchronizedList(new ArrayList<Integer>());
        volatile double x, y, z, minY = 1e9, maxStep;
        volatile int curHeld = 0;
    }

    static void simulate(MockServer.Client c, SimWorld sw, int[] hotbar, Stats st, double sx, double sy, double sz) throws Exception {
        Flow.joinAs(c, 256);
        Buf.Writer w = new Buf.Writer().b(0).varInt(1).varInt(46);
        for (int i = 0; i < 46; i++) { int item = (i >= 36 && i < 45) ? hotbar[i - 36] : 0; IntegrationTests.writeSlot(w, item > 0 ? item : -1, 1, null); }
        IntegrationTests.writeSlot(w, -1, 0, null);
        c.send(0x13, w);
        for (int cx = -2; cx <= 2; cx++) for (int cz = -2; cz <= 2; cz++) {
            final int fcx = cx, fcz = cz;
            int[][] secs = new int[Flow.WORLD_H / 16][];
            for (int i = 0; i < secs.length; i++) {
                int[] a = new int[4096]; boolean any = false;
                for (int y = 0; y < 16; y++) for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++) {
                    int v = sw.get(fcx * 16 + x, i * 16 + y, fcz * 16 + z);
                    if (v != 0) { a[(y << 8) | (z << 4) | x] = v; any = true; }
                }
                secs[i] = any ? a : null;
            }
            Flow.chunk(c, cx, cz, secs);
        }
        Flow.syncPosition(c, sx, sy, sz, 1);
        c.ignorable.clear();
        MockServer.Tracker tr = new MockServer.Tracker();
        st.client = c; st.tracker = tr;
        double lx = Double.NaN, ly = 0, lz = 0;
        int[] digCell = null; long digStart = 0;
        while (!c.eof) {
            MockServer.Pkt p;
            try { p = c.next(300); } catch (TimeoutException e) { continue; } catch (java.io.EOFException e) { return; }
            if (tr.apply(p)) {
                if (tr.moved) {
                double x = tr.x, y = tr.y, z = tr.z;
                if (!Double.isNaN(lx)) {
                    double step = Math.hypot(x - lx, z - lz);
                    st.maxStep = Math.max(st.maxStep, step);
                    if (step > 0.36) st.violations.add("horizontal step " + step);
                    if (Math.abs(y - ly) > 1.3) st.violations.add("vertical step " + (y - ly));
                }
                lx = x; ly = y; lz = z;
                int x0 = (int) Math.floor(x - 0.3 + 1e-7), x1 = (int) Math.floor(x + 0.3 - 1e-7), z0 = (int) Math.floor(z - 0.3 + 1e-7), z1 = (int) Math.floor(z + 0.3 - 1e-7);
                int y0 = (int) Math.floor(y + 1e-7), y1 = (int) Math.floor(y + 1.8 - 1e-7);
                for (int bx = x0; bx <= x1; bx++) for (int bz = z0; bz <= z1; bz++) for (int by = y0; by <= y1; by++)
                    if (sw.solid(bx, by, bz)) st.violations.add("inside block (" + bx + "," + by + "," + bz + ") at (" + x + "," + y + "," + z + ")");
                st.x = x; st.y = y; st.z = z; st.minY = Math.min(st.minY, y); st.packets++;
                }
            } else if (p.id == 0x22) {
                p.r.varInt();
                st.commands.add(new int[]{p.r.varInt()});
            } else if (p.id == 0x20) {
                st.abilityFlags.add(p.r.u8());
            } else if (p.id == 0x36) {
                st.useItems.add(st.curHeld);
            } else if (p.id == 0x2C) {
                int slot = p.r.s16();
                st.curHeld = slot;
                st.held.add(slot);
            } else if (p.id == 0x21) {
                int status = p.r.varInt();
                long pos = p.r.i64();
                int face = p.r.i8();
                int seq = p.r.varInt();
                int x = World.posX(pos), y = World.posY(pos), z = World.posZ(pos);
                if (status == 0) {
                    int bs = sw.get(x, y, z);
                    if (hardnessOf(bs) < 0) { c.send(0x09, new Buf.Writer().i64(pos).varInt(bs)); continue; }
                    digCell = new int[]{x, y, z};
                    digStart = System.nanoTime();
                } else if (status == 2 && digCell != null && digCell[0] == x && digCell[1] == y && digCell[2] == z) {
                    int bs = sw.get(x, y, z);
                    int ticks = (int) ((System.nanoTime() - digStart) / 50_000_000L);
                    String item = ITEM_NAME[hotbar[st.curHeld] < ITEM_NAME.length ? hotbar[st.curHeld] : 0];
                    double dmg = damage(blockName(bs), hardnessOf(bs), item);
                    if (dmg * (ticks + 1) >= 0.7) {
                        sw.set(x, y, z, 0);
                        st.digs.add(x + "," + y + "," + z);
                        st.digTicks.add(ticks);
                        c.send(0x09, new Buf.Writer().i64(pos).varInt(0));
                        c.send(0x05, new Buf.Writer().varInt(seq));
                    } else {
                        st.early++;
                        c.send(0x09, new Buf.Writer().i64(pos).varInt(bs));
                    }
                    digCell = null;
                }
            } else if (p.id == 0x35) {
                p.r.varInt();
                long pos = p.r.i64();
                int face = p.r.varInt();
                p.r.f32(); p.r.f32(); p.r.f32(); p.r.bool();
                int seq = p.r.varInt();
                int x = World.posX(pos), y = World.posY(pos), z = World.posZ(pos);
                int bs = sw.get(x, y, z);
                if (bs == CHEST) {
                    st.chestUses++;
                    c.send(0x31, new Buf.Writer().varInt(7).varInt(2).nbt(Flow.comp("Chest", "white")));
                    Buf.Writer cw = new Buf.Writer().b(7).varInt(1).varInt(63);
                    for (int i = 0; i < 63; i++) IntegrationTests.writeSlot(cw, -1, 0, null);
                    IntegrationTests.writeSlot(cw, -1, 0, null);
                    c.send(0x13, cw);
                    continue;
                }
                if (bs >= 20 && bs <= 83) {
                    st.doorUses++;
                    for (int dy = -1; dy <= 1; dy++) {
                        int s2 = sw.get(x, y + dy, z);
                        if (s2 >= 20 && s2 <= 83) {
                            int flipped = 20 + ((s2 - 20) ^ 2);
                            sw.set(x, y + dy, z, flipped);
                            c.send(0x09, new Buf.Writer().i64(World.posX(0) == 0 ? ObstacleTests.pack(x, y + dy, z) : 0L).varInt(flipped));
                        }
                    }
                    continue;
                }
                int[] d = face == 0 ? new int[]{0, -1, 0} : face == 1 ? new int[]{0, 1, 0} : face == 2 ? new int[]{0, 0, -1} : face == 3 ? new int[]{0, 0, 1} : face == 4 ? new int[]{-1, 0, 0} : new int[]{1, 0, 0};
                int tx = x + d[0], ty = y + d[1], tz = z + d[2];
                boolean holdingBlock = hotbar[st.curHeld] == 3;
                boolean emptyTarget = sw.get(tx, ty, tz) == 0;
                boolean supportOk = sw.solid(x, y, z);
                boolean overlaps = st.x + 0.3 > tx && st.x - 0.3 < tx + 1 && st.z + 0.3 > tz && st.z - 0.3 < tz + 1 && st.y + 1.8 > ty && st.y < ty + 1;
                double reach = Math.sqrt(Math.pow(tx + 0.5 - st.x, 2) + Math.pow(ty + 0.5 - (st.y + 1.62), 2) + Math.pow(tz + 0.5 - st.z, 2));
                if (holdingBlock && emptyTarget && supportOk && !overlaps && reach <= 6.0) {
                    sw.set(tx, ty, tz, COBBLE);
                    st.places.add(tx + "," + ty + "," + tz + "@" + face);
                    c.send(0x09, new Buf.Writer().i64(ObstacleTests.pack(tx, ty, tz)).varInt(COBBLE));
                    c.send(0x05, new Buf.Writer().varInt(seq));
                } else {
                    st.rejectedPlaces++;
                    c.send(0x09, new Buf.Writer().i64(ObstacleTests.pack(tx, ty, tz)).varInt(sw.get(tx, ty, tz)));
                }
            }
        }
    }

    static long pack(int x, int y, int z) { return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (y & 0xFFF); }

    static ClientSession session(Rec rec, MockServer ms, String name, java.util.function.Consumer<NavConfig> nav) {
        ClientSession cs = IntegrationTests.newSession(rec);
        cs.world.blocks = Data.Blocks.parse(BLOCKS);
        cs.inventory.items = Data.Items.parse(ITEMS);
        nav.accept(cs.nav());
        cs.connect(IntegrationTests.profile(ms, name));
        return cs;
    }

    static boolean arrived(Rec rec) { return rec.actionStatus.contains("رسیدید"); }

    static void integration() throws Exception {
        digThroughStone(); digDirtByHand(); digDisabledAndProtected(); bridgeGap(); pillarUp(); swimPond(); climbLadder(); openDoor();
    }

    static void digThroughStone() throws Exception {
        T.suite("sim: dig through a stone wall with the right tool");
        SimWorld sw = new SimWorld((x, y, z) -> y <= 4 ? STONE : (x >= 3 && x <= 4 && y <= 8) ? STONE : 0);
        Stats st = new Stats();
        int[] hotbar = {0, 0, 2, 3, 0, 0, 0, 0, 0};
        try (MockServer ms = new MockServer(c -> simulate(c, sw, hotbar, st, 0.5, 5, 0.5))) {
            Rec rec = new Rec();
            ClientSession cs = session(rec, ms, "Digger", n -> n.allowBreak = true);
            T.check("world + position ready", Rec.waitFor(() -> cs.world.chunkCount() == 25 && cs.hasPosition() && cs.inventory.player().slots[38] != null, 8000));
            cs.startAction(new Actions.GoTo(7, 5, 0, false));
            T.check("goto through a 2-thick wall: arrives", Rec.waitFor(() -> arrived(rec), 40000));
            T.eq("exactly 4 blocks dug (2 high x 2 deep): " + st.digs, st.digs.size(), 4);
            boolean cells = true;
            for (String d : st.digs) { String[] a = d.split(","); int x = Integer.parseInt(a[0]), y = Integer.parseInt(a[1]); if (x < 3 || x > 4 || y < 5 || y > 6) cells = false; }
            T.check("only wall blocks at feet/head height were dug", cells);
            T.eq("never finished early (the server's 70% rule was satisfied each time)", st.early, 0);
            boolean timing = true;
            for (int t : st.digTicks) if (t < 16 || t > 30) timing = false;
            T.check("each block took 16-30 ticks (vanilla needs 23 with a wooden pickaxe): " + st.digTicks, timing);
            T.check("the pickaxe (hotbar slot 2) was equipped before digging: " + st.held, !st.held.isEmpty() && st.held.get(0) == 2);
            T.check("no collisions / speeding seen by the server: " + st.violations, st.violations.isEmpty());
            T.check("player ended beyond the wall (x=" + st.x + ")", st.x > 5.0);
            cs.disconnect();
        }
    }

    static void digDirtByHand() throws Exception {
        T.suite("sim: bare-hand digging of dirt, wrong tool timing");
        SimWorld sw = new SimWorld((x, y, z) -> y <= 4 ? STONE : (x == 3 && y <= 8) ? DIRT : 0);
        Stats st = new Stats();
        int[] hotbar = {0, 0, 0, 3, 0, 0, 0, 0, 0};
        try (MockServer ms = new MockServer(c -> simulate(c, sw, hotbar, st, 0.5, 5, 0.5))) {
            Rec rec = new Rec();
            ClientSession cs = session(rec, ms, "Hand", n -> n.allowBreak = true);
            T.check("ready", Rec.waitFor(() -> cs.world.chunkCount() == 25 && cs.hasPosition(), 8000));
            cs.startAction(new Actions.GoTo(6, 5, 0, false));
            T.check("goto through a dirt wall: arrives", Rec.waitFor(() -> arrived(rec), 40000));
            T.eq("2 dirt blocks dug", st.digs.size(), 2);
            T.eq("no early finishes", st.early, 0);
            boolean timing = true;
            for (int t : st.digTicks) if (t < 11 || t > 22) timing = false;
            T.check("bare-hand dirt takes ~15 ticks per block: " + st.digTicks, timing);
            T.check("no violations: " + st.violations, st.violations.isEmpty());
            cs.disconnect();
        }
    }

    static void digDisabledAndProtected() throws Exception {
        T.suite("sim: digging off, and protected blocks");
        SimWorld sw = new SimWorld((x, y, z) -> y <= 4 ? STONE : (x == 3 && y <= 8) ? STONE : 0);
        Stats st = new Stats();
        try (MockServer ms = new MockServer(c -> simulate(c, sw, new int[9], st, 0.5, 5, 0.5))) {
            Rec rec = new Rec();
            ClientSession cs = session(rec, ms, "NoDig", n -> n.allowBreak = false);
            T.check("ready", Rec.waitFor(() -> cs.world.chunkCount() == 25 && cs.hasPosition(), 8000));
            cs.startAction(new Actions.GoTo(7, 5, 0, false));
            T.check("digging off: the action stops without arriving", Rec.waitFor(() -> !rec.actionRunning && !rec.actionStatus.isEmpty(), 20000) && !arrived(rec));
            T.eq("digging off: no block was touched", st.digs.size(), 0);
            T.check("digging off: still no violations", st.violations.isEmpty());
            cs.disconnect();
        }
        SimWorld chests = new SimWorld((x, y, z) -> y <= 4 ? STONE : (x == 3 && y <= 8) ? CHEST : 0);
        for (int y = 0; y <= 4; y++) for (int z = -40; z < 48; z++) chests.set(3, y, z, CHEST);
        Stats st2 = new Stats();
        try (MockServer ms = new MockServer(c -> simulate(c, chests, new int[9], st2, 0.5, 5, 0.5))) {
            Rec rec = new Rec();
            ClientSession cs = session(rec, ms, "Chests", n -> n.allowBreak = true);
            T.check("ready", Rec.waitFor(() -> cs.world.chunkCount() == 25 && cs.hasPosition(), 8000));
            cs.startAction(new Actions.GoTo(7, 5, 0, false));
            T.check("a wall of chests is never broken", Rec.waitFor(() -> !rec.actionRunning && !rec.actionStatus.isEmpty(), 20000) && st2.digs.isEmpty() && !arrived(rec));
            cs.disconnect();
        }
    }

    static void bridgeGap() throws Exception {
        T.suite("sim: bridge a gap with placed blocks");
        SimWorld sw = new SimWorld((x, y, z) -> (y <= 4 && !(x >= 3 && x <= 5)) ? STONE : 0);
        Stats st = new Stats();
        int[] hotbar = {5, 0, 0, 3, 0, 0, 0, 0, 0};
        try (MockServer ms = new MockServer(c -> simulate(c, sw, hotbar, st, 0.5, 5, 0.5))) {
            Rec rec = new Rec();
            ClientSession cs = session(rec, ms, "Bridger", n -> n.allowPlace = true);
            T.check("ready", Rec.waitFor(() -> cs.world.chunkCount() == 25 && cs.hasPosition() && cs.inventory.player().slots[39] != null, 8000));
            cs.startAction(new Actions.GoTo(9, 5, 0, false));
            T.check("goto across a 3-wide void: arrives", Rec.waitFor(() -> arrived(rec), 40000));
            T.eq("three blocks placed: " + st.places, st.places.size(), 3);
            T.eq("no placement was rejected by the server", st.rejectedPlaces, 0);
            boolean line = true;
            for (int i = 0; i < st.places.size(); i++) if (!st.places.get(i).startsWith((3 + i) + ",4,")) line = false;
            T.check("blocks placed in order at x=3,4,5, floor level: " + st.places, line);
            T.check("the cobblestone slot was selected: " + st.held, st.held.contains(3));
            T.check("the player never fell (min y " + st.minY + ")", st.minY >= 4.99);
            T.check("no violations: " + st.violations, st.violations.isEmpty());
            cs.disconnect();
        }
        // without blocks in the hotbar the same trip is impossible
        SimWorld sw2 = new SimWorld((x, y, z) -> (y <= 4 && !(x >= 3 && x <= 5)) ? STONE : 0);
        Stats st2 = new Stats();
        try (MockServer ms = new MockServer(c -> simulate(c, sw2, new int[]{5, 0, 0, 0, 0, 0, 0, 0, 0}, st2, 0.5, 5, 0.5))) {
            Rec rec = new Rec();
            ClientSession cs = session(rec, ms, "NoBlocks", n -> n.allowPlace = true);
            T.check("ready", Rec.waitFor(() -> cs.world.chunkCount() == 25 && cs.hasPosition(), 8000));
            cs.startAction(new Actions.GoTo(9, 5, 0, false));
            T.check("no throwaway block in the hotbar: nothing is placed, no falling", Rec.waitFor(() -> !rec.actionRunning && !rec.actionStatus.isEmpty(), 20000) && st2.places.isEmpty() && st2.minY >= 4.99);
            cs.disconnect();
        }
    }

    static void pillarUp() throws Exception {
        T.suite("sim: pillar up by jumping and placing underneath");
        SimWorld sw = new SimWorld((x, y, z) -> y <= 4 ? STONE : 0);
        Stats st = new Stats();
        int[] hotbar = {0, 0, 0, 0, 3, 0, 0, 0, 0};
        try (MockServer ms = new MockServer(c -> simulate(c, sw, hotbar, st, 0.5, 5, 0.5))) {
            Rec rec = new Rec();
            ClientSession cs = session(rec, ms, "Pillar", n -> { n.allowPlace = true; n.arriveDistance = 0.5; });
            T.check("ready", Rec.waitFor(() -> cs.world.chunkCount() == 25 && cs.hasPosition() && cs.inventory.player().slots[40] != null, 8000));
            cs.startAction(new Actions.GoTo(0, 8, 0, false));
            T.check("goto 3 blocks up in the open: arrives", Rec.waitFor(() -> arrived(rec), 40000));
            T.eq("3 pillar blocks: " + st.places, st.places.size(), 3);
            T.eq("none rejected", st.rejectedPlaces, 0);
            T.check("placed one above the other, top faces", st.places.get(0).startsWith("0,5,0@1") && st.places.get(1).startsWith("0,6,0@1") && st.places.get(2).startsWith("0,7,0@1"));
            T.check("standing on top (y=" + st.y + ")", Math.abs(st.y - 8.0) < 0.06);
            T.check("no violations (never placed into the player): " + st.violations, st.violations.isEmpty());
            cs.disconnect();
        }
    }

    static void swimPond() throws Exception {
        T.suite("sim: swim across a pond");
        SimWorld sw = new SimWorld((x, y, z) -> y <= 2 ? STONE : (y <= 4 ? ((x >= 5 && x <= 12) ? WATER : STONE) : 0));
        Stats st = new Stats();
        try (MockServer ms = new MockServer(c -> simulate(c, sw, new int[9], st, 0.5, 5, 0.5))) {
            Rec rec = new Rec();
            ClientSession cs = session(rec, ms, "Swimmer", n -> { });
            T.check("ready", Rec.waitFor(() -> cs.world.chunkCount() == 25 && cs.hasPosition(), 8000));
            cs.startAction(new Actions.GoTo(16, 5, 0, false));
            T.check("goto across an 8-wide pond: arrives", Rec.waitFor(() -> arrived(rec), 40000));
            T.check("ended on the far bank (x=" + st.x + ", y=" + st.y + ")", st.x > 14 && Math.abs(st.y - 5.0) < 0.06);
            T.check("stayed afloat, never sank to the bottom (min y " + st.minY + ")", st.minY >= 3.7);
            T.check("no violations: " + st.violations, st.violations.isEmpty());
            T.check("swimming is slower than walking (max step " + String.format("%.3f", st.maxStep) + ")", st.maxStep <= 0.2300);
            cs.disconnect();
        }
        Stats st2 = new Stats();
        try (MockServer ms = new MockServer(c -> simulate(c, sw, new int[9], st2, 0.5, 5, 0.5))) {
            Rec rec = new Rec();
            ClientSession cs = session(rec, ms, "NoSwim", n -> n.allowSwim = false);
            T.check("ready", Rec.waitFor(() -> cs.world.chunkCount() == 25 && cs.hasPosition(), 8000));
            cs.startAction(new Actions.GoTo(16, 5, 0, false));
            T.check("swimming off: stops at the shore, stays dry", Rec.waitFor(() -> !rec.actionRunning && !rec.actionStatus.isEmpty(), 20000) && st2.x < 5 && !arrived(rec));
            cs.disconnect();
        }
    }

    static void climbLadder() throws Exception {
        T.suite("sim: climb a ladder");
        SimWorld sw = new SimWorld((x, y, z) -> {
            if (y <= 4) return STONE;
            if (x == 5 && z == 0 && y <= 9) return STONE;
            if (x == 4 && z == 0 && y <= 9) return LADDER;
            return 0;
        });
        Stats st = new Stats();
        try (MockServer ms = new MockServer(c -> simulate(c, sw, new int[9], st, 0.5, 5, 0.5))) {
            Rec rec = new Rec();
            ClientSession cs = session(rec, ms, "Climber", n -> n.arriveDistance = 0.5);
            T.check("ready", Rec.waitFor(() -> cs.world.chunkCount() == 25 && cs.hasPosition(), 8000));
            cs.startAction(new Actions.GoTo(5, 10, 0, false));
            T.check("goto the top of a 5-high tower with a ladder: arrives", Rec.waitFor(() -> arrived(rec), 40000));
            T.check("standing on the tower top (y=" + st.y + ")", Math.abs(st.y - 10.0) < 0.06 && Math.abs(st.x - 5.5) < 1.0);
            T.check("no violations (ladder does not block, tower does): " + st.violations, st.violations.isEmpty());
            cs.disconnect();
        }
    }

    static void openDoor() throws Exception {
        T.suite("sim: open a door in a wall");
        SimWorld sw = new SimWorld((x, y, z) -> {
            if (y <= 4) return STONE;
            if (x == 3 && y <= 8) {
                if (z == 0 && y == 5) return doorState(false, false);
                if (z == 0 && y == 6) return doorState(true, false);
                return STONE;
            }
            return 0;
        });
        Stats st = new Stats();
        try (MockServer ms = new MockServer(c -> simulate(c, sw, new int[9], st, 0.5, 5, 0.5))) {
            Rec rec = new Rec();
            ClientSession cs = session(rec, ms, "Doorman", n -> n.arriveDistance = 0.5);
            T.check("ready", Rec.waitFor(() -> cs.world.chunkCount() == 25 && cs.hasPosition(), 8000));
            cs.startAction(new Actions.GoTo(6, 5, 0, false));
            T.check("goto through a closed door: arrives", Rec.waitFor(() -> arrived(rec), 30000));
            T.eq("the door was opened exactly once", st.doorUses, 1);
            T.check("the player is on the other side (x=" + st.x + ")", st.x > 5.0);
            T.check("never walked through the closed door: " + st.violations, st.violations.isEmpty());
            cs.disconnect();
        }
    }
}
