import com.mcclient.core.Buf;
import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.zip.*;

/**
 * A from-scratch Minecraft 1.20.4 server stub used by the integration tests.
 * Framing/compression is implemented here independently of the client's Framing class.
 */
final class MockServer implements AutoCloseable {
    interface Scenario { void run(Client c) throws Exception; }

    static final class Pkt {
        final int id; final Buf.Reader r;
        Pkt(int id, byte[] body) { this.id = id; this.r = new Buf.Reader(body); }
    }

    final ServerSocket ss;
    final AtomicInteger connections = new AtomicInteger();
    final List<Client> clients = Collections.synchronizedList(new ArrayList<Client>());
    volatile Scenario scenario;
    volatile boolean closed;

    MockServer(Scenario sc) throws IOException {
        scenario = sc;
        ss = new ServerSocket(0, 10, InetAddress.getLoopbackAddress());
        Thread t = new Thread(() -> {
            while (!closed) {
                try {
                    Socket s = ss.accept();
                    final int n = connections.incrementAndGet();
                    final Client c = new Client(s, n);
                    clients.add(c);
                    Thread h = new Thread(() -> {
                        try { scenario.run(c); } catch (Throwable e) { c.failure = e; if (!closed && !(e instanceof EOFException) && !(e instanceof TimeoutException && c.eof)) { System.out.println("  [scenario conn " + n + " threw] " + e); StackTraceElement[] st = e.getStackTrace(); for (int i = 0; i < Math.min(4, st.length); i++) System.out.println("       at " + st[i]); } } finally { c.finished.countDown(); }
                    }, "mock-conn-" + n);
                    h.setDaemon(true);
                    h.start();
                } catch (IOException e) { return; }
            }
        }, "mock-accept");
        t.setDaemon(true);
        t.start();
    }

    int port() { return ss.getLocalPort(); }
    String address() { return "127.0.0.1:" + port(); }

    @Override public void close() {
        closed = true;
        try { ss.close(); } catch (IOException e) { /* ignore */ }
        synchronized (clients) { for (Client c : clients) c.close(); }
    }

    /** Follows the player's state from the serverbound movement packets (independent of the client's own bookkeeping). */
    static final class Tracker {
        double x = Double.NaN, y = Double.NaN, z = Double.NaN;
        float yaw, pitch;
        boolean ground, moved;
        int posPackets, rotPackets, groundPackets, posRotPackets;
        /** @return true when {@code p} was a movement packet; {@link #moved} tells whether it carried a position. */
        boolean apply(Pkt p) {
            switch (p.id) {
                case 0x17: x = p.r.f64(); y = p.r.f64(); z = p.r.f64(); ground = p.r.bool(); moved = true; posPackets++; return true;
                case 0x18: x = p.r.f64(); y = p.r.f64(); z = p.r.f64(); yaw = p.r.f32(); pitch = p.r.f32(); ground = p.r.bool(); moved = true; posRotPackets++; return true;
                case 0x19: yaw = p.r.f32(); pitch = p.r.f32(); ground = p.r.bool(); moved = false; rotPackets++; return true;
                case 0x1A: ground = p.r.bool(); moved = false; groundPackets++; return true;
                default: return false;
            }
        }
    }

    static final class Client {
        final Socket s;
        final int number;
        final InputStream in;
        final OutputStream out;
        volatile int threshold = -1;
        final BlockingQueue<Pkt> queue = new LinkedBlockingQueue<>();
        final CountDownLatch finished = new CountDownLatch(1);
        final long born = System.nanoTime();
        volatile Throwable failure;
        volatile boolean eof;
        /** Movement packets (Pos 0x17, PosRot 0x18, Rot 0x19, OnGround 0x1A) and Player Command 0x22 are noise for most tests. */
        final Set<Integer> ignorable = new HashSet<>(Arrays.asList(0x17, 0x18, 0x19, 0x1A, 0x22));

        Client(Socket s, int number) throws IOException {
            this.s = s; this.number = number;
            in = new BufferedInputStream(s.getInputStream());
            out = s.getOutputStream();
            Thread t = new Thread(this::pump, "mock-pump-" + number);
            t.setDaemon(true);
            t.start();
        }

        long ms() { return (System.nanoTime() - born) / 1_000_000; }

        void close() { try { s.close(); } catch (IOException e) { /* ignore */ } }

        // ---- independent framing
        private static int readVarInt(InputStream in) throws IOException {
            int v = 0, shift = 0;
            while (true) {
                int b = in.read();
                if (b < 0) throw new EOFException();
                v |= (b & 0x7F) << shift;
                if ((b & 0x80) == 0) return v;
                shift += 7;
            }
        }

        private void pump() {
            try {
                while (true) {
                    int len = readVarInt(in);
                    byte[] data = new byte[len];
                    int off = 0;
                    while (off < len) { int k = in.read(data, off, len - off); if (k < 0) throw new EOFException(); off += k; }
                    byte[] payload = data;
                    if (threshold >= 0) {
                        ByteArrayInputStream bi = new ByteArrayInputStream(data);
                        int dl = readVarInt(bi);
                        byte[] rest = new byte[bi.available()];
                        bi.read(rest);
                        if (dl == 0) payload = rest;
                        else {
                            Inflater inf = new Inflater();
                            inf.setInput(rest);
                            payload = new byte[dl];
                            int n = 0;
                            while (n < dl) { int k = inf.inflate(payload, n, dl - n); if (k == 0) break; n += k; }
                        }
                    }
                    ByteArrayInputStream pi = new ByteArrayInputStream(payload);
                    int id = readVarInt(pi);
                    byte[] body = new byte[pi.available()];
                    pi.read(body);
                    queue.add(new Pkt(id, body));
                }
            } catch (Exception e) { eof = true; }
        }

        synchronized void send(int id, byte[] body) throws IOException {
            ByteArrayOutputStream p = new ByteArrayOutputStream();
            writeVarInt(p, id);
            p.write(body);
            byte[] payload = p.toByteArray();
            ByteArrayOutputStream f = new ByteArrayOutputStream();
            if (threshold < 0) { writeVarInt(f, payload.length); f.write(payload); }
            else if (payload.length >= threshold) {
                Deflater d = new Deflater();
                d.setInput(payload); d.finish();
                ByteArrayOutputStream comp = new ByteArrayOutputStream();
                byte[] buf = new byte[1024];
                while (!d.finished()) { int k = d.deflate(buf); comp.write(buf, 0, k); }
                ByteArrayOutputStream dl = new ByteArrayOutputStream();
                writeVarInt(dl, payload.length);
                writeVarInt(f, dl.size() + comp.size());
                f.write(dl.toByteArray()); f.write(comp.toByteArray());
            } else { writeVarInt(f, payload.length + 1); f.write(0); f.write(payload); }
            out.write(f.toByteArray());
            out.flush();
        }

        void send(int id, Buf.Writer w) throws IOException { send(id, w.toBytes()); }
        void send(int id) throws IOException { send(id, new byte[0]); }

        static void writeVarInt(OutputStream o, int v) throws IOException {
            while (true) {
                if ((v & ~0x7F) == 0) { o.write(v); return; }
                o.write((v & 0x7F) | 0x80);
                v >>>= 7;
            }
        }

        /** Next packet, skipping ignorable ones (position reminders). Fails the test on timeout. */
        Pkt next(int timeoutMs) throws Exception {
            long end = System.currentTimeMillis() + timeoutMs;
            while (true) {
                long left = end - System.currentTimeMillis();
                if (left <= 0) throw new TimeoutException("no packet within " + timeoutMs + " ms");
                Pkt p = queue.poll(left, TimeUnit.MILLISECONDS);
                if (p == null) { if (eof) throw new EOFException("client closed the connection"); continue; }
                if (!ignorable.contains(p.id)) return p;
            }
        }

        Pkt expect(int id, int timeoutMs) throws Exception {
            Pkt p = next(timeoutMs);
            if (p.id != id) throw new AssertionError("expected packet 0x" + Integer.toHexString(id) + " but got 0x" + Integer.toHexString(p.id));
            return p;
        }

        /** Waits for a packet with this id, discarding anything else. */
        Pkt await(int id, int timeoutMs) throws Exception {
            long end = System.currentTimeMillis() + timeoutMs;
            while (true) {
                long left = end - System.currentTimeMillis();
                if (left <= 0) throw new TimeoutException("packet 0x" + Integer.toHexString(id) + " not received within " + timeoutMs + " ms");
                Pkt p = queue.poll(left, TimeUnit.MILLISECONDS);
                if (p == null) { if (eof) throw new EOFException("client closed the connection"); continue; }
                if (p.id == id) return p;
            }
        }
    }

    // ------------------------------------------------------------------ offline UUID, independently computed

    static UUID offlineUuid(String name) throws Exception {
        byte[] h = MessageDigest.getInstance("MD5").digest(("OfflinePlayer:" + name).getBytes("UTF-8"));
        h[6] = (byte) ((h[6] & 0x0f) | 0x30);
        h[8] = (byte) ((h[8] & 0x3f) | 0x80);
        long msb = 0, lsb = 0;
        for (int i = 0; i < 8; i++) msb = (msb << 8) | (h[i] & 0xff);
        for (int i = 8; i < 16; i++) lsb = (lsb << 8) | (h[i] & 0xff);
        return new UUID(msb, lsb);
    }
}
