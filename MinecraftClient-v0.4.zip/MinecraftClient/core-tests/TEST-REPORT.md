# گزارش تست — نسخهٔ ۰٫۴

دستور: `sh core-tests/run.sh all` (فقط JDK؛ کامپایل هسته با `-Xlint:all` و اجرای همهٔ تست‌ها)

**نتیجه: 1109 بررسی پاس، 0 شکست.** (نسخهٔ ۰٫۳: ۷۰۵ پاس.)

## آنچه این تست‌ها نشان می‌دهند و نشان نمی‌دهند
- هستهٔ Java (پروتکل، فیزیک، مسیریابی، اکشن‌ها، اینونتوری) با یک **سرور شبیه‌ساز** مستقل تست شده است: سروری که فقط همان چیزی را که ما در تست می‌گذاریم مدل می‌کند. این معادل اجرا روی سرور واقعی ماینکرافت نیست.
- **لایهٔ Kotlin/Compose کامپایل و اجرا نشده** (کامپایلر Kotlin روی این ماشین نبود). فقط بررسی ایستا انجام شد: تعادل آکولاد/پرانتز و تطبیق ارجاع‌های `session.*` / `session.core.*` / `prefs.*` با اعضای واقعی (صفر ارجاع ناشناخته).
- هیچ کدام از تست‌ها APK را نساخته یا روی دستگاه اجرا نکرده‌اند.

## مقادیر مرجع فیزیک (از پرامپت) و نتیجهٔ اندازه‌گیری
| کمیت | مرجع | اندازه‌گیری |
|---|---|---|
| سرعت راه رفتن | 0٫2158/تیک | 0٫21586 |
| سرعت دویدن | 0٫2806/تیک | 0٫28062 |
| قلهٔ پرش | 1٫2522 | 1٫25220 |
| مدت پرش | ۱۲ تیک | ۱۲ تیک |
| سقوط ۷ بلوک از حالت سکون | ۱۵ تیک | ۱۵ تیک |
| سرعت حد سقوط | −3٫92 | −3٫92 |
| پرواز کریتیو | (۱۰٫۹ بلوک/ث) | 0٫5425/تیک |
| ‎Levitation I | ‎0٫9 بلوک/ث | 0٫0454/تیک |

## تست‌ها به تفکیک
| مجموعه | پاس | شکست |
|---|---|---|
| buffers | 13 | 0 |
| nbt | 11 | 0 |
| json | 5 | 0 |
| chat | 17 | 0 |
| framing | 20 | 0 |
| chunk data (paletted containers) | 10 | 0 |
| registry data | 11 | 0 |
| world queries | 4 | 0 |
| path finder | 12 | 0 |
| text layout: mixed Persian / English | 29 | 0 |
| chat: clickEvent / hoverEvent / font | 27 | 0 |
| layout: spans keep events, and pack fonts are measured by the metrics | 5 | 0 |
| physics: reference values | 15 | 0 |
| physics: input, sprint and jumping rules | 16 | 0 |
| physics: friction blocks | 7 | 0 |
| physics: water, lava and ladders | 11 | 0 |
| physics: collision shapes (step-up, slabs, stairs, ledges) | 9 | 0 |
| physics: flying, effects, unloaded chunks | 13 | 0 |
| planning: goals drive A*, stairs/slabs need real shapes | 8 | 0 |
| baritone: ActionCosts | 9 | 0 |
| baritone: goals | 18 | 0 |
| menus: types, sizes and layouts (protocol 765) | 63 | 0 |
| shapes: blockCollisionShapes.json loader and sanity checks | 10 | 0 |
| path finder: Baritone-style obstacles (planner) | 35 | 0 |
| render to PNG (visual check) | 2 | 0 |
| server list ping | 11 | 0 |
| login, compression, chat, health, players, suggestions | 44 | 0 |
| auto-login and startup commands | 29 | 0 |
| kick and auto-rejoin | 44 | 0 |
| online-mode servers | 1 | 0 |
| world loading, gravity and teleports | 22 | 0 |
| inventory, containers and item actions | 62 | 0 |
| death and respawn | 24 | 0 |
| robustness against odd or hostile servers | 14 | 0 |
| resource packs (download, hash cache, decline) | 43 | 0 |
| path finding + walking against server-side collision checks | 53 | 0 |
| follow a player | 17 | 0 |
| sim: dig through a stone wall with the right tool | 19 | 0 |
| sim: bare-hand digging of dirt, wrong tool timing | 16 | 0 |
| sim: digging off, and protected blocks | 26 | 0 |
| sim: bridge a gap with placed blocks | 30 | 0 |
| sim: pillar up by jumping and placing underneath | 17 | 0 |
| sim: swim across a pond | 28 | 0 |
| sim: climb a ladder | 14 | 0 |
| sim: open a door in a wall | 15 | 0 |
| session: movement packets like LocalPlayer.sendPosition | 20 | 0 |
| session: server-driven motion (velocity, explosion, attributes, effects, abilities) | 72 | 0 |
| actions: open a block with a screen, mine, explore, waypoints, auto-eat | 108 | 0 |

## تغییرات نسبت به ۰٫۳
- **حذف‌شده:** ۷ بررسی `physics()` قدیمی (به API حذف‌شدهٔ `tickVertical` وابسته بودند)؛ همهٔ آن موارد در مجموعهٔ «physics» جدید با دقت بیشتر پوشش داده شده‌اند.
- **تغییر رفتار عمدی:** «شیفت‌کلیک پیش‌بینی محلی ندارد» → حالا مثل کلاینت اصلی پیش‌بینی دارد (پیش‌بینی برای پنجرهٔ بازیکن، چست/دیسپنسر/هاپر/شولکر؛ بقیهٔ منوها پاسخ سرور).
- **سرور شبیه‌ساز:** حالا 0x17/0x18/0x19/0x1A و 0x22 را می‌پذیرد، ردیاب حرکت مستقل دارد (`MockServer.Tracker`) و چست را با Open Screen باز می‌کند.
- **جدید:** `PhysicsTests` (71)، `GoalTests` (Baritone: هزینه‌ها، Goalها؛ چیدمان منوها؛ بارگذار شکل‌ها؛ برنامه‌ریزی با دال)، `ChatEventTests` (رویدادها/فونت/چیدمان)، `MoveTests` (پکت‌های حرکتی، سرعت/انفجار/صفات/افکت/توانایی‌ها از سرور، پرواز، باز کردن بلاک، Mine، Explore، Waypoint، خوردن خودکار، پد دستی).

## باگ‌هایی که این تست‌ها/بازبینی پیدا کردند
1. ترتیب انواع منو در ۰٫۳ برای ۷۶۵ غلط بود (`crafter_3x3` = ۷ جا افتاده بود؛ اندازهٔ enchanting و beacon هم اشتباه).
2. پورت اولیهٔ `GoalGetToBlock` قدر مطلق را دور کل عبارت نمی‌گذاشت؛ با خواندن مجدد bytecode اصلاح شد.
3. بررسی سلامت شکل‌ها جعبه‌های با ارتفاع بیش از ۱ (حصار/دیوار ۱٫۵) را رد می‌کرد؛ فایل واقعی minecraft-data را هم رد می‌کرد.
4. شرط «کار معلق» در Walker استاتیک بود و بعد از کندن بلاک بازیکن را ثابت نگه می‌داشت.
5. هدف `GoalNear` با `ceil` ساخته می‌شد و با شرط رسیدن هم‌خوان نبود (ستون‌سازی ناقص می‌ماند)؛ با `floor` اصلاح شد.
6. در آب، بدون نگه‌داشتن پرش بازیکن غرق می‌شد؛ مثل بازیکن واقعی روی سطح شناور می‌ماند.

## چه چیزی تست **نشده**
- رندر Compose، لمس، گردش‌کار دانلود (فونت وزیر، `blockCollisionShapes.json`، `effects.json`، jar ماینکرافت)، ریسورس‌پک واقعی، فونت‌های bitmap/space پک واقعی، سرویس پس‌زمینه، دیالوگ‌ها.
- فایل واقعی `blockCollisionShapes.json` (فقط نمونهٔ هم‌قالب).
- رفتار روی یخ، slime و جریان آب در سرور واقعی؛ اتصال به سرور واقعی ۱٫۲۰٫۴.
